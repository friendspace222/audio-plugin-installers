# Building Breakwater

Breakwater is a separate audio-effect plugin with its own AU, VST3 and optional standalone application. Its bundle ID is `audio.breakwater.plugin`; installer receipts use `audio.breakwater.plugin.au`, `.vst3`, `.app` and `.docs`. Its AU type/subtype/manufacturer are `aufx / BkwD / BkwA`. Its installer targets Breakwater paths and does not replace Tideglass or Ironvale.

## Install a compiled release

Use the finished Mac installer ZIP when available. Extract it and double-click the `.pkg`, or mount the `.dmg` and open `Install Breakwater.pkg`. Apple Installer installs AU and VST3 by default; the standalone app is optional. No compiler, developer tools or Terminal commands are required on the destination Mac.

The source ZIP and `Build-and-Package.command` are developer materials, not a compiled installer. A workflow file alone is not proof of a successful native build. A finished release should include its `BUILD-VALIDATION.txt`, checksums and corresponding-source archive.

## Native Mac build

The default target is Intel `x86_64` with minimum macOS `10.15`. The prepared public GitHub workflow uses the standard `macos-15-intel` runner and Xcode 16.4. It reads the product version from `CMakeLists.txt`, configures the deployment target for both the plugin and JUCE's separate helper build, builds all three formats, runs CTest and creates native PKG/DMG files.

For a developer build on a suitable Mac, install Apple developer tools and CMake 3.22 or newer, then run from the source folder:

```bash
export MACOSX_DEPLOYMENT_TARGET=10.15
bash scripts/build-macos.sh
```

The scripts can prepare their supported CMake version if needed. A first online build fetches JUCE 7.0.12 at commit `4f43011b96eb0636104cb3e433894cda98243626`. A corresponding-source archive includes the actual JUCE source tree used in the build under `vendor/JUCE` for offline builds. Apple compilers, SDKs and CMake are still required to compile that source.

On Catalina, use Apple developer tools that can run on Catalina; Xcode 16.4 is the newer CI host's toolchain, not a Catalina requirement. Successful compilation and deployment metadata do not prove compatibility with Catalina 10.15.7 or a particular Logic/GarageBand version.

Generated files are placed in `dist/`. A build refuses to overwrite an existing version's installer/source archive; move previous outputs aside before rebuilding that version. To package completed local binaries without recompiling, run `Make-Installer.command` from the same source tree.

## Independent public CI

The prepared workflow is `.github/workflows/build-breakwater.yml` in the installer repository. It runs manually or when `breakwater-source.zip` changes on `main`. Its source archive must contain the `Breakwater/` directory, including `Resources/Kit`, source, tests, scripts, documentation and licenses. The matching SHA-256 file is verified before extraction. The workflow must be committed before the source ZIP upload so that upload starts the intended build.

The job is restricted to public repositories, a standard GitHub-hosted Intel Mac runner, one product and a 25-minute timeout. It has read-only repository permissions, no signing credentials and one-day artifact retention. It does not use a paid runner or publish a release. Other plugins' workflows and artifacts are independent.

The native checks are designed to:

1. Build AU, VST3 and standalone formats; run the project's tests and inspect Intel/deployment metadata.
2. Verify all 24 kit WAV files against the source manifest, plus their attribution and license files.
3. Confirm byte-identical kit assets in every compiled bundle and the complete corresponding-source archive.
4. Inspect all four installer payloads for Catalina-compatible legacy gzip compression.
5. Execute the default installer, verify AU/VST3/documentation destinations, then install the optional app.
6. Check installed signatures, ownership, versions and receipts, and all kit assets under each bundle's `Contents/Resources/Kit`.
7. Refresh AU registration, require discovery within 30 seconds and run `auval -v aufx BkwD BkwA` against the actual system installation.
8. Verify the disk image and package/source checksums before uploading the finished artifact.

These checks run on macOS 15. They do not establish Catalina runtime behavior, Logic/GarageBand integration, musical quality or suitability for every guide recording. Read the generated validation record to see which checks actually passed for a downloaded build.

## Resources and licenses

CMake copies `Resources/Kit` as separate assets into the AU, VST3 and standalone bundles before packaging. The corresponding-source script also preserves that directory. Do not omit WAV files when preparing a source ZIP: the installed plugin needs these recordings.

The starter kit has eight pieces, three recorded velocity layers per piece and one recording per layer, for 24 WAV files. `Resources/Kit/manifest.json` records their original names, hashes and format. Attribution and license notices accompany the assets; detailed provenance is in `docs/STARTER-KIT-PROVENANCE.txt`.

The default combined plugin code distribution is GPLv3. The independently licensed AVL Drumkits sample assets use CC-BY-SA 3.0 with the original AVL Drumkits music exception. Preserve the supplied notices and corresponding source when redistributing. The default installer is unsigned and not notarized; the bundles have ad-hoc code signatures.

## Musical limitations of this version

Breakwater generates a drum arrangement from a captured or imported guitar/bass guide. Use a constant-tempo 4/4 project and align the guide's first bar to the DAW grid. This version is not an automatic arbitrary-meter or tempo-map follower. The starter kit is a compact recorded kit, not a large commercial drum library with many recorded round robins. Host registration and DSP tests do not substitute for listening to the generated arrangement in the intended project.
