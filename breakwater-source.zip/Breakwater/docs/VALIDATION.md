# Breakwater 0.1.0 validation

The dependency-free core passes 209 checks, including guide accent influence,
distinct styles, half-time backbeats, phrase fills, triplets, dynamic sections,
seeded repeatability, gap handling, bounded limb collisions, invalid input,
44.1-384 kHz analysis and allocation-free prepare/begin/process.

The optimized Windows plugin build passes its processor integration suite with
the actual bundled sample kit: recorded-input learning, silent reference monitor,
generation, audible output, transport stop/live rewind, stopped-capture preservation
across prepareToPlay, enabled mute, preview dismissal, session note/guide recall,
malformed state preservation, WAV guide import, MIDI export including duration,
background stereo WAV export, local preview and native editor construction.
Synthesized guitar-like pulses provide repeatable regression input. They do not
prove quality on a real guitar performance or a finished mix.

The final optimized Windows VST3 also passes pluginval at strictness 5 with
seed 6726. This exercises plugin lifecycle, parameters, state, processing and
editor behavior independently of the project's integration suite.

The kit's 24 WAV hashes match the original source. The native build workflow
checks the resource files and attribution in compiled bundles, actual installed
bundles and corresponding source, then tests the installed AU. The finished
installer ZIP's BUILD-VALIDATION.txt records the exact successful native run;
this source document alone is not proof that a later Mac build passed.

The target is Intel x86_64 / macOS 10.15. A modern Intel Mac runner can validate
binary deployment metadata, package installation and AU behavior, but cannot
establish Catalina 10.15.7 or the user's GarageBand version's behavior. Host
suspension/bounce, recorded-track workflow and listening on that Mac still need
acceptance testing. No universal superiority or artist-emulation claim is made.

Known first-preview boundaries: 4/4, fixed tempo during learning, up to 128 bars,
no automatic beat-grid/tempo inference, no semantic section recognition, no
editable per-section map, and no fill-only selective regeneration. The acoustic
starter kit has three velocity layers, without true recorded round robins.
