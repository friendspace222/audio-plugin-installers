# Breakwater: first session

Breakwater 0.1 follows recorded parts through a listening pass. It is an Audio
Unit effect with an internal drum kit. It cannot select or read another track
directly, and it does not replace GarageBand's built-in Drummer track type.

## Inside GarageBand

1. Set the project to **4/4** and the correct, fixed tempo. Your reference should
   fit that beat grid. A clean guitar or bass recording usually gives clearer
   attacks than a heavily compressed mix. Tempo detection is not included yet.
2. Create a new **audio track** named Drums Guide. Copy the desired guitar/bass
   audio regions to it at exactly their original timeline positions. Use a clean
   track without amp effects or other processing after Breakwater.
3. In that track's plug-in slots, choose **Audio Units > Breakwater Audio >
   Breakwater**. Leave this track enabled and unmuted. Keep Reference Monitor at
   zero so the copied guitar/bass is not heard twice; its input still gets learned.
4. Rewind to a bar boundary before the part. Press **Listen**, then play the
   recorded reference. The plugin arms until it receives a running host transport.
   Keep the original instrument track audible. A listening pass records timing
   and activity features locally; it does not upload or store the raw recording.
5. Stop playback and click **Finish & Generate**. A cycle wrap or timeline seek
   ends the listening pass; learn one pass, not multiple overlapping cycles.
6. Rewind to the same project position and play. Breakwater now produces drums
   on Drums Guide while the original instrument plays on its original track.
7. Adjust the drummer controls and click **Update**. **New Variation** keeps the
   guide/settings and chooses a new repeatable variation. Save your GarageBand
   project after generating: the timing features and exact notes are embedded
   in the session, so the source file is not needed for playback.

For different sections, use separate instances on guide tracks holding the
corresponding regions, or export an approved section before learning the next.
Keep each exported part aligned to its reported start bar. There is no editable
multi-section arrangement map or selective fill-only regeneration in 0.1.

## Choosing a performance

- **Post-hardcore:** syncopated guide-driven kicks and driving backbeats.
- **Metal:** greater double-kick density and sustained heavy rhythmic drive.
- **Screamo:** more frenetic density, cymbal accents and phrase activity.
- **Emo:** more restrained kicks and open space around the backbeat.
- **Auto dynamics:** energy-based density choices; it does not identify lyrics,
  verses or choruses semantically. Choose Verse/Chorus/Breakdown explicitly when
  you know the section's role. Breakdown uses a half-time backbeat.
- **Follow Riff:** how strongly detected reference accents influence kick notes.
  It does not assign every guitar note to a drum or copy an existing drum track.
- **Double Kick / Complexity:** density controls. Maximum values can be very busy.
- **Fills:** likelihood of fills at phrase/section ends. Human Feel changes
  timing and strength within bounded limits rather than constantly adding notes.
- **Triplets:** use a triplet subdivision for the generated patterns. The meter
  remains 4/4. **Respect Pauses** suppresses hits during gaps; switch it off if
  sparse guitar picking makes the drums stop too often.

Try moderate Follow and Complexity first, then raise Double Kick for heavier
choruses. Use explicit Breakdown for deliberate half-time sections. Compare
generated takes at similar output levels; louder does not mean better.

## Preview, import and export

**Preview** auditions the arrangement locally while the host is stopped. It
starts at the learned section's beginning and includes the kit tail. Starting
host playback dismisses Preview. In standalone mode, import a WAV/AIFF guide,
set Manual Tempo and Import Start Bar, then use Preview. Imported files must fit
the manually supplied grid; this version does not infer a free-time tempo map.

**Export MIDI** writes General MIDI channel-10 drum notes, a fixed tempo event,
4/4 meter and the complete section length including trailing rests. Import it
into GarageBand and select a compatible drum instrument. Its sounds depend on
that instrument; MIDI itself contains no samples. The file starts at its own
beat zero, so place it at the start bar shown by Breakwater.

**Export WAV** writes a separate 48 kHz, stereo, 24-bit drum file with the current
kit mix and an eight-second tail. It does not mix in the reference recording.
Rendering runs in the background. Place it at the reported start bar. Export
uses the learned fixed tempo, even if the host tempo has subsequently changed.

If you edit the underlying guitar timing, learn it again. Changing style or
generation controls requires Update; the drum mixer and output apply directly.
The rendered note sequence is deterministic for the saved guide/settings/seed.

## Limits and troubleshooting

- Maximum 128 bars per instance. Import longer songs in sections.
- Only 4/4 and a fixed learning tempo are supported. Tempo changes stop capture;
  use separate constant-tempo sections. Host playback can scale existing note
  positions to its current tempo, but WAV export is fixed-tempo.
- If there are no drums, check input activity during Listen, finish the pass,
  rewind to the learned start, enable Drummer, and ensure the kit is installed.
- Keep the copied guide track unmuted. Muting a track can stop the host feeding
  the effect. If you bypass the effect in GarageBand, the raw copied guide can
  become audible; use the plugin's Drummer switch to silence its drums instead.
- The mix has a soft output ceiling. Turn down drum Output or individual pieces
  if heavy layering sounds squashed. This is not a mastering processor.
- The starter kit has three velocity recordings per piece and no true recorded
  round robins. Fast repeated hits may still benefit from another MIDI drum kit.
- No claim of outperforming GarageBand or accurately reproducing a particular
  artist's drummer has been established. Real-instrument listening remains key.

The code and sample licenses are separate. See THIRD_PARTY_NOTICES.md and
STARTER-KIT-PROVENANCE.txt; the sample library's music exception allows produced
music to be licensed freely. Keep sample attribution/licenses when redistributing
the sample library or plugin installer.
