#!/usr/bin/env python3
"""Reproduce the Breakwater starter kit from its pinned, freely licensed source.

Python standard library only. The shipped WAVs are already 44.1 kHz / 16-bit /
mono, so this script copies their complete original bytes without resampling,
trimming, normalising or synthesising alternate hits.
"""

import argparse
import hashlib
import io
import json
from pathlib import Path
import urllib.request
import wave
import zipfile


SOURCE_URL = "https://www.bandshed.net/sounds/AVLDrumkits_SFZ/RED_ZEPPELIN_2023_repack.zip"
SOURCE_SHA256 = "9f5c5e5a76decae7eb63b2242f91a51210e91f7e5bb57587352c544721b1012f"
SOURCE_ROOT = "RED_ZEPPELIN_2023_repack/"
LAYERS = (1, 3, 5)
PIECES = {
    "kick": "36-Ludwig-26-Kick",
    "snare": "38-Ludwig-14-Snare",
    "hat_closed": "42-Sabian-13-HatClosed",
    "hat_open": "48-Sabian-13-HatSwish",
    "tom_high": "45-Ludwig-14-Tom",
    "tom_low": "41-Ludwig-16-FloorTom",
    "crash": "49-Zildjian-20-Crash",
    "ride": "51-Zildjian-24-Ride",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path,
                        help="Use an already downloaded original ZIP instead of the network")
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[1] / "Resources" / "Kit")
    args = parser.parse_args()
    archive = (args.archive.read_bytes() if args.archive else
               urllib.request.urlopen(SOURCE_URL, timeout=60).read())
    actual_hash = hashlib.sha256(archive).hexdigest()
    if actual_hash != SOURCE_SHA256:
        raise RuntimeError("Source archive SHA-256 differs from the reviewed release: " + actual_hash)

    args.output.mkdir(parents=True, exist_ok=True)
    entries = []
    with zipfile.ZipFile(io.BytesIO(archive)) as source:
        for piece, original_prefix in PIECES.items():
            for layer, original_layer in enumerate(LAYERS, 1):
                original_name = f"{original_prefix}-{original_layer}.wav"
                member = SOURCE_ROOT + original_name
                data = source.read(member)
                with wave.open(io.BytesIO(data), "rb") as reader:
                    if (reader.getnchannels(), reader.getsampwidth(), reader.getframerate()) != (1, 2, 44100):
                        raise RuntimeError("Unexpected source WAV format: " + member)
                    frames = reader.getnframes()
                filename = f"{piece}_v{layer}_r1.wav"
                (args.output / filename).write_bytes(data)
                entries.append({
                    "file": filename,
                    "piece": piece,
                    "velocity_layer": layer,
                    "source_velocity_layer": original_layer,
                    "round_robin": 1,
                    "source_member": member,
                    "sha256": hashlib.sha256(data).hexdigest(),
                    "bytes": len(data),
                    "channels": 1,
                    "sample_rate": 44100,
                    "pcm_bits": 16,
                    "frames": frames,
                })
    manifest = {
        "name": "Breakwater starter kit",
        "source_creator": "Glen MacArthur",
        "source_library": "AVL Drumkits / Red Zeppelin 2023 repack",
        "source_url": SOURCE_URL,
        "source_archive_sha256": SOURCE_SHA256,
        "license": "CC-BY-SA-3.0 with the original AVL Drumkits music exception",
        "license_url": "https://bandshed.net/pdf/AVL-Drumkits%20CC-BY-SA%20License.pdf",
        "changes": "Subset selection and file renaming only; WAV bytes are unchanged.",
        "true_velocity_layers_per_piece": 3,
        "true_round_robins_per_layer": 1,
        "samples": entries,
    }
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(f"Prepared {len(entries)} unchanged WAVs; {sum(e['bytes'] for e in entries):,} bytes.")


if __name__ == "__main__":
    main()
