#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
fail() { echo "ERROR: $*" >&2; exit 1; }
[[ "$(uname -s)" == Darwin ]] || fail "A Mac is required to build Audio Units and Apple installers."
xcode-select -p >/dev/null 2>&1 || fail "Install Apple Command Line Tools with xcode-select --install, then rerun."
xcrun --find clang++ >/dev/null 2>&1 || fail "Apple clang++ is unavailable. Select an installed Xcode/Command Line Tools."
xcrun --show-sdk-path >/dev/null 2>&1 || fail "A macOS SDK is required. Complete the Xcode setup first."
cmake_bin="$(/bin/bash "$project_dir/scripts/ensure-cmake-macos.sh")" || fail "Could not prepare CMake. See the error above."
export PATH="$cmake_bin:$PATH"
for tool in cmake ctest git pkgbuild productbuild lipo otool codesign; do
    command -v "$tool" >/dev/null 2>&1 || fail "Missing $tool. Install CMake 3.22+ and Apple developer tools (see docs/BUILD.md)."
done
arch="${BREAKWATER_ARCHITECTURES:-x86_64}"
minimum="${BREAKWATER_MIN_MACOS:-10.15}"
case "$arch" in
    x86_64) flavor="macos-x86_64" ;;
    arm64) flavor="macos-arm64" ;;
    'x86_64;arm64'|'arm64;x86_64') flavor="macos-universal" ;;
    *) fail "Use x86_64, arm64, or 'x86_64;arm64' architectures." ;;
esac
build_dir="$project_dir/build/$flavor"
echo "Breakwater: $arch, minimum macOS $minimum."
if [[ -f "$project_dir/vendor/JUCE/CMakeLists.txt" ]]; then
    echo "Using bundled JUCE 7.0.12. Allow time for compilation."
else
    echo "First build downloads pinned JUCE 7.0.12 from GitHub; allow time for compilation."
fi
cmake -S "$project_dir" -B "$build_dir" -G "Unix Makefiles" \
    -DCMAKE_BUILD_TYPE=Release \
    "-DCMAKE_OSX_ARCHITECTURES=$arch" \
    "-DCMAKE_OSX_DEPLOYMENT_TARGET=$minimum" \
    -DBREAKWATER_BUILD_PLUGIN=ON -DBREAKWATER_BUILD_TESTS=ON
cmake --build "$build_dir" --config Release --parallel "${BREAKWATER_JOBS:-4}"
ctest --test-dir "$build_dir" -C Release --output-on-failure
/bin/bash "$project_dir/scripts/verify-macos.sh" "$build_dir" "$arch" "$minimum"
/bin/bash "$project_dir/scripts/package-macos.sh" "$build_dir" "$arch" "$minimum"
