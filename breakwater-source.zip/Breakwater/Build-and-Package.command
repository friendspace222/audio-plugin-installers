#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")" && pwd)"
if /bin/bash "$project_dir/scripts/build-macos.sh"; then
    echo "Build and packaging finished. See the dist folder."
else
    status=$?
    echo "Build stopped (exit $status). Read the error above and docs/BUILD.md."
    if [[ -t 0 ]]; then read -r -p "Press Return to close..." unused; fi
    exit "$status"
fi
if [[ -t 0 ]]; then read -r -p "Press Return to close..." unused; fi
