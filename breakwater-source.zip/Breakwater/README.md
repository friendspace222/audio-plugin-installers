# Breakwater 0.1.0

A first working recorded-guide drummer for post-hardcore, metal, screamo and emo.
An AU audio effect listens to a copied guitar/bass part inside GarageBand, then
plays its generated acoustic drum arrangement at the learned project position.
The original guitar/bass track remains separate. VST3 and standalone formats are
also included. No cloud service, subscription or paid sound library is required.

This preview supports 4/4 and a fixed project tempo, up to 128 bars per instance.
Set GarageBand's tempo correctly before listening. It is not an automatic tempo,
time-signature or semantic verse/chorus detector, and it is not Apple's Drummer
track type. Auto dynamics chooses arrangement density from the guide's energy.
Musical quality and the exact Catalina/GarageBand workflow need user audition.

Features include four distinct style biases; Verse, Chorus and half-time
Breakdown modes; riff-following kick placement; double-kick density; phrase fills;
straight/triplet subdivision; timing/velocity variation; pause handling; per-piece
mix controls; saved arrangements; MIDI and stereo drum-WAV export. Playback uses
the host's position, including rewinding and looping the recorded regions.

The starter kit contains 24 real acoustic recordings: eight pieces, three
recorded velocity layers each. It has one recording per layer, not recorded round
robins. See docs/STARTER-KIT-PROVENANCE.txt. Sample assets are independently
licensed CC-BY-SA 3.0 with the AVL music exception, and remain separate WAV files.

Read START-HERE-MAC.txt and docs/USER-GUIDE.md before the first listening pass.
The target is Intel macOS 10.15+, with a double-click PKG installer. The installer
ZIP's BUILD-VALIDATION.txt records the actual native checks; a newer-Mac build
does not establish Catalina or GarageBand runtime compatibility. The free build
is ad-hoc signed with an unsigned, unnotarized installer.

Original code is MIT; combined JUCE plugin binaries use GPLv3. Corresponding
source, full JUCE source and all sample/license notices accompany the installer.
