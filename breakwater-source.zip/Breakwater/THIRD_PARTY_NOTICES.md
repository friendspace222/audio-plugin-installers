# Breakwater third-party notices

Original Breakwater source code is MIT, as stated in LICENSE. Its original
groove rules are not copied transcriptions of commercial songs or products.

## JUCE 7.0.12 and bundled SDKs

JUCE is pinned to commit 4f43011b96eb0636104cb3e433894cda98243626. The default
combined plugin is distributed under GPLv3. The original-code MIT license does
not remove the combined work's obligations. GPLv3 and the pinned JUCE and VST3
notices are in docs/licenses. The corresponding-source archive includes the
complete JUCE source used in the build, including embedded dependency notices.
Distribute the corresponding-source archive with the installer. No commercial
JUCE license or paid subscription is used by this open-source build.

## Breakwater starter kit / AVL Drumkits

Resources/Kit contains a distinctly named subset of Glen MacArthur's AVL Red
Zeppelin 2023 repack. These WAV assets are separate from the program and retain
their own CC-BY-SA 3.0 license with the author's music exception. They have not
been relicensed as MIT or GPL. Selection and file renaming are the only changes;
the selected audio bytes are unchanged. There are three velocity layers and one
recording per layer for each of eight pieces, with no recorded round robins.

Attribution, complete license and original PDF, source URLs, hashes and the
selection manifest are retained in Resources/Kit and docs/licenses. The original
author's music exception allows produced music and other non-sample-library
works to be licensed freely. Preserve these notices when redistributing the
samples. See docs/STARTER-KIT-PROVENANCE.txt and scripts/prepare_starter_kit.py.

Source and license: https://www.bandshed.net/avldrumkits/
https://bandshed.net/pdf/AVL-Drumkits%20CC-BY-SA%20License.pdf

No affiliation with Apple, any artist, or the recorded instrument manufacturers
is implied. Hardware names in sample provenance identify the recorded equipment.
