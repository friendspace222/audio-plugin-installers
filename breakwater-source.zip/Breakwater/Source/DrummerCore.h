#pragma once
#include <array>
#include <cstdint>
#include <vector>

namespace breakwater {
constexpr int ticksPerBeat = 24;
constexpr int maxBars = 128;
constexpr int maxTicks = maxBars * 4 * ticksPerBeat;
enum class Piece : int { Kick, Snare, HatClosed, HatOpen, TomHigh, TomLow, Crash, Ride, Count };
struct Event { double beat = 0; Piece piece = Piece::Kick; float velocity = 0.8f; };
struct Guide {
    std::array<float, maxTicks> accents{};
    std::array<float, maxTicks> activity{};
    int ticks = 0;
    double startBeat = 0, bpm = 120;
    bool hasSignal = false;
};
struct Settings {
    int style = 0; // Post-hardcore, Metal, Screamo, Emo
    int section = 0; // Auto energy, Verse, Chorus, Breakdown
    float complexity = .55f, intensity = .7f, follow = .75f;
    float doubleKick = .35f, fills = .5f, humanize = .3f;
    bool triplet = false, respectGaps = true;
    uint32_t seed = 1;
};
struct Pattern { std::vector<Event> events; int bars = 0; double startBeat = 0, bpm = 120; };
class GuideAnalyser {
public:
    void prepare(double sampleRate) noexcept;
    void begin(double startBeat, double bpm) noexcept;
    void process(float mono, double absoluteBeat) noexcept;
    const Guide& result() const noexcept { return guide; }
private:
    Guide guide{};
    double rate = 48000;
    float envelope = 0, previous = 0, fast = 0, slow = 0, previousInput = 0;
    double lastBeat = -1;
};
Pattern generate(const Guide&, const Settings&);
int midiNote(Piece) noexcept;
} // namespace breakwater
