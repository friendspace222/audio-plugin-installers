#pragma once
#include <JuceHeader.h>
#include "DrummerCore.h"
#include "KitSampler.h"
#include <atomic>

class BreakwaterAudioProcessor final : public juce::AudioProcessor {
public:
    BreakwaterAudioProcessor();
    ~BreakwaterAudioProcessor() override;
    void prepareToPlay(double,int) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
    void processBlockBypassed(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Breakwater"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 10; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "Custom drummer"; }
    void changeProgramName(int,const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*,int) override;

    void beginListen();
    bool finishAndGenerate();
    bool generatePattern(bool newVariation = false);
    bool importGuide(const juce::File&);
    bool exportMidi(const juce::File&);
    void exportAudio(const juce::File&); // background render; status reflects completion
    void setPreview(bool on) noexcept;
    bool isPreviewing() const noexcept { return preview.load(); }
    void clearPattern();
    juce::String getStatus() const;
    breakwater::Pattern getPatternSnapshot() const;
    bool hasGuide() const;
    bool isKitReady() const noexcept { return kitReady.load(); }

    juce::AudioProcessorValueTreeState parameters;
    std::atomic<int> listenState{0}; // 0 idle, 1 armed, 2 capturing, 3 ready to generate
    std::atomic<int> learnedBars{0}, eventCount{0};
    std::atomic<float> inputPeak{0}, outputPeak{0};
    std::atomic<double> currentBpm{120}, currentBeat{0};
    std::atomic<bool> hostPlaying{false}, hostTiming{false}, exportBusy{false};
    std::atomic<int> timingIssue{0}; // 1 unsupported meter, 2 tempo/seek discontinuity

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    float value(const char*) const noexcept;
    breakwater::Settings settings() const;
    void status(const juce::String&);
    void adoptPattern(breakwater::Pattern);
    mutable juce::SpinLock captureLock, patternLock;
    breakwater::GuideAnalyser analyser;
    breakwater::Guide savedGuide;
    bool captureCached = false; // protected by captureLock
    breakwater::Pattern pattern;
    breakwater::KitSampler sampler;
    double rate = 48000, previewBeat = 0, expectedBeat = -100000;
    std::atomic<bool> preview{false}, resetVoices{false}, kitReady{false};
    size_t cursor = 0;
    std::atomic<uint32_t> variation{1};
    mutable juce::CriticalSection statusLock;
    juce::String statusText = "Copy your guitar/bass regions to a new audio track. Insert Breakwater there, then Listen.";
    juce::ThreadPool exports{1};
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(BreakwaterAudioProcessor)
};
