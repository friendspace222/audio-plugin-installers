#include "PluginProcessor.h"
#include <cmath>
#include <algorithm>

namespace {
float clean(float x) noexcept {return std::isfinite(x)?std::clamp(x,-16.f,16.f):0.f;}
float ceiling(float x) noexcept {x=clean(x);const float a=std::abs(x);return a<=.8f?x:std::copysign(.8f+.18f*std::tanh((a-.8f)/.18f),x);}
bool decodeBounded(juce::MemoryBlock& bytes,const juce::String& encoded,size_t limit){
    const auto prefix=encoded.upToFirstOccurrenceOf(".",false,false);
    if(prefix.isEmpty()||prefix.length()>8||!prefix.containsOnly("0123456789"))return false;
    const auto declared=prefix.getLargeIntValue();
    if(declared<0||(uint64_t)declared>limit||encoded.length()>(int)(limit*2+32))return false;
    return bytes.fromBase64Encoding(encoded)&&bytes.getSize()==(size_t)declared;
}
constexpr const char* levelIds[]={"kickDb","snareDb","hatDb","tomDb","cymbalDb"};
}
juce::AudioProcessorValueTreeState::ParameterLayout BreakwaterAudioProcessor::createLayout() {
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    auto choice=[&](const char* id,const char* name,juce::StringArray items,int initial=0){layout.add(std::make_unique<juce::AudioParameterChoice>(juce::ParameterID{id,1},name,items,initial));};
    auto number=[&](const char* id,const char* name,float low,float high,float initial,float step=.1f){layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{id,1},name,juce::NormalisableRange<float>{low,high,step},initial));};
    auto toggle=[&](const char* id,const char* name,bool initial){layout.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{id,1},name,initial));};
    choice("style","Style",{"Post-hardcore","Metal","Screamo","Emo"});
    choice("section","Section",{"Auto dynamics","Verse","Chorus","Breakdown"});
    number("complexity","Complexity",0,100,55);number("intensity","Intensity",0,100,70);
    number("follow","Follow riff",0,100,75);number("doubleKick","Double kick",0,100,35);
    number("fills","Fills",0,100,50);number("humanize","Human feel",0,100,30);
    toggle("triplet","Triplet subdivision",false);toggle("respectGaps","Respect pauses",true);
    number("bpm","Manual tempo",40,240,120,.01f);number("startBar","Import start bar",1,128,1,1);
    number("dryMix","Reference monitor",0,100,0);number("outputDb","Drum output",-24,6,-6);
    number("kickDb","Kick",-24,6,0);number("snareDb","Snare",-24,6,0);number("hatDb","Hi-hat",-24,6,0);
    number("tomDb","Toms",-24,6,0);number("cymbalDb","Cymbals",-24,6,0);
    toggle("enabled","Drummer enabled",true);
    return layout;
}
BreakwaterAudioProcessor::BreakwaterAudioProcessor():AudioProcessor(BusesProperties().withInput("Reference",juce::AudioChannelSet::stereo(),true).withOutput("Drums",juce::AudioChannelSet::stereo(),true)),parameters(*this,nullptr,"BreakwaterState",createLayout()) {
    kitReady=sampler.load();if(!kitReady)status("Drum samples are missing. Reinstall the complete Breakwater package.");
}
BreakwaterAudioProcessor::~BreakwaterAudioProcessor(){exports.removeAllJobs(true,-1);}
float BreakwaterAudioProcessor::value(const char* id) const noexcept {return parameters.getRawParameterValue(id)->load();}
breakwater::Settings BreakwaterAudioProcessor::settings() const {
    breakwater::Settings s;s.style=(int)value("style");s.section=(int)value("section");
    s.complexity=value("complexity")/100;s.intensity=value("intensity")/100;s.follow=value("follow")/100;
    s.doubleKick=value("doubleKick")/100;s.fills=value("fills")/100;s.humanize=value("humanize")/100;
    s.triplet=value("triplet")>.5f;s.respectGaps=value("respectGaps")>.5f;s.seed=variation.load();return s;
}
void BreakwaterAudioProcessor::prepareToPlay(double sampleRate,int) {
    rate=std::isfinite(sampleRate)&&sampleRate>=8000?sampleRate:48000;
    {const juce::SpinLock::ScopedLockType lock(captureLock);
     if(listenState==2||listenState==3){if(!captureCached)savedGuide=analyser.result();captureCached=true;listenState=3;}
     analyser.prepare(rate);}
    sampler.prepare(rate);expectedBeat=-100000;cursor=0;previewBeat=0;
}
bool BreakwaterAudioProcessor::isBusesLayoutSupported(const BusesLayout& l) const {
    const auto input=l.getMainInputChannelSet(),output=l.getMainOutputChannelSet();
    return (input==juce::AudioChannelSet::mono()&&(output==juce::AudioChannelSet::mono()||output==juce::AudioChannelSet::stereo()))
        || (input==juce::AudioChannelSet::stereo()&&output==juce::AudioChannelSet::stereo());
}
void BreakwaterAudioProcessor::status(const juce::String& s){const juce::ScopedLock lock(statusLock);statusText=s;}
juce::String BreakwaterAudioProcessor::getStatus() const {
    if(!kitReady)return "Drum samples missing: reinstall the complete package.";
    if(timingIssue==1)return "This preview supports 4/4. Set the project to 4/4 before listening or playback.";
    if(exportBusy)return "Rendering drum WAV in the background...";
    if(listenState==1)return "Listening is armed. Play your recorded reference in GarageBand, from a bar boundary.";
    if(listenState==2)return "Learning your reference: "+juce::String(learnedBars.load())+" bars. Stop playback, then Finish & Generate.";
    if(listenState==3)return timingIssue==2?"Capture ended at a tempo change or seek. Finish & Generate this section, or learn it again at a fixed tempo.":"Reference captured. Choose Finish & Generate. Keep the project in 4/4 at the recorded tempo.";
    const juce::ScopedLock lock(statusLock);return statusText;
}
void BreakwaterAudioProcessor::beginListen(){const juce::SpinLock::ScopedLockType lock(captureLock);captureCached=false;preview=false;listenState=1;learnedBars=0;timingIssue=0;resetVoices=true;}
bool BreakwaterAudioProcessor::finishAndGenerate(){
    {const juce::SpinLock::ScopedLockType lock(captureLock);
     const int previousState=listenState.exchange(0);
     if(previousState==2||previousState==3){if(!captureCached)savedGuide=analyser.result();captureCached=false;}
     else if(previousState==1){status("Nothing captured yet. Press Listen, then play the reference track.");return false;}}
    return generatePattern();
}
bool BreakwaterAudioProcessor::hasGuide() const {const juce::SpinLock::ScopedLockType lock(captureLock);return savedGuide.hasSignal;}
void BreakwaterAudioProcessor::adoptPattern(breakwater::Pattern p){
    {const juce::SpinLock::ScopedLockType lock(patternLock);pattern=std::move(p);eventCount=(int)pattern.events.size();}
    resetVoices=true;
}
breakwater::Pattern BreakwaterAudioProcessor::getPatternSnapshot() const {const juce::SpinLock::ScopedLockType lock(patternLock);return pattern;}
bool BreakwaterAudioProcessor::generatePattern(bool next){
    if(listenState.load()!=0){status("Finish the listening pass before generating a new take.");return false;}
    breakwater::Guide guide;{const juce::SpinLock::ScopedLockType lock(captureLock);guide=savedGuide;}
    if(!guide.hasSignal){status("No usable reference yet. Listen to a recorded part or import its WAV/AIFF.");return false;}
    if(next)variation.fetch_add(1);
    auto p=breakwater::generate(guide,settings());
    if(p.events.empty()){status("No rhythmic activity detected. Check the reference level and project tempo.");return false;}
    const int bars=p.bars;adoptPattern(std::move(p));status("Generated "+juce::String(bars)+" bars. Rewind to the learned start and play. Adjust the feel, then choose Update.");return true;
}
void BreakwaterAudioProcessor::clearPattern(){listenState=0;preview=false;{const juce::SpinLock::ScopedLockType lock(captureLock);savedGuide={};}adoptPattern({});status("Cleared. Listen to a new reference or import an audio file.");}
void BreakwaterAudioProcessor::setPreview(bool on) noexcept {preview=on;resetVoices=true;}
void BreakwaterAudioProcessor::processBlockBypassed(juce::AudioBuffer<float>& buffer,juce::MidiBuffer& midi){
    midi.clear();sampler.reset();expectedBeat=-100000;
    if(getTotalNumInputChannels()==1&&buffer.getNumChannels()>1)buffer.copyFrom(1,0,buffer,0,0,buffer.getNumSamples());
}
void BreakwaterAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer,juce::MidiBuffer& midi){
    juce::ScopedNoDenormals denormals;midi.clear();
    double tempo=value("bpm"),beat=0;bool playing=false,timing=false,validMeter=true;
    if(auto* head=getPlayHead())if(auto position=head->getPosition()){
        playing=position->getIsPlaying();
        if(auto bpm=position->getBpm())if(std::isfinite(*bpm)&&*bpm>=20&&*bpm<=400)tempo=*bpm;
        if(auto ppq=position->getPpqPosition())if(std::isfinite(*ppq)){beat=*ppq;timing=true;}
        if(!timing)if(auto time=position->getTimeInSamples()){beat=(double)*time/rate*tempo/60;timing=true;}
        if(auto meter=position->getTimeSignature())validMeter=meter->numerator==4&&meter->denominator==4;
    }
    currentBpm=tempo;currentBeat=beat;hostPlaying=playing;hostTiming=timing;
    if(playing)preview=false;
    if(!validMeter)timingIssue=1;else if(timingIssue==1)timingIssue=0;
    const double step=tempo/(60*rate);
    const bool audition=preview.load()&&!playing;
    const bool active=(playing&&timing&&validMeter)||audition;
    if(resetVoices.exchange(false)){sampler.reset();expectedBeat=-100000;previewBeat=0;cursor=0;}
    const juce::SpinLock::ScopedTryLockType captureGuard(captureLock);
    const juce::SpinLock::ScopedTryLockType patternGuard(patternLock);
    if(captureGuard.isLocked()){
        if(listenState==1&&playing&&timing&&validMeter){analyser.begin(std::floor(beat/4)*4,tempo);listenState=2;}
        if(listenState==2&&playing&&(std::abs(tempo-analyser.result().bpm)>.1||(expectedBeat>-99999&&std::abs(beat-expectedBeat)>.25))){listenState=3;timingIssue=2;}
        if(listenState==2&&(!playing||!validMeter||!timing))listenState=3;
    }
    if(audition&&patternGuard.isLocked())beat=pattern.startBeat+previewBeat;
    const bool playPattern=patternGuard.isLocked()&&active&&value("enabled")>.5f&&listenState.load()!=2;
    if(playPattern&&(std::abs(beat-expectedBeat)>step*2||expectedBeat < -99999)){
        sampler.reset();const double relative=beat-pattern.startBeat;
        cursor=(size_t)std::distance(pattern.events.begin(),std::lower_bound(pattern.events.begin(),pattern.events.end(),relative-1e-8,[](const breakwater::Event& e,double b){return e.beat<b;}));
    }
    if(!active||value("enabled")<.5f){sampler.reset();expectedBeat=-100000;if(value("enabled")<.5f)resetVoices=true;}
    std::array<float,5> levels{};for(size_t i=0;i<levels.size();++i)levels[i]=juce::Decibels::decibelsToGain(value(levelIds[i]));
    const float output=juce::Decibels::decibelsToGain(value("outputDb"));
    const float dry=listenState.load()==2?value("dryMix")*.01f:0.f;
    const int inputs=getTotalNumInputChannels();float inPeak=0,outPeak=0;
    for(int n=0;n<buffer.getNumSamples();++n){
        const float l=clean(buffer.getSample(0,n)),r=inputs>1?clean(buffer.getSample(1,n)):l;
        inPeak=std::max(inPeak,std::max(std::abs(l),std::abs(r)));
        const double now=beat+step*n;
        if(captureGuard.isLocked()&&listenState==2){
            if(now<analyser.result().startBeat || now>=analyser.result().startBeat+breakwater::maxBars*4)listenState=3;
            else analyser.process((l+r)*.5f,now);
        }
        if(playPattern){while(cursor<pattern.events.size()&&pattern.startBeat+pattern.events[cursor].beat<now+step){
            const auto& event=pattern.events[cursor++];if(pattern.startBeat+event.beat>=now-step)sampler.trigger(event.piece,event.velocity);
        }}
        float dl=0,dr=0;if(active)sampler.tick(dl,dr,levels);
        const float left=ceiling(dl*output+l*dry),right=ceiling(dr*output+r*dry);
        if(buffer.getNumChannels()==1)buffer.setSample(0,n,(left+right)*.5f);
        else{buffer.setSample(0,n,left);buffer.setSample(1,n,right);}
        outPeak=std::max(outPeak,std::max(std::abs(left),std::abs(right)));
    }
    if(captureGuard.isLocked()&&listenState>=2)learnedBars=(analyser.result().ticks+95)/96;
    if(active)expectedBeat=beat+step*buffer.getNumSamples();
    if(audition&&patternGuard.isLocked()){
        previewBeat+=step*buffer.getNumSamples();
        if(previewBeat>=pattern.bars*4+tempo/60*8){preview=false;resetVoices=true;}
    }
    inputPeak=inPeak;outputPeak=outPeak;
}
bool BreakwaterAudioProcessor::importGuide(const juce::File& file){
    if(listenState!=0){status("Finish the listening pass before importing.");return false;}
    juce::AudioFormatManager formats;formats.registerBasicFormats();std::unique_ptr<juce::AudioFormatReader> reader(formats.createReaderFor(file));
    if(!reader||reader->sampleRate<8000||reader->lengthInSamples<=0){status("Could not read that audio file. Use WAV or AIFF.");return false;}
    const double bpm=value("bpm"),start=(value("startBar")-1)*4;
    const int64_t limit=(int64_t)std::ceil(breakwater::maxBars*4*60/bpm*reader->sampleRate);
    if(reader->lengthInSamples>limit){status("Reference exceeds 128 bars at this tempo. Import a shorter section.");return false;}
    breakwater::GuideAnalyser analysis;analysis.prepare(reader->sampleRate);analysis.begin(start,bpm);
    juce::AudioBuffer<float> audio(2,4096);
    for(int64_t offset=0;offset<reader->lengthInSamples;offset+=4096){const int count=(int)std::min<int64_t>(4096,reader->lengthInSamples-offset);
        audio.clear();if(!reader->read(&audio,0,count,offset,true,true)){status("Audio import failed.");return false;}
        for(int n=0;n<count;++n){const float mono=reader->numChannels>1?(audio.getSample(0,n)+audio.getSample(1,n))*.5f:audio.getSample(0,n);analysis.process(mono,start+(offset+n)/reader->sampleRate*bpm/60);}
    }
    {const juce::SpinLock::ScopedLockType lock(captureLock);savedGuide=analysis.result();}
    return generatePattern();
}
bool BreakwaterAudioProcessor::exportMidi(const juce::File& file){
    const auto p=getPatternSnapshot();if(p.events.empty()){status("Generate a drum part before exporting.");return false;}
    juce::MidiMessageSequence track;track.addEvent(juce::MidiMessage::tempoMetaEvent((int)std::round(60000000/p.bpm)),0);
    track.addEvent(juce::MidiMessage::timeSignatureMetaEvent(4,4),0);
    for(const auto& e:p.events){const int note=breakwater::midiNote(e.piece);track.addEvent(juce::MidiMessage::noteOn(10,note,(juce::uint8)std::clamp((int)std::round(e.velocity*127),1,127)),e.beat*960);track.addEvent(juce::MidiMessage::noteOff(10,note),(e.beat+.08)*960);}
    track.addEvent(juce::MidiMessage::endOfTrack(),std::max(p.bars*4.0*960,track.getEndTime()));
    track.updateMatchedPairs();juce::MidiFile midi;midi.setTicksPerQuarterNote(960);midi.addTrack(track);
    auto out=file.createOutputStream();if(!out||!out->setPosition(0)||!out->truncate().wasOk()||!midi.writeTo(*out)){status("Could not save MIDI.");return false;}
    status("MIDI saved. Drag it into GarageBand at bar "+juce::String(p.startBeat/4+1,1)+" and choose a GM-compatible drum instrument.");return true;
}
void BreakwaterAudioProcessor::exportAudio(const juce::File& file){
    const auto p=getPatternSnapshot();if(p.events.empty()||!kitReady){status("Generate a drum part with the installed kit before exporting.");return;}
    if(exportBusy.exchange(true))return;
    const float output=juce::Decibels::decibelsToGain(value("outputDb"));std::array<float,5> levels{};
    for(size_t i=0;i<5;++i)levels[i]=juce::Decibels::decibelsToGain(value(levelIds[i]));
    exports.addJob([this,file,p,output,levels]{
        breakwater::KitSampler render;bool okay=render.load();render.prepare(48000);
        juce::WavAudioFormat wav;std::unique_ptr<juce::AudioFormatWriter> writer;
        if(okay){auto stream=file.createOutputStream();if(stream&&stream->setPosition(0)&&stream->truncate().wasOk())writer.reset(wav.createWriterFor(stream.release(),48000,2,24,{},0));okay=writer!=nullptr;}
        const int64_t length=(int64_t)std::ceil((p.bars*4*60/p.bpm+8)*48000);size_t next=0;juce::AudioBuffer<float> block(2,1024);
        for(int64_t offset=0;okay&&offset<length;offset+=1024){const int count=(int)std::min<int64_t>(1024,length-offset);
            for(int n=0;n<count;++n){const double b=(offset+n)/48000.0*p.bpm/60;while(next<p.events.size()&&p.events[next].beat<b+p.bpm/(60*48000)){const auto& e=p.events[next++];render.trigger(e.piece,e.velocity);}float l,r;render.tick(l,r,levels);block.setSample(0,n,ceiling(l*output));block.setSample(1,n,ceiling(r*output));}
            okay=writer->writeFromAudioSampleBuffer(block,0,count);
        }
        writer.reset();status(okay?"Drum WAV saved. Place it at project bar "+juce::String(p.startBeat/4+1,1)+". Export uses the learned fixed tempo.":"WAV export failed. Check the destination and installed kit.");exportBusy=false;
    });
}
void BreakwaterAudioProcessor::getStateInformation(juce::MemoryBlock& output){
    auto state=parameters.copyState();state.setProperty("schema",1,nullptr);state.setProperty("variation",(int)variation.load(),nullptr);
    breakwater::Guide guide;{const juce::SpinLock::ScopedLockType lock(captureLock);guide=savedGuide;}
    auto p=getPatternSnapshot();juce::ValueTree learned("Guide");learned.setProperty("ticks",guide.ticks,nullptr);learned.setProperty("start",guide.startBeat,nullptr);learned.setProperty("bpm",guide.bpm,nullptr);learned.setProperty("signal",guide.hasSignal,nullptr);
    juce::MemoryOutputStream binary;for(int i=0;i<guide.ticks;++i){binary.writeFloat(guide.accents[(size_t)i]);binary.writeFloat(guide.activity[(size_t)i]);}
    learned.setProperty("data",binary.getMemoryBlock().toBase64Encoding(),nullptr);state.addChild(learned,-1,nullptr);
    juce::ValueTree events("Pattern");events.setProperty("bars",p.bars,nullptr);events.setProperty("start",p.startBeat,nullptr);events.setProperty("bpm",p.bpm,nullptr);
    juce::MemoryOutputStream notes;for(const auto& e:p.events){notes.writeDouble(e.beat);notes.writeInt((int)e.piece);notes.writeFloat(e.velocity);}
    events.setProperty("data",notes.getMemoryBlock().toBase64Encoding(),nullptr);state.addChild(events,-1,nullptr);
    if(auto xml=state.createXml())copyXmlToBinary(*xml,output);
}
void BreakwaterAudioProcessor::setStateInformation(const void* data,int size){
    if(size<=0||size>16*1024*1024)return;auto xml=getXmlFromBinary(data,size);if(!xml)return;auto tree=juce::ValueTree::fromXml(*xml);if(!tree.hasType("BreakwaterState"))return;
    breakwater::Guide guide;auto source=tree.getChildWithName("Guide");guide.ticks=std::clamp((int)source.getProperty("ticks",0),0,breakwater::maxTicks);guide.startBeat=(double)source.getProperty("start",0.0);guide.bpm=(double)source.getProperty("bpm",120.0);guide.hasSignal=(bool)source.getProperty("signal",false);
    if(!std::isfinite(guide.startBeat)||!std::isfinite(guide.bpm)||guide.bpm<20||guide.bpm>400)return;
    juce::MemoryBlock bytes;if(!decodeBounded(bytes,source.getProperty("data").toString(),breakwater::maxTicks*8)||bytes.getSize()!=(size_t)guide.ticks*8)return;
    juce::MemoryInputStream bins(bytes,false);for(int i=0;i<guide.ticks;++i){guide.accents[(size_t)i]=std::clamp(clean(bins.readFloat()),0.f,16.f);guide.activity[(size_t)i]=std::clamp(clean(bins.readFloat()),0.f,16.f);}
    breakwater::Pattern restored;auto events=tree.getChildWithName("Pattern");restored.bars=std::clamp((int)events.getProperty("bars",0),0,breakwater::maxBars);restored.startBeat=(double)events.getProperty("start",0.0);restored.bpm=(double)events.getProperty("bpm",120.0);
    if(!std::isfinite(restored.startBeat)||!std::isfinite(restored.bpm)||restored.bpm<20||restored.bpm>400)return;
    if(!decodeBounded(bytes,events.getProperty("data").toString(),1024*1024)||bytes.getSize()%16)return;
    juce::MemoryInputStream notes(bytes,false);while(!notes.isExhausted()){breakwater::Event e;e.beat=notes.readDouble();e.piece=(breakwater::Piece)notes.readInt();e.velocity=notes.readFloat();if(!std::isfinite(e.beat)||e.beat<0||e.beat>=restored.bars*4||!std::isfinite(e.velocity)||(int)e.piece<0||(int)e.piece>7)return;e.velocity=std::clamp(e.velocity,.01f,1.f);restored.events.push_back(e);}
    std::sort(restored.events.begin(),restored.events.end(),[](const auto& a,const auto& b){return a.beat<b.beat;});
    auto cleaned=parameters.copyState();
    for(auto* base:getParameters())if(auto* parameter=dynamic_cast<juce::RangedAudioParameter*>(base)){
        const auto incoming=tree.getChildWithProperty("id",parameter->paramID);
        if(incoming.isValid()){
            const float v=(float)incoming.getProperty("value");
            if(std::isfinite(v)){auto child=cleaned.getChildWithProperty("id",parameter->paramID);child.setProperty("value",parameter->convertFrom0to1(std::clamp(parameter->convertTo0to1(v),0.f,1.f)),nullptr);}
        }
    }
    parameters.replaceState(cleaned);variation=(uint32_t)(int)tree.getProperty("variation",1);
    listenState=0;preview=false;{const juce::SpinLock::ScopedLockType lock(captureLock);savedGuide=guide;}adoptPattern(std::move(restored));status("Saved drum arrangement restored. Play from its learned project position.");
}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new BreakwaterAudioProcessor();}
