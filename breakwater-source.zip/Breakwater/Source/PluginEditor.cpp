#include "PluginProcessor.h"
#include <algorithm>
#include <cmath>
#include <memory>
#include <vector>

namespace {
const juce::Colour background { 0xff11171c }, panel { 0xff1b242b }, inset { 0xff141c22 };
const juce::Colour edge { 0xff35434c }, ivory { 0xfff2ecdf }, muted { 0xffa1adb3 };
const juce::Colour coral { 0xffef967f }, sea { 0xff94c8bb }, warning { 0xffedb56e };

juce::Font font (float height, bool bold = false)
{
    return juce::Font (height, bold ? juce::Font::bold : juce::Font::plain);
}

void text (juce::Graphics& g, const juce::String& value, juce::Rectangle<int> area,
           float height, juce::Colour colour, bool bold = false,
           juce::Justification alignment = juce::Justification::centredLeft)
{
    g.setFont (font (height, bold));
    g.setColour (colour);
    g.drawText (value, area, alignment);
}

class BreakwaterLookAndFeel final : public juce::LookAndFeel_V4 {
public:
    BreakwaterLookAndFeel()
    {
        setColour (juce::ComboBox::backgroundColourId, inset);
        setColour (juce::ComboBox::textColourId, ivory);
        setColour (juce::ComboBox::outlineColourId, edge);
        setColour (juce::PopupMenu::backgroundColourId, panel);
        setColour (juce::PopupMenu::textColourId, ivory);
        setColour (juce::PopupMenu::highlightedBackgroundColourId, edge);
        setColour (juce::PopupMenu::highlightedTextColourId, coral);
        setColour (juce::TextButton::buttonColourId, inset);
        setColour (juce::TextButton::buttonOnColourId, coral);
        setColour (juce::TextButton::textColourOffId, ivory);
        setColour (juce::TextButton::textColourOnId, ivory);
        setColour (juce::Slider::textBoxTextColourId, ivory);
        setColour (juce::Slider::textBoxBackgroundColourId, inset);
        setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        setColour (juce::Slider::textBoxHighlightColourId, coral.withAlpha (0.3f));
        setColour (juce::Slider::rotarySliderFillColourId, coral);
        setColour (juce::Slider::trackColourId, sea);
        setColour (juce::Label::textColourId, ivory);
        setColour (juce::TooltipWindow::backgroundColourId, inset);
        setColour (juce::TooltipWindow::textColourId, ivory);
        setColour (juce::TooltipWindow::outlineColourId, edge);
    }

    juce::Font getComboBoxFont (juce::ComboBox&) override { return font (12.0f); }
    juce::Font getTextButtonFont (juce::TextButton&, int) override { return font (10.5f, true); }
    juce::Font getLabelFont (juce::Label& label) override { return label.getFont(); }

    juce::Label* createSliderTextBox (juce::Slider& slider) override
    {
        auto* label = juce::LookAndFeel_V4::createSliderTextBox (slider);
        label->getProperties().set ("breakwaterValue", true);
        label->setFont (font (11.0f));
        label->setColour (juce::Label::outlineColourId, juce::Colours::transparentBlack);
        label->setColour (juce::Label::textWhenEditingColourId, ivory);
        label->setColour (juce::Label::backgroundWhenEditingColourId, inset);
        label->setColour (juce::TextEditor::textColourId, ivory);
        label->setColour (juce::TextEditor::backgroundColourId, inset);
        label->setColour (juce::TextEditor::highlightColourId, coral.withAlpha (0.3f));
        return label;
    }

    void drawLabel (juce::Graphics& g, juce::Label& label) override
    {
        if (! static_cast<bool> (label.getProperties()["breakwaterValue"]))
        {
            juce::LookAndFeel_V4::drawLabel (g, label);
            return;
        }
        const auto area = label.getLocalBounds().toFloat().reduced (0.5f);
        g.setColour (inset); g.fillRoundedRectangle (area, 3.5f);
        g.setColour (edge.withAlpha (0.7f)); g.drawRoundedRectangle (area, 3.5f, 1.0f);
        if (! label.isBeingEdited())
            text (g, label.getText(), label.getLocalBounds().reduced (3, 0), 11.0f,
                  ivory.withAlpha (label.isEnabled() ? 1.0f : 0.35f), false, juce::Justification::centred);
    }

    void drawButtonBackground (juce::Graphics& g, juce::Button& button, const juce::Colour&,
                               bool hovered, bool down) override
    {
        const auto area = button.getLocalBounds().toFloat().reduced (0.5f);
        const bool primary = static_cast<bool> (button.getProperties()["primary"]);
        const auto accent = button.findColour (juce::TextButton::buttonOnColourId);
        const float alpha = button.isEnabled() ? 1.0f : 0.3f;
        g.setColour ((primary || button.getToggleState()
                         ? accent.withAlpha (down ? 0.3f : 0.16f)
                         : (hovered ? edge : inset)).withMultipliedAlpha (alpha));
        g.fillRoundedRectangle (area, 6.0f);
        g.setColour ((primary || button.getToggleState() || button.hasKeyboardFocus (true)
                         ? accent : edge).withMultipliedAlpha (alpha));
        g.drawRoundedRectangle (area, 6.0f, 1.0f);
    }

    void drawComboBox (juce::Graphics& g, int width, int height, bool, int, int, int, int,
                       juce::ComboBox& box) override
    {
        const auto area = juce::Rectangle<float> (0.5f, 0.5f, (float) width - 1, (float) height - 1);
        g.setColour (inset); g.fillRoundedRectangle (area, 6.0f);
        g.setColour (box.hasKeyboardFocus (true) ? coral : edge); g.drawRoundedRectangle (area, 6.0f, 1.0f);
        juce::Path chevron;
        const float x = (float) width - 15, y = (float) height * 0.5f;
        chevron.startNewSubPath (x - 3, y - 1); chevron.lineTo (x, y + 2); chevron.lineTo (x + 3, y - 1);
        g.setColour (muted); g.strokePath (chevron, juce::PathStrokeType (1.3f));
    }

    void drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                           float position, float startAngle, float endAngle, juce::Slider& slider) override
    {
        const auto area = juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height).reduced (5.0f);
        const auto centre = area.getCentre();
        const auto radius = juce::jmin (area.getWidth(), area.getHeight()) * 0.5f - 1.0f;
        if (radius <= 0) return;
        const auto accent = slider.findColour (juce::Slider::rotarySliderFillColourId)
                                  .withMultipliedAlpha (slider.isEnabled() ? 1.0f : 0.3f);
        const auto angle = startAngle + position * (endAngle - startAngle);
        juce::Path track, active;
        track.addCentredArc (centre.x, centre.y, radius, radius, 0, startAngle, endAngle, true);
        active.addCentredArc (centre.x, centre.y, radius, radius, 0, startAngle, angle, true);
        g.setColour (edge); g.strokePath (track, juce::PathStrokeType (2.2f));
        g.setColour (accent); g.strokePath (active, juce::PathStrokeType (2.2f));
        const auto disc = juce::Rectangle<float> (radius * 1.56f, radius * 1.56f).withCentre (centre);
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff34434b), centre.x, disc.getY(),
                                               juce::Colour (0xff202b32), centre.x, disc.getBottom(), false));
        g.fillEllipse (disc); g.setColour (edge.brighter (0.15f)); g.drawEllipse (disc, 1.0f);
        g.setColour (accent);
        g.drawLine (centre.x + std::sin (angle) * radius * 0.35f,
                    centre.y - std::cos (angle) * radius * 0.35f,
                    centre.x + std::sin (angle) * radius * 0.62f,
                    centre.y - std::cos (angle) * radius * 0.62f, 2.0f);
        if (slider.hasKeyboardFocus (true)) { g.setColour (accent); g.drawEllipse (disc.expanded (3), 1.0f); }
    }

    void drawLinearSlider (juce::Graphics& g, int x, int y, int width, int height,
                           float position, float, float, juce::Slider::SliderStyle,
                           juce::Slider& slider) override
    {
        const float cy = (float) y + (float) height * 0.5f;
        g.setColour (edge); g.drawLine ((float) x, cy, (float) (x + width), cy, 3.0f);
        g.setColour (slider.findColour (juce::Slider::trackColourId)
                          .withMultipliedAlpha (slider.isEnabled() ? 1.0f : 0.3f));
        g.drawLine ((float) x, cy, position, cy, 3.0f);
        g.fillEllipse (position - 3.5f, cy - 3.5f, 7.0f, 7.0f);
    }
};

class ParameterControl final : public juce::Component {
public:
    enum class Kind { Rotary, Horizontal, Number };
    ParameterControl (juce::AudioProcessorValueTreeState& state, const char* id,
                      const char* title, const char* unit, const char* tip, Kind mode = Kind::Rotary)
        : kind (mode)
    {
        auto* parameter = state.getParameter (id);
        jassert (parameter != nullptr);
        const auto accessibleName = parameter->getName (128);
        setName (accessibleName);
        label.setText (title, juce::dontSendNotification);
        label.setFont (font (9.0f, true));
        label.setColour (juce::Label::textColourId, muted);
        label.setJustificationType (kind == Kind::Rotary ? juce::Justification::centred : juce::Justification::centredLeft);
        label.setBorderSize (juce::BorderSize<int> (0));
        label.setInterceptsMouseClicks (false, false);
        slider.setName (accessibleName); slider.setTitle (accessibleName);
        slider.setDescription (tip);
        slider.setTooltip (juce::String (tip) + " Double-click to reset; type a value for precision.");
        slider.setWantsKeyboardFocus (true);
        slider.setSliderStyle (kind == Kind::Rotary ? juce::Slider::RotaryHorizontalVerticalDrag
                              : kind == Kind::Number ? juce::Slider::IncDecButtons : juce::Slider::LinearHorizontal);
        slider.setTextBoxStyle (kind == Kind::Rotary ? juce::Slider::TextBoxBelow : juce::Slider::TextBoxRight,
                                false, kind == Kind::Number ? 72 : kind == Kind::Horizontal ? 68 : 58, 20);
        slider.setDoubleClickReturnValue (true, parameter->convertFrom0to1 (parameter->getDefaultValue()));
        addAndMakeVisible (label); addAndMakeVisible (slider);
        attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (state, id, slider);
        const juce::String suffix (unit);
        const int decimals = juce::String (id) == "bpm" ? 2 : suffix == " dB" ? 1 : 0;
        slider.textFromValueFunction = [suffix, decimals] (double v) {
            return juce::String (v, decimals) + suffix;
        };
        slider.valueFromTextFunction = [] (const juce::String& v) { return v.getDoubleValue(); };
        slider.updateText();
    }
    void resized() override
    {
        auto area = getLocalBounds(); label.setBounds (area.removeFromTop (14)); slider.setBounds (area);
    }
    juce::Slider slider;
private:
    Kind kind;
    juce::Label label;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
};

class PatternView final : public juce::Component {
public:
    explicit PatternView (BreakwaterAudioProcessor& p) : processor (p)
    {
        setName ("Drum pattern preview");
        setDescription ("Four-bar view of the generated drum part. Lanes show kick, snare, hats, toms and cymbals. This is a preview, not a note editor.");
    }
    void refresh()
    {
        pattern = processor.getPatternSnapshot();
        firstBar = juce::jlimit (0, juce::jmax (0, ((pattern.bars - 1) / 4) * 4), firstBar);
        repaint();
    }
    void movePage (int direction) { firstBar = juce::jlimit (0, juce::jmax (0, ((pattern.bars - 1) / 4) * 4), firstBar + direction * 4); repaint(); }
    bool hasPrevious() const { return firstBar > 0; }
    bool hasNext() const { return firstBar + 4 < pattern.bars; }
    juce::String pageDescription() const
    {
        if (pattern.bars <= 0) return "NO PART YET";
        return "BARS " + juce::String (firstBar + 1) + "-" + juce::String (juce::jmin (firstBar + 4, pattern.bars))
               + " / " + juce::String (pattern.bars);
    }
    void paint (juce::Graphics& g) override
    {
        const int left = 80, top = 23, laneHeight = 25;
        const float gridWidth = (float) (getWidth() - left - 10);
        const char* lanes[] { "KICK", "SNARE", "HATS", "TOMS", "CYMBALS" };
        const juce::Colour colours[] { coral, ivory, sea, warning, juce::Colour (0xffb9add9) };
        for (int lane = 0; lane < 5; ++lane)
        {
            const int y = top + lane * laneHeight;
            text (g, lanes[lane], { 0, y, left - 12, laneHeight }, 9.0f, muted, true);
            g.setColour ((lane % 2 == 0 ? inset : background).withAlpha (0.6f));
            g.fillRect ((float) left, (float) y, gridWidth, (float) laneHeight - 1);
        }
        const int projectBar = (int) std::floor (pattern.startBeat / 4.0) + firstBar + 1;
        for (int beat = 0; beat <= 16; ++beat)
        {
            const float x = (float) left + (float) beat * gridWidth / 16.0f;
            g.setColour (edge.withAlpha (beat % 4 == 0 ? 0.85f : 0.35f));
            g.drawVerticalLine ((int) x, (float) top, (float) (top + laneHeight * 5));
            if (beat % 4 == 0 && beat < 16)
                text (g, pattern.bars > 0 ? juce::String (projectBar + beat / 4) : juce::String (beat / 4 + 1),
                      { (int) x + 7, 0, 100, 18 }, 9.0f, muted, true);
        }
        if (pattern.events.empty())
        {
            text (g, "Your drum part will appear here", { left, top + 36, (int) gridWidth, 28 }, 17.0f, ivory,
                  false, juce::Justification::centred);
            text (g, "Listen to a recorded riff, then Finish & Generate.", { left, top + 66, (int) gridWidth, 20 }, 11.0f, muted,
                  false, juce::Justification::centred);
            return;
        }
        for (const auto& event : pattern.events)
        {
            const double position = event.beat - (double) firstBar * 4.0;
            if (position < 0 || position >= 16) continue;
            const int piece = (int) event.piece;
            const int lane = piece < 2 ? piece : piece < 4 ? 2 : piece < 6 ? 3 : 4;
            const float velocity = juce::jlimit (0.0f, 1.0f, event.velocity);
            const float height = 7 + velocity * 12;
            const float x = (float) left + (float) position * gridWidth / 16.0f;
            const float y = (float) (top + lane * laneHeight) + ((float) laneHeight - height) * 0.5f;
            g.setColour (colours[lane].withAlpha (0.45f + velocity * 0.55f));
            g.fillRoundedRectangle (x, y, 5.0f, height, 1.5f);
        }
        if (processor.hostPlaying.load())
        {
            const double position = processor.currentBeat.load() - pattern.startBeat - (double) firstBar * 4.0;
            if (position >= 0 && position < 16)
            {
                g.setColour (ivory.withAlpha (0.8f));
                const float x = (float) left + (float) position * gridWidth / 16.0f;
                g.drawLine (x, (float) top, x, (float) (top + laneHeight * 5), 1.2f);
            }
        }
    }
private:
    BreakwaterAudioProcessor& processor;
    breakwater::Pattern pattern;
    int firstBar = 0;
};

class BreakwaterEditor final : public juce::AudioProcessorEditor, private juce::Timer {
public:
    explicit BreakwaterEditor (BreakwaterAudioProcessor& p)
        : juce::AudioProcessorEditor (p), engine (p), tooltip (this, 650), pattern (p)
    {
        setLookAndFeel (&look); tooltip.setLookAndFeel (&look);
        addAndMakeVisible (canvas);
        canvas.onPaint = [this] (juce::Graphics& g) { paintInterface (g); };
        add (pattern);
        choice (style, "style", "Style", "Choose the broad playing vocabulary. Click Update after changing the feel.");
        choice (section, "section", "Section", "Auto dynamics follows the guide energy. Verse, Chorus and Breakdown set a consistent section approach.");
        makeControl ("complexity", "COMPLEXITY", "%", "Amount of rhythmic detail in the generated part.");
        makeControl ("intensity", "INTENSITY", "%", "How hard the drummer plays and how strongly accents land.");
        makeControl ("follow", "FOLLOW RIFF", "%", "How strongly kick accents follow the recorded guitar or bass guide.");
        makeControl ("doubleKick", "DOUBLE KICK", "%", "Amount of faster kick activity in suitable parts.");
        makeControl ("fills", "FILLS", "%", "Amount of drum fills around phrase boundaries.");
        makeControl ("humanize", "HUMAN FEEL", "%", "Small variations in hit timing and strength.");
        makeControl ("bpm", "IMPORT / FALLBACK BPM", "", "Set this to the project tempo before importing a guide. Listening uses host tempo when supplied. Use a constant tempo in 4/4.", ParameterControl::Kind::Number);
        makeControl ("startBar", "IMPORT START BAR", "", "Project bar where an imported guide starts. Bar 1 is the beginning of the project.", ParameterControl::Kind::Number);
        makeControl ("dryMix", "LISTEN MONITOR", "%", "Reference audio heard while listening. Keep this at zero when the original track is already audible.", ParameterControl::Kind::Horizontal);
        makeControl ("outputDb", "DRUM OUTPUT", " dB", "Final drum output level. Leave headroom in the project.", ParameterControl::Kind::Horizontal);
        makeControl ("kickDb", "KICK", " dB", "Kick drum level.");
        makeControl ("snareDb", "SNARE", " dB", "Snare drum level.");
        makeControl ("hatDb", "HATS", " dB", "Closed and open hi-hat level.");
        makeControl ("tomDb", "TOMS", " dB", "High and low tom level.");
        makeControl ("cymbalDb", "CYMBALS", " dB", "Crash and ride cymbal level.");
        toggle (triplet, "triplet", "TRIPLET FEEL", "Use triplet-based divisions in the generated part.");
        toggle (respectGaps, "respectGaps", "RESPECT RIFF GAPS", "Keep breathing room where the recorded guide has gaps.");
        toggle (enabled, "enabled", "DRUMS ON", "Turn drum playback on or off.");
        enabled.setColour (juce::TextButton::buttonOnColourId, sea);
        action (listen, "LISTEN", "Arm guide capture, then play the project. Use a duplicated guitar/bass audio track so the original stays audible.",
                [this] { engine.beginListen(); refresh(); });
        listen.getProperties().set ("primary", true);
        action (finish, "FINISH & GENERATE", "Finish recording the guide and generate a drum part from its rhythm and dynamics.",
                [this] { engine.finishAndGenerate(); refreshPattern(); });
        finish.getProperties().set ("primary", true);
        action (import, "IMPORT WAV", "Import a recorded guide instead of listening. First set its BPM and project start bar.", [this] { chooseFile (0); });
        action (preview, "PREVIEW", "Audition the generated drums locally while project playback is stopped.",
                [this] { engine.setPreview (! engine.isPreviewing()); refresh(); });
        preview.setColour (juce::TextButton::buttonOnColourId, sea);
        action (update, "UPDATE", "Rebuild the part from your recorded guide with the current style and feel controls.",
                [this] { engine.generatePattern (false); refreshPattern(); });
        action (variation, "NEW VARIATION", "Generate another take with the same guide and settings.",
                [this] { engine.generatePattern (true); refreshPattern(); });
        action (exportMidi, "EXPORT MIDI", "Save the generated notes as a MIDI file for a drum instrument or further editing.", [this] { chooseFile (1); });
        action (exportWav, "EXPORT WAV", "Render the drum part to a WAV file using the current kit mix.", [this] { chooseFile (2); });
        exportWav.getProperties().set ("primary", true);
        action (previous, "<", "Show the previous four bars.", [this] { pattern.movePage (-1); refresh(); });
        action (next, ">", "Show the next four bars.", [this] { pattern.movePage (1); refresh(); });
        previous.setName ("Previous four bars"); next.setName ("Next four bars");
        status.setFont (font (10.5f)); status.setColour (juce::Label::textColourId, muted);
        status.setBorderSize (juce::BorderSize<int> (0)); status.setName ("Breakwater status");
        status.setJustificationType (juce::Justification::centredLeft); add (status);
        setOpaque (true); setResizable (true, true);
        setResizeLimits (952, 646, 1568, 1064);
        getConstrainer()->setFixedAspectRatio (1120.0 / 760.0);
        setSize (1120, 760);
        refreshPattern(); startTimerHz (20);
    }

    ~BreakwaterEditor() override
    {
        stopTimer(); chooser.reset(); tooltip.setLookAndFeel (nullptr); setLookAndFeel (nullptr);
    }

    void paint (juce::Graphics& g) override { g.fillAll (background); }
    void resized() override
    {
        const float scale = juce::jmin ((float) getWidth() / 1120.0f, (float) getHeight() / 760.0f);
        canvas.setTransform (juce::AffineTransform::scale (scale)); canvas.setBounds (0, 0, 1120, 760);
        listen.setBounds (44, 174, 112, 38); finish.setBounds (166, 174, 176, 38);
        import.setBounds (352, 174, 116, 38); preview.setBounds (478, 174, 112, 38);
        control ("bpm").setBounds (606, 165, 136, 47); control ("startBar").setBounds (760, 165, 132, 47);
        enabled.setBounds (920, 174, 156, 38);
        style.setBounds (44, 295, 172, 31); section.setBounds (230, 295, 188, 31);
        update.setBounds (432, 295, 112, 31); variation.setBounds (558, 295, 146, 31);
        const char* feel[] { "complexity", "intensity", "follow", "doubleKick", "fills", "humanize" };
        for (int i = 0; i < 6; ++i) control (feel[i]).setBounds (40 + i * 111, 339, 105, 86);
        triplet.setBounds (44, 435, 160, 25); respectGaps.setBounds (216, 435, 192, 25);
        const char* pieces[] { "kickDb", "snareDb", "hatDb", "tomDb", "cymbalDb" };
        for (int i = 0; i < 5; ++i) control (pieces[i]).setBounds (752 + i * 66, 291, 64, 91);
        control ("outputDb").setBounds (760, 391, 316, 32); control ("dryMix").setBounds (760, 432, 316, 32);
        pattern.setBounds (44, 539, 1032, 150);
        previous.setBounds (830, 501, 30, 26); next.setBounds (1046, 501, 30, 26);
        status.setBounds (26, 718, 736, 31);
        exportMidi.setBounds (788, 718, 140, 31); exportWav.setBounds (944, 718, 152, 31);
    }

private:
    class Canvas final : public juce::Component {
    public:
        std::function<void (juce::Graphics&)> onPaint;
        void paint (juce::Graphics& g) override { if (onPaint) onPaint (g); }
    };
    void add (juce::Component& component) { canvas.addAndMakeVisible (component); }
    void action (juce::TextButton& button, const char* title, const char* tip, std::function<void()> callback)
    {
        button.setButtonText (title); button.setName (title); button.setTooltip (tip);
        button.setWantsKeyboardFocus (true); button.onClick = std::move (callback); add (button);
    }
    void toggle (juce::TextButton& button, const char* id, const char* title, const char* tip)
    {
        button.setButtonText (title); button.setName (engine.parameters.getParameter (id)->getName (128));
        button.setTooltip (tip); button.setClickingTogglesState (true); button.setWantsKeyboardFocus (true); add (button);
        buttonAttachments.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (engine.parameters, id, button));
    }
    void choice (juce::ComboBox& box, const char* id, const char* title, const char* tip)
    {
        auto* parameter = dynamic_cast<juce::AudioParameterChoice*> (engine.parameters.getParameter (id));
        jassert (parameter != nullptr);
        if (parameter != nullptr) box.addItemList (parameter->choices, 1);
        box.setName (title); box.setTitle (title); box.setTooltip (tip); box.setDescription (tip);
        box.setWantsKeyboardFocus (true); add (box);
        comboAttachments.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (engine.parameters, id, box));
    }
    void makeControl (const char* id, const char* title, const char* unit, const char* tip,
                      ParameterControl::Kind kind = ParameterControl::Kind::Rotary)
    {
        auto item = std::make_unique<ParameterControl> (engine.parameters, id, title, unit, tip, kind);
        add (*item); controlIds.emplace_back (id); controls.push_back (std::move (item));
    }
    ParameterControl& control (const juce::String& id)
    {
        for (size_t i = 0; i < controlIds.size(); ++i) if (controlIds[i] == id) return *controls[i];
        jassertfalse; return *controls.front();
    }
    void card (juce::Graphics& g, juce::Rectangle<float> area)
    {
        g.setColour (juce::Colours::black.withAlpha (0.15f)); g.fillRoundedRectangle (area.translated (0, 3), 9);
        g.setColour (panel); g.fillRoundedRectangle (area, 9);
        g.setColour (edge.withAlpha (0.8f)); g.drawRoundedRectangle (area.reduced (0.5f), 9, 1);
    }
    void heading (juce::Graphics& g, const char* number, const char* title, int x, int y, int width)
    {
        text (g, number, { x, y, 24, 22 }, 10, coral, true);
        text (g, title, { x + 30, y, width - 30, 22 }, 13, ivory, true);
    }
    void meter (juce::Graphics& g, int x, int y, float level, const char* title)
    {
        text (g, title, { x, y - 2, 26, 14 }, 8, muted);
        const float normal = juce::jlimit (0.0f, 1.0f, (juce::Decibels::gainToDecibels (level, -60.0f) + 60.0f) / 60.0f);
        for (int i = 0; i < 22; ++i)
        {
            g.setColour ((float) i / 22.0f < normal ? (i > 19 ? coral : sea) : edge);
            g.fillRect (x + 30 + i * 5, y, 3, 9);
        }
    }
    void paintInterface (juce::Graphics& g)
    {
        g.fillAll (background);
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff24323b), 0, 0, background, 700, 180, false));
        g.fillRect (0, 0, 1120, 88);
        juce::Path mark;
        mark.startNewSubPath (28, 50); mark.lineTo (38, 33); mark.lineTo (48, 50); mark.lineTo (58, 33); mark.lineTo (68, 50);
        mark.startNewSubPath (28, 59); mark.lineTo (68, 59);
        g.setColour (coral); g.strokePath (mark, juce::PathStrokeType (2.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        text (g, "BREAKWATER", { 84, 25, 338, 35 }, 29, ivory, true);
        text (g, "RECORDED-GUIDE DRUMMER", { 86, 61, 338, 16 }, 9, muted, true);
        text (g, engine.isKitReady() ? "RECORDED DRUM KIT READY" : "DRUM KIT MISSING - REINSTALL THE PACKAGE",
              { 670, 29, 426, 18 }, 10, engine.isKitReady() ? sea : coral, true, juce::Justification::centredRight);
        text (g, juce::String ("4/4 HOST GRID  /  ") + juce::String (engine.currentBpm.load(), 1)
              + " BPM  /  CONSTANT TEMPO  /  v" + JucePlugin_VersionString,
              { 660, 55, 436, 16 }, 9, muted, false, juce::Justification::centredRight);
        card (g, { 24, 100, 1072, 134 }); card (g, { 24, 250, 700, 220 });
        card (g, { 740, 250, 356, 220 }); card (g, { 24, 486, 1072, 218 });
        heading (g, "01", "FOLLOW YOUR RIFF", 44, 114, 330);
        const int listening = engine.listenState.load();
        juce::String captureText = listening == 1 ? "ARMED - PRESS PLAY IN YOUR DAW"
                                : listening == 2 ? "LISTENING  /  " + juce::String (engine.learnedBars.load()) + " BARS"
                                : listening == 3 ? "GUIDE READY - FINISH & GENERATE"
                                : engine.hasGuide() ? "GUIDE CAPTURED" : "READY TO LISTEN";
        text (g, captureText, { 490, 116, 400, 17 }, 10, listening > 0 ? coral : sea, true, juce::Justification::centredRight);
        meter (g, 932, 118, inputMeter, "IN");
        text (g, "Duplicate guitar/bass regions onto a new audio track, insert Breakwater, then Listen and play the project.",
              { 44, 141, 1032, 17 }, 11, muted);
        heading (g, "02", "SHAPE THE PART", 44, 262, 330);
        text (g, "STYLE", { 44, 280, 172, 13 }, 8.5f, muted, true);
        text (g, "SECTION", { 230, 280, 188, 13 }, 8.5f, muted, true);
        text (g, "ADJUST THE FEEL, THEN UPDATE", { 432, 280, 272, 13 }, 8.5f, muted, false, juce::Justification::centredRight);
        text (g, "4/4 grid; no automatic tempo detection.", { 426, 438, 278, 19 }, 9, muted, false, juce::Justification::centredRight);
        heading (g, "03", "KIT MIX", 760, 262, 200);
        meter (g, 932, 270, outputMeter, "OUT");
        heading (g, "04", "YOUR DRUM PART", 44, 501, 310);
        const int count = engine.eventCount.load();
        text (g, count > 0 ? juce::String (count) + " HITS  /  PLAY THE PROJECT TO HEAR THE PART" : "PROJECT-ALIGNED PLAYBACK",
              { 300, 504, 510, 16 }, 9, muted, false, juce::Justification::centredRight);
        text (g, pattern.pageDescription(), { 866, 501, 174, 26 }, 9.5f, ivory, true, juce::Justification::centred);
    }
    void refreshPattern() { pattern.refresh(); refresh(); }
    void refresh()
    {
        const int listening = engine.listenState.load();
        const bool recording = listening == 1 || listening == 2;
        const bool pendingGuide = listening > 0;
        const bool busy = engine.exportBusy.load();
        const bool hasPart = engine.eventCount.load() > 0;
        listen.setEnabled (! recording && ! busy && chooser == nullptr);
        listen.setButtonText (listening == 1 ? "ARMED" : listening == 2 ? "LISTENING" : "LISTEN");
        finish.setEnabled (listening > 0 && ! busy);
        import.setEnabled (! pendingGuide && ! busy && chooser == nullptr);
        preview.setEnabled (engine.isPreviewing() || (hasPart && engine.isKitReady() && ! engine.hostPlaying.load() && ! pendingGuide && ! busy));
        preview.setToggleState (engine.isPreviewing(), juce::dontSendNotification);
        preview.setButtonText (engine.isPreviewing() ? "STOP PREVIEW" : "PREVIEW");
        update.setEnabled (engine.hasGuide() && ! pendingGuide && ! busy);
        variation.setEnabled (engine.hasGuide() && ! pendingGuide && ! busy);
        exportMidi.setEnabled (hasPart && ! pendingGuide && ! busy && chooser == nullptr);
        exportWav.setEnabled (hasPart && engine.isKitReady() && ! pendingGuide && ! busy && chooser == nullptr);
        exportWav.setButtonText (busy ? "RENDERING..." : "EXPORT WAV");
        enabled.setButtonText (enabled.getToggleState() ? "DRUMS ON" : "DRUMS OFF");
        control ("bpm").setEnabled (! pendingGuide && ! busy);
        control ("startBar").setEnabled (! pendingGuide && ! busy);
        previous.setEnabled (pattern.hasPrevious()); next.setEnabled (pattern.hasNext());
        status.setText (engine.getStatus(), juce::dontSendNotification);
        inputMeter = juce::jmax (engine.inputPeak.load(), inputMeter * 0.84f);
        outputMeter = juce::jmax (engine.outputPeak.load(), outputMeter * 0.84f);
        canvas.repaint(); pattern.repaint();
    }
    void timerCallback() override
    {
        if (++ticks % 5 == 0) pattern.refresh();
        refresh();
    }
    void chooseFile (int kind)
    {
        if (chooser != nullptr) return;
        const bool importing = kind == 0;
        const auto defaultFile = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory)
                                     .getChildFile (kind == 1 ? "Breakwater.mid" : "Breakwater.wav");
        chooser = std::make_unique<juce::FileChooser> (importing ? "Import recorded guitar or bass guide"
                          : kind == 1 ? "Export Breakwater MIDI" : "Export Breakwater drum audio",
                          importing ? juce::File{} : defaultFile,
                          importing ? "*.wav;*.aif;*.aiff" : kind == 1 ? "*.mid" : "*.wav", true);
        const int flags = importing ? juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles
                                    : juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles
                                      | juce::FileBrowserComponent::warnAboutOverwriting;
        juce::Component::SafePointer<BreakwaterEditor> safe (this);
        chooser->launchAsync (flags, [safe, kind] (const juce::FileChooser& dialog) {
            if (safe == nullptr) return;
            auto file = dialog.getResult();
            if (file != juce::File{})
            {
                if (kind == 0) safe->engine.importGuide (file);
                if (kind == 1) safe->engine.exportMidi (file);
                if (kind == 2) safe->engine.exportAudio (file);
                safe->refreshPattern();
            }
            juce::MessageManager::callAsync ([safe] { if (safe != nullptr) { safe->chooser.reset(); safe->refresh(); } });
        });
        refresh();
    }

    BreakwaterAudioProcessor& engine;
    BreakwaterLookAndFeel look;
    juce::TooltipWindow tooltip;
    Canvas canvas;
    PatternView pattern;
    juce::ComboBox style, section;
    juce::TextButton listen, finish, import, preview, update, variation, enabled, triplet, respectGaps;
    juce::TextButton exportMidi, exportWav, previous, next;
    juce::Label status;
    std::vector<juce::String> controlIds;
    std::vector<std::unique_ptr<ParameterControl>> controls;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAttachments;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAttachments;
    std::unique_ptr<juce::FileChooser> chooser;
    float inputMeter = 0, outputMeter = 0;
    int ticks = 0;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (BreakwaterEditor)
};
} // namespace

juce::AudioProcessorEditor* BreakwaterAudioProcessor::createEditor()
{
    return new BreakwaterEditor (*this);
}
