#include "KitSampler.h"
#include <cmath>
namespace breakwater {
juce::File KitSampler::findKitDirectory() {
    auto location=juce::File::getSpecialLocation(juce::File::currentExecutableFile).getParentDirectory();
    for(int depth=0;depth<5;++depth) {
        const auto kit=location.getChildFile("Resources/Kit");
        if(kit.getChildFile("kick_v1_r1.wav").existsAsFile())return kit;
        location=location.getParentDirectory();
    }
    return {};
}
bool KitSampler::load() {
    reset(); for(auto& bank:samples)bank.clear();
    const auto directory=findKitDirectory(); if(!directory.isDirectory())return false;
    const char* prefixes[]={"kick","snare","hat_closed","hat_open","tom_high","tom_low","crash","ride"};
    juce::AudioFormatManager formats;formats.registerBasicFormats();
    for(int p=0;p<8;++p)for(int layer=1;layer<=3;++layer) {
        auto file=directory.getChildFile(juce::String(prefixes[p])+"_v"+juce::String(layer)+"_r1.wav");
        std::unique_ptr<juce::AudioFormatReader> reader(formats.createReaderFor(file));
        if(!reader || reader->lengthInSamples<=0 || reader->lengthInSamples>reader->sampleRate*15)return false;
        const int length=(int)reader->lengthInSamples;
        juce::AudioBuffer<float> buffer(2,length);
        if(!reader->read(&buffer,0,length,0,true,true))return false;
        Sample sample;sample.rate=reader->sampleRate;sample.layer=layer;
        sample.left.assign(buffer.getReadPointer(0),buffer.getReadPointer(0)+length);
        const auto* right=buffer.getReadPointer(reader->numChannels>1?1:0);
        sample.right.assign(right,right+length);
        samples[(size_t)p].push_back(std::move(sample));
    }
    return true;
}
void KitSampler::reset() noexcept {for(auto& voice:voices)voice={};roundRobin.fill(0);clock=0;}
void KitSampler::trigger(Piece piece,float velocity) noexcept {
    const int p=std::clamp((int)piece,0,7);const auto& bank=samples[(size_t)p];if(bank.empty())return;
    velocity=std::isfinite(velocity)?std::clamp(velocity,.01f,1.f):.7f;
    const int layer=velocity<.42f?0:(velocity<.76f?1:2);
    // Closing the hi-hat chokes its open articulation, as on a physical kit.
    if(p==2)for(auto& v:voices)if(v.piece==3)v.sample=nullptr;
    auto* voice=&voices[0];
    for(auto& v:voices) {if(v.sample==nullptr){voice=&v;break;}if(v.age<voice->age)voice=&v;}
    const auto& sample=bank[std::min((size_t)layer,bank.size()-1)];
    // Velocity layers are real recordings. No invented round-robin claim.
    *voice={&sample,0,sample.rate/rate,.45f*(.35f+.65f*velocity),p,++clock};
}
void KitSampler::tick(float& left,float& right,const std::array<float,5>& levels) noexcept {
    left=right=0;
    static constexpr int group[]={0,1,2,2,3,3,4,4};
    static constexpr float pan[]={0,0,-.22f,-.22f,-.28f,.30f,-.32f,.32f};
    for(auto& v:voices)if(v.sample) {
        const auto& s=*v.sample;const auto i=(size_t)v.position;
        if(i+1>=s.left.size()){v.sample=nullptr;continue;}
        const float f=(float)(v.position-(double)i);
        const float l=s.left[i]+f*(s.left[i+1]-s.left[i]);
        const float r=s.right[i]+f*(s.right[i+1]-s.right[i]);
        const float gain=v.gain*levels[(size_t)group[v.piece]];
        left+=l*gain*std::sqrt(.5f*(1-pan[v.piece]));
        right+=r*gain*std::sqrt(.5f*(1+pan[v.piece]));
        v.position+=v.step;
    }
}
}
