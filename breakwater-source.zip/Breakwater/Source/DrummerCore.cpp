#include "DrummerCore.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>

namespace breakwater {
namespace {
constexpr int barTicks = 4 * ticksPerBeat;
constexpr int pieceCount = static_cast<int>(Piece::Count);
float unit(float value, float fallback = 0) noexcept {
    return std::isfinite(value) ? std::clamp(value, 0.0f, 1.0f) : fallback;
}
float finitePositive(float value) noexcept {
    return std::isfinite(value) ? std::clamp(value, 0.0f, 8.0f) : 0.0f;
}
double validTempo(double bpm) noexcept {
    return std::isfinite(bpm) ? std::clamp(bpm, 20.0, 400.0) : 120.0;
}
// Keyed random values make each decision repeatable and keep later phrases
// stable when an earlier hit is removed. No runtime/global RNG is involved.
uint32_t hash(uint32_t x) noexcept {
    x ^= x >> 16; x *= 0x7feb352du; x ^= x >> 15; x *= 0x846ca68bu; return x ^ (x >> 16);
}
float randomAt(uint32_t seed, int position, int stream) noexcept {
    return (hash(seed ^ (static_cast<uint32_t>(position) * 0x9e3779b9u)
        ^ (static_cast<uint32_t>(stream) * 0x85ebca6bu)) >> 8) * (1.0f / 16777216.0f);
}
struct Hit { float velocity = 0, priority = 0; };
struct TimedHit { double beat; Piece piece; float velocity, priority; };
bool cymbal(Piece p) noexcept {
    return p == Piece::HatClosed || p == Piece::HatOpen || p == Piece::Crash || p == Piece::Ride;
}
} // namespace

void GuideAnalyser::prepare(double sampleRate) noexcept {
    rate = std::isfinite(sampleRate) ? std::clamp(sampleRate, 8000.0, 384000.0) : 48000.0;
    begin(0, 120);
}
void GuideAnalyser::begin(double startBeat, double bpm) noexcept {
    guide = Guide{};
    guide.startBeat = std::isfinite(startBeat) ? startBeat : 0;
    guide.bpm = validTempo(bpm);
    envelope = previous = fast = slow = previousInput = 0;
    lastBeat = -std::numeric_limits<double>::infinity();
}
void GuideAnalyser::process(float mono, double absoluteBeat) noexcept {
    if (!std::isfinite(absoluteBeat) || absoluteBeat < guide.startBeat || absoluteBeat < lastBeat) return;
    const double relativeTick = (absoluteBeat - guide.startBeat) * ticksPerBeat;
    if (!std::isfinite(relativeTick) || relativeTick >= maxTicks) return;
    const int tick = static_cast<int>(relativeTick);
    if (absoluteBeat - lastBeat > 1.0 / ticksPerBeat) envelope = previous = fast = slow = previousInput = 0;
    lastBeat = absoluteBeat;
    const float x = std::isfinite(mono) ? std::clamp(mono, -4.0f, 4.0f) : 0.0f;
    const float level = std::abs(x);
    // Cheap sample-rate-scaled followers require neither allocation nor exp()
    // in the sample loop. Activity falls fast enough to retain musical rests.
    const float fastCoefficient = static_cast<float>(1.0 / (1.0 + rate * .0015));
    const float slowCoefficient = static_cast<float>(1.0 / (1.0 + rate * .045));
    const float activityCoefficient = static_cast<float>(1.0 / (1.0 + rate * (level > envelope ? .002 : .020)));
    fast += fastCoefficient * (level - fast);
    slow += slowCoefficient * (level - slow);
    envelope += activityCoefficient * (level - envelope);
    const float rise = std::max(0.0f, fast - previous);
    const float onset = std::max(0.0f, fast - 1.18f * slow) + rise * 4.0f;
    previous = fast; previousInput = x;
    guide.accents[tick] = std::max(guide.accents[tick], onset);
    guide.activity[tick] = std::max(guide.activity[tick], envelope);
    guide.ticks = std::max(guide.ticks, tick + 1);
    guide.hasSignal = guide.hasSignal || envelope > .0001f;
    if (std::abs(fast) < 1e-20f) fast = 0;
    if (std::abs(slow) < 1e-20f) slow = 0;
    if (std::abs(envelope) < 1e-20f) envelope = 0;
}

Pattern generate(const Guide& guide, const Settings& input) {
    Pattern result;
    result.startBeat = std::isfinite(guide.startBeat) ? guide.startBeat : 0;
    result.bpm = validTempo(guide.bpm);
    const int count = std::clamp(guide.ticks, 0, maxTicks);
    result.bars = (count + barTicks - 1) / barTicks;
    if (!guide.hasSignal || count == 0) return result;
    const int style = std::clamp(input.style, 0, 3), section = std::clamp(input.section, 0, 3);
    const float complexity = unit(input.complexity,.55f), intensity = unit(input.intensity,.7f);
    const float follow = unit(input.follow,.75f), doubles = unit(input.doubleKick,.35f);
    const float fills = unit(input.fills,.5f), human = unit(input.humanize,.3f);
    const uint32_t seed = input.seed ^ (static_cast<uint32_t>(style) * 0x27d4eb2du);
    float accentMaximum = 0, activityMaximum = 0;
    for (int t = 0; t < count; ++t) {
        accentMaximum = std::max(accentMaximum, finitePositive(guide.accents[t]));
        activityMaximum = std::max(activityMaximum, finitePositive(guide.activity[t]));
    }
    if (std::max(accentMaximum,activityMaximum) < .00001f) return result;
    std::vector<float> accents(count), activity(count), peaks(count);
    std::vector<unsigned char> active(count);
    for (int t = 0; t < count; ++t) {
        accents[t] = finitePositive(guide.accents[t]) / std::max(.00001f,accentMaximum);
        activity[t] = finitePositive(guide.activity[t]) / std::max(.00001f,activityMaximum);
        active[t] = (activity[t] > .055f || accents[t] > .12f) ? 1 : 0;
    }
    // Close only short holes (at most one third of a beat), preserving long
    // stops while not mistaking the space between palm-muted strokes for rests.
    int preceding = -1;
    for (int t = 0; t < count; ++t) if (active[t]) {
        if (preceding >= 0 && t - preceding <= 9)
            for (int k = preceding + 1; k < t; ++k) active[k] = 1;
        preceding = t;
    }
    int previousPeak = -100;
    for (int t = 0; t < count; ++t) {
        const float left = t ? accents[t-1] : 0, right = t+1<count ? accents[t+1] : 0;
        if (accents[t] > .12f && accents[t] >= left && accents[t] > right) {
            if (t - previousPeak >= 3) { peaks[t] = accents[t]; previousPeak = t; }
            else if (accents[t] > peaks[previousPeak]) { peaks[previousPeak] = 0; peaks[t] = accents[t]; previousPeak = t; }
        }
    }
    std::vector<int> sections(result.bars, section ? section : 1);
    std::vector<float> energy(result.bars);
    for (int bar = 0; bar < result.bars; ++bar) {
        float sum = 0, peakSum = 0; int onsetCount = 0;
        const int end = std::min(count,(bar+1)*barTicks);
        for (int t=bar*barTicks;t<end;++t) { sum+=activity[t];peakSum+=peaks[t];if(peaks[t]>.25f)++onsetCount; }
        const float mean = sum / std::max(1,end-bar*barTicks);
        energy[bar] = .65f*std::sqrt(mean)+.35f*std::min(1.0f,peakSum/8.0f);
        if (section == 0) {
            const int suggested = energy[bar]>.40f && mean>.45f && onsetCount<=4 ? 3 : energy[bar]>.57f ? 2 : 1;
            if (bar==0 || bar%4==0 || std::abs(energy[bar]-energy[bar-1])>.24f) sections[bar]=suggested;
            else sections[bar]=sections[bar-1];
        }
    }
    std::vector<std::array<Hit,pieceCount>> grid(count);
    const auto put = [&](int tick, Piece piece, float velocity, float priority) {
        if (tick<0 || tick>=count || (input.respectGaps && !active[tick])) return;
        auto& hit=grid[tick][static_cast<int>(piece)];
        if(priority>hit.priority)hit={std::clamp(velocity,.12f,1.0f),priority};
    };
    const int division=input.triplet?8:6, doubleDivision=input.triplet?4:3;
    // Original rhythmic biases, not transcriptions of commercial recordings.
    static constexpr float kickBias[4][16] = {
        {.95f,.08f,.25f,.52f,.10f,.43f,.67f,.18f,.78f,.15f,.20f,.59f,.08f,.48f,.31f,.18f},
        {.98f,.22f,.48f,.65f,.12f,.42f,.69f,.52f,.88f,.36f,.31f,.72f,.10f,.58f,.66f,.42f},
        {.94f,.43f,.16f,.72f,.12f,.57f,.22f,.51f,.79f,.36f,.58f,.17f,.12f,.68f,.42f,.77f},
        {.94f,.02f,.32f,.10f,.04f,.30f,.48f,.08f,.71f,.04f,.42f,.17f,.04f,.36f,.13f,.07f}
    };
    static constexpr float doubleBias[4]={.65f,1.0f,.85f,.22f};
    const double kickSpacing=result.bpm/60.0*.055;
    for(int bar=0;bar<result.bars;++bar) {
        const int origin=bar*barTicks, mode=sections[bar];
        const bool breakdown=mode==3, chorus=mode==2;
        const bool transition=bar+1<result.bars && sections[bar+1]!=mode;
        const bool phraseEnd=(bar%4==3)||transition||bar==result.bars-1;
        const bool fill=phraseEnd && fills>0 && randomAt(seed,bar,10)<fills;
        const int fillLength=fill ? ((complexity>.78f && (transition||bar==result.bars-1))?48:24) : 0;
        const int fillStart=origin+barTicks-fillLength;
        const float strength=.44f+.44f*intensity+(chorus?.08f:0);
        const int hatDivision=(complexity>.72f && (style==2 || (chorus&&style==1))) ? division : (input.triplet?8:12);
        for(int t=origin;t<std::min(count,origin+barTicks);++t) {
            const int local=t-origin;
            const float accent=peaks[t];
            if(accent>.12f && randomAt(seed,t,1)<follow*(.40f+.60f*accent))
                put(t,Piece::Kick,strength*(.78f+.22f*accent),3.0f+accent);
            if(local%division==0) {
                const int slot=std::min(15,local*16/barTicks);
                float probability=kickBias[style][slot]*(.38f+.62f*complexity)*(1.0f-.74f*follow);
                if(local==0)probability=std::max(probability,.75f-.40f*follow);
                if(breakdown)probability*=local%24==0?1.20f:.30f;
                if(chorus)probability*=1.15f;
                if(randomAt(seed,t,2)<probability)put(t,Piece::Kick,strength*(local%24==0?1.0f:.83f),1.0f);
            }
            // Double-kick phrases are tied to stronger guide activity, downbeat
            // regions or a guide onset, rather than a continuous random stream.
            if(doubles>0 && local%doubleDivision==0) {
                float nearby=0;for(int k=std::max(origin,t-12);k<=t;++k)nearby=std::max(nearby,peaks[k]);
                const bool phraseRegion=(local<24 || (local>=48&&local<72) || nearby>.45f);
                float probability=doubles*doubleBias[style]*(.28f+.72f*complexity)*(chorus?1.0f:.72f);
                if(breakdown)probability*=nearby>.35f?1.0f:.25f;
                if(phraseRegion && randomAt(seed,t,3)<probability)
                    put(t,Piece::Kick,strength*(local%division==0?.88f:.72f),1.2f);
            }
            const bool backbeat=breakdown?local==48:(local==24||local==72);
            if(backbeat)put(t,Piece::Snare,std::min(1.0f,strength+.08f),5.0f);
            if(complexity>.48f && !breakdown && (local==(input.triplet?16:18)||local==(input.triplet?64:66)||local==(input.triplet?80:84))
                && randomAt(seed,t,4)<(complexity-.48f)*(style==3?1.2f:.70f))
                put(t,Piece::Snare,strength*.32f,1.4f);
            const bool inFill=fill&&t>=fillStart;
            if(!inFill && local%(breakdown?24:hatDivision)==0) {
                Piece metal=chorus && style==1?Piece::Ride:Piece::HatClosed;
                if((chorus&&(local==0||(style==2&&local==48))) || (breakdown&&local==0))metal=Piece::Crash;
                else if(local>=72 && randomAt(seed,t,5)<(.08f+.26f*intensity)*(chorus?1.4f:.7f))metal=Piece::HatOpen;
                const float accentVelocity=local%24==0?1.0f:(input.triplet&&local%24==8?.67f:.77f);
                put(t,metal,strength*accentVelocity*(metal==Piece::Crash?1.0f:.78f),metal==Piece::Crash?3.5f:1.0f);
            }
            if(inFill && (t-fillStart)%division==0) {
                const float progress=float(t-fillStart)/std::max(1,fillLength);
                Piece piece=progress<.28f?Piece::Snare:progress<.62f?Piece::TomHigh:Piece::TomLow;
                if(style==1&&progress>.75f)piece=Piece::Snare;
                put(t,piece,strength*(.66f+.30f*progress),3.0f);
            }
        }
    }
    std::vector<TimedHit> timed;
    timed.reserve(result.bars*64);
    for(int tick=0;tick<count;++tick) {
        auto& row=grid[tick];
        // A drummer cannot simultaneously strike an open and closed hi-hat.
        auto& closed=row[static_cast<int>(Piece::HatClosed)];auto& open=row[static_cast<int>(Piece::HatOpen)];
        if(closed.priority>0&&open.priority>0){if(open.priority>=closed.priority)closed={};else open={};}
        const double jitter=(randomAt(seed,tick,20)*2.0-1.0)*human*std::min(.012*result.bpm/60.0,.40/ticksPerBeat);
        const double lower=input.respectGaps && (tick==0 || !active[tick-1]) ? tick/double(ticksPerBeat) : 0.0;
        const double beat=std::clamp(tick/double(ticksPerBeat)+jitter,lower,std::nextafter(count/double(ticksPerBeat),0.0));
        for(int p=0;p<pieceCount;++p)if(row[p].priority>0) {
            const float variation=1.0f+human*(randomAt(seed,tick,30+p)*2.0f-1.0f)*.12f;
            timed.push_back({beat,static_cast<Piece>(p),std::clamp(row[p].velocity*variation,.12f,1.0f),row[p].priority});
        }
    }
    std::stable_sort(timed.begin(),timed.end(),[](const TimedHit&a,const TimedHit&b){
        return a.beat!=b.beat?a.beat<b.beat:a.priority>b.priority;
    });
    result.events.reserve(timed.size());
    std::array<double,2> handTime{{-1000,-1000}};
    std::array<double,pieceCount> pieceTime;pieceTime.fill(-1000);
    const double handSpacing=result.bpm/60.0*.065, sameHandPieceSpacing=result.bpm/60.0*.035;
    double kickTime=-1000;float kickPriority=0;std::size_t lastKick=0;
    for(const auto& hit:timed) {
        const int piece=static_cast<int>(hit.piece);
        if(hit.piece==Piece::Kick) {
            if(hit.beat-kickTime<kickSpacing) {
                if(hit.priority<=kickPriority)continue;
                result.events[lastKick].velocity=0; // Replace a weaker neighbouring template kick.
            }
            kickTime=hit.beat;kickPriority=hit.priority;lastKick=result.events.size();
        } else {
            if(hit.beat-pieceTime[piece]<sameHandPieceSpacing)continue;
            const int hand=handTime[0]<=handTime[1]?0:1;
            if(hit.beat-handTime[hand]<handSpacing)continue;
            // Keep the hi-hat/cymbal line to one hand per exact grid instant;
            // the second hand is available for snare or tom punctuation.
            if(cymbal(hit.piece) && !result.events.empty()) {
                bool occupied=false;
                for(auto it=result.events.rbegin();it!=result.events.rend()&&it->beat==hit.beat;++it)
                    occupied=occupied||(it->velocity>0&&cymbal(it->piece));
                if(occupied)continue;
            }
            handTime[hand]=hit.beat;pieceTime[piece]=hit.beat;
        }
        result.events.push_back({hit.beat,hit.piece,hit.velocity});
    }
    result.events.erase(std::remove_if(result.events.begin(),result.events.end(),[](const Event&e){return e.velocity==0;}),result.events.end());
    return result;
}

int midiNote(Piece piece) noexcept {
    switch(piece) {
        case Piece::Kick:return 36;
        case Piece::Snare:return 38;
        case Piece::HatClosed:return 42;
        case Piece::HatOpen:return 46;
        case Piece::TomHigh:return 50;
        case Piece::TomLow:return 45;
        case Piece::Crash:return 49;
        case Piece::Ride:return 51;
        default:return 36;
    }
}
} // namespace breakwater
