#pragma once
#include <JuceHeader.h>
#include "DrummerCore.h"
#include <array>
#include <vector>
namespace breakwater {
class KitSampler {
public:
    bool load(); // disk I/O, call off audio thread
    void prepare(double sr) noexcept { rate = sr; reset(); }
    void reset() noexcept;
    void trigger(Piece,float) noexcept;
    void tick(float& left,float& right,const std::array<float,5>& levels) noexcept;
    static juce::File findKitDirectory();
private:
    struct Sample { std::vector<float> left,right; double rate = 44100; int layer = 1; };
    struct Voice { const Sample* sample=nullptr; double position=0,step=1; float gain=0; int piece=0; uint64_t age=0; };
    std::array<std::vector<Sample>,8> samples;
    std::array<Voice,64> voices{};
    std::array<unsigned,8> roundRobin{};
    double rate=48000;
    uint64_t clock=0;
};
}
