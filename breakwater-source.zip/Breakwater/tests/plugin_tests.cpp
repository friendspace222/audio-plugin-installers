#include "PluginProcessor.h"
#include <iostream>
#include <stdexcept>
#include <cmath>
namespace {
int checks=0;
void check(bool yes,const char* what){++checks;if(!yes)throw std::runtime_error(what);}
void set(BreakwaterAudioProcessor& p,const char* id,float v){auto* x=p.parameters.getParameter(id);check(x!=nullptr,"Parameter missing");x->setValueNotifyingHost(x->convertTo0to1(v));}
class Head final:public juce::AudioPlayHead {public:double beat=0,bpm=120;bool playing=true;juce::Optional<PositionInfo> getPosition() const override {PositionInfo p;p.setBpm(bpm);p.setPpqPosition(beat);p.setIsPlaying(playing);p.setTimeSignature(TimeSignature{4,4});return p;}};
float guideSample(int n){const int period=6000;const float t=(float)(n%period)/48000;return .3f*std::sin(2*3.14159265358979323846f*110*n/48000)*std::exp(-t*75);}
void snapshot(juce::Component& editor,const juce::File& file){auto stream=file.createOutputStream();check(stream!=nullptr,"Screenshot stream failed");stream->setPosition(0);stream->truncate();juce::PNGImageFormat png;check(png.writeImageToStream(editor.createComponentSnapshot(editor.getLocalBounds()),*stream),"Screenshot failed");}
double render(BreakwaterAudioProcessor& p,Head& head,int count,bool withInput=false){juce::AudioBuffer<float> buffer(2,256);juce::MidiBuffer midi;double energy=0;for(int offset=0;offset<count;offset+=256){const int n=std::min(256,count-offset);buffer.setSize(2,n,false,false,true);buffer.clear();if(withInput)for(int i=0;i<n;++i)buffer.setSample(0,i,guideSample(offset+i));p.processBlock(buffer,midi);for(int c=0;c<2;++c)for(int i=0;i<n;++i){const float v=buffer.getSample(c,i);check(std::isfinite(v)&&std::abs(v)<=.981f,"Unbounded output");energy+=v*v;}head.beat+=n/48000.0*head.bpm/60;}return energy;}
}
int main(int argc,char** argv){try{
    juce::ScopedJuceInitialiser_GUI gui;
    BreakwaterAudioProcessor p;check(p.getParameters().size()==20,"Expected20controls");check(p.isKitReady(),"Bundled acoustic kit not found");p.prepareToPlay(48000,256);
    Head head;p.setPlayHead(&head);juce::AudioBuffer<float> audio(2,256);juce::MidiBuffer midi;
    check(!p.generatePattern(),"Empty guide generated drums");
    p.beginListen();check(render(p,head,48000*8,true)==0,"Muted guide monitor leaked duplicated reference");head.playing=false;audio.clear();p.processBlock(audio,midi);check(p.listenState==3,"Transport stop did not finish capture");
    p.prepareToPlay(48000,512);check(p.finishAndGenerate(),"Device reprepare lost stopped capture");
    auto pattern=p.getPatternSnapshot();check(pattern.bars==4&&!pattern.events.empty(),"Unexpected learned length/events");check(p.hasGuide(),"Learned guide not retained");
    head.beat=pattern.startBeat;head.playing=true;p.prepareToPlay(48000,256);const double first=render(p,head,48000);
    check(first>1,"Kit playback silent");head.beat=pattern.startBeat;p.prepareToPlay(48000,256);const double second=render(p,head,48000);check(std::abs(first-second)<1e-5,"Seek/restart changed deterministic playback");
    head.beat=pattern.startBeat;const double liveSeek=render(p,head,48000);check(std::abs(first-liveSeek)<1e-5,"Live rewind retained stale notes/voices");
    set(p,"enabled",0);check(render(p,head,256)==0,"Drummer Off left ringing voices");set(p,"enabled",1);
    p.setPreview(true);render(p,head,256);check(!p.isPreviewing(),"Host playback did not dismiss Preview");
    head.playing=false;audio.clear();p.processBlock(audio,midi);check(audio.getMagnitude(0,256)==0,"Stopped transport did not silence drums");
    juce::MemoryBlock state;p.getStateInformation(state);BreakwaterAudioProcessor restored;restored.setStateInformation(state.getData(),(int)state.getSize());auto recalled=restored.getPatternSnapshot();check(recalled.events.size()==pattern.events.size()&&recalled.bars==pattern.bars,"Arrangement state lost");
    for(size_t i=0;i<pattern.events.size();++i)check(pattern.events[i].beat==recalled.events[i].beat&&pattern.events[i].velocity==recalled.events[i].velocity&&pattern.events[i].piece==recalled.events[i].piece,"Saved notes changed");
    const char bad[]="garbage";restored.setStateInformation(bad,sizeof bad);check(restored.eventCount==p.eventCount,"Malformed state changed arrangement");
    BreakwaterAudioProcessor empty;juce::MemoryBlock emptyState;empty.getStateInformation(emptyState);restored.setStateInformation(emptyState.getData(),(int)emptyState.getSize());check(restored.eventCount==0&&!restored.hasGuide(),"Empty state did not clear previous arrangement");
    const auto temp=juce::File::getSpecialLocation(juce::File::tempDirectory).getNonexistentChildFile("breakwater-validation","",false);check(temp.createDirectory().wasOk(),"Cannot create temporary directory");
    const auto midiFile=temp.getChildFile("drums.mid");check(p.exportMidi(midiFile),"MIDI export failed");juce::FileInputStream in(midiFile);juce::MidiFile parsed;check(parsed.readFrom(in)&&parsed.getTimeFormat()==960,"Invalid MIDI export");check(parsed.getNumTracks()==1,"MIDI track missing");int notes=0;for(int i=0;i<parsed.getTrack(0)->getNumEvents();++i)if(parsed.getTrack(0)->getEventPointer(i)->message.isNoteOn())++notes;check(notes==(int)pattern.events.size(),"MIDI notes lost");check(parsed.getLastTimestamp()>=pattern.bars*4*960,"MIDI lost arrangement trailing duration");
    const auto wavFile=temp.getChildFile("drums.wav");p.exportAudio(wavFile);const auto deadline=juce::Time::getMillisecondCounterHiRes()+30000;while(p.exportBusy&&juce::Time::getMillisecondCounterHiRes()<deadline)juce::Thread::sleep(10);check(!p.exportBusy,"WAV export timed out");
    juce::AudioFormatManager formats;formats.registerBasicFormats();std::unique_ptr<juce::AudioFormatReader> wav(formats.createReaderFor(wavFile));check(wav&&wav->numChannels==2&&wav->sampleRate==48000&&wav->lengthInSamples>48000*8,"Invalid WAV export");wav.reset();
    const auto source=temp.getChildFile("guide.wav");{juce::WavAudioFormat format;auto stream=source.createOutputStream();std::unique_ptr<juce::AudioFormatWriter> writer(format.createWriterFor(stream.release(),48000,1,24,{},0));check(writer!=nullptr,"Guide writer failed");juce::AudioBuffer<float> signal(1,48000*4);for(int n=0;n<signal.getNumSamples();++n)signal.setSample(0,n,guideSample(n));check(writer->writeFromAudioSampleBuffer(signal,0,signal.getNumSamples()),"Guide write failed");}
    set(restored,"startBar",5);check(restored.importGuide(source),"WAV import failed");check(restored.getPatternSnapshot().startBeat==16&&restored.getPatternSnapshot().bars==2,"Import timing wrong");
    restored.prepareToPlay(48000,256);restored.setPreview(true);Head stopped;stopped.playing=false;restored.setPlayHead(&stopped);check(render(restored,stopped,24000)>1,"Standalone preview silent");restored.setPreview(false);
    std::unique_ptr<juce::AudioProcessorEditor> editor(p.createEditor());check(editor!=nullptr&&editor->getWidth()>=900,"Editor missing");
    if(argc>1){juce::File dir(juce::String::fromUTF8(argv[1]));dir.createDirectory();snapshot(*editor,dir.getChildFile("Breakwater-Full.png"));editor->setSize(950,650);snapshot(*editor,dir.getChildFile("Breakwater-Minimum.png"));}
    editor.reset();temp.deleteRecursively();std::cout<<"PASS: "<<checks<<" processor checks; capture, actual kit audio, transport, state, MIDI/WAV export, import, preview and editor.\n";
    return 0;
}catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}}
