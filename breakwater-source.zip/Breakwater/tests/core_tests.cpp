#include "../Source/DrummerCore.h"
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <new>
#include <string>
#include <vector>

static std::atomic<bool> watchAllocations{false};
static std::atomic<int> allocations{0};
void* operator new(std::size_t n) {
    if(watchAllocations.load())++allocations;
    if(auto* p=std::malloc(n?n:1))return p;
    throw std::bad_alloc();
}
void* operator new[](std::size_t n){return ::operator new(n);}
void operator delete(void* p) noexcept{std::free(p);}
void operator delete[](void* p) noexcept{std::free(p);}
void operator delete(void* p,std::size_t) noexcept{std::free(p);}
void operator delete[](void* p,std::size_t) noexcept{std::free(p);}

using namespace breakwater;
namespace {
constexpr double pi=3.14159265358979323846;
constexpr int barTicks=4*ticksPerBeat;
int checks=0,failures=0;
void check(bool condition,const std::string& message) {
    ++checks;if(!condition){++failures;std::cerr<<"FAIL: "<<message<<'\n';}
}
Guide guideWith(int bars,const std::vector<int>& onsets) {
    Guide guide;guide.ticks=std::min(maxTicks,bars*barTicks);guide.startBeat=16;guide.bpm=120;guide.hasSignal=true;
    for(int n=0;n<guide.ticks;++n)guide.activity[n]=.25f;
    for(int b=0;b<bars;++b)for(int tick:onsets)if(b*barTicks+tick<guide.ticks)guide.accents[b*barTicks+tick]=1;
    return guide;
}
Settings fixed() {
    Settings s;s.humanize=0;s.section=1;s.doubleKick=0;s.fills=0;s.respectGaps=true;s.seed=12345;return s;
}
bool equal(const Pattern&a,const Pattern&b) {
    if(a.bars!=b.bars||a.startBeat!=b.startBeat||a.bpm!=b.bpm||a.events.size()!=b.events.size())return false;
    for(std::size_t n=0;n<a.events.size();++n)if(a.events[n].beat!=b.events[n].beat||a.events[n].piece!=b.events[n].piece||a.events[n].velocity!=b.events[n].velocity)return false;
    return true;
}
int pieces(const Pattern&p,Piece piece) {
    return static_cast<int>(std::count_if(p.events.begin(),p.events.end(),[piece](const Event&e){return e.piece==piece;}));
}
float averageVelocity(const Pattern&p) {
    float sum=0;for(const auto&e:p.events)sum+=e.velocity;return sum/std::max<std::size_t>(1,p.events.size());
}
int eventsIn(const Pattern&p,double begin,double end) {
    return static_cast<int>(std::count_if(p.events.begin(),p.events.end(),[=](const Event&e){return e.beat>=begin&&e.beat<end;}));
}
double accentCoverage(const Pattern&p,const Guide&g) {
    int hits=0,total=0;
    for(int tick=0;tick<g.ticks;++tick)if(g.accents[tick]>.5f) {
        ++total;for(const auto&e:p.events)if(e.piece==Piece::Kick&&std::abs(e.beat-tick/double(ticksPerBeat))<.0001){++hits;break;}
    }
    return total?hits/double(total):0;
}
void analyser() {
    for(double rate:{44100.,48000.,96000.,192000.,384000.}) {
        GuideAnalyser analyser;analyser.prepare(rate);analyser.begin(16,120);
        for(int n=0;n<static_cast<int>(rate*1.5);++n)analyser.process(0,16+n/rate*2);
        check(!analyser.result().hasSignal,"digital silence is not detected as a guide at "+std::to_string(rate));
        check(analyser.result().ticks==72,"silent capture retains timing at "+std::to_string(rate));
        check(generate(analyser.result(),fixed()).events.empty(),"silent capture produces no learned pattern");
        analyser.begin(16,120);
        for(int n=0;n<static_cast<int>(rate*2);++n) {
            const double time=n/rate,phase=std::fmod(time,.25);
            const float signal=phase<.09?static_cast<float>(.4*std::sin(2*pi*220*phase)*std::exp(-phase/.025)):0;
            analyser.process(signal,16+time*2);
        }
        const auto& g=analyser.result();check(g.hasSignal&&g.ticks==96,"rhythmic guide is captured at "+std::to_string(rate));
        float high=0;for(int t=0;t<g.ticks;++t)high=std::max(high,g.accents[t]);
        int detected=0;for(int beat=0;beat<8;++beat){float onset=0;for(int t=beat*12;t<std::min(g.ticks,beat*12+3);++t)onset=std::max(onset,g.accents[t]);if(onset>high*.5f)++detected;}
        check(detected==8,"eight known pluck accents localized within three ticks at "+std::to_string(rate));
        auto s=fixed();s.follow=1;const auto pattern=generate(g,s);
        check(pieces(pattern,Piece::Kick)>=7,"analysed guitar pulses influence generated kicks at "+std::to_string(rate));
        analyser.begin(0,120);
        for(int n=0;n<static_cast<int>(rate*.5);++n)analyser.process(static_cast<float>(.3*std::sin(2*pi*1000*n/rate)),n/rate*2);
        float first=0,late=0;for(int t=0;t<24;++t){if(t<6)first=std::max(first,analyser.result().accents[t]);if(t>=12)late=std::max(late,analyser.result().accents[t]);}
        check(late<first*.15f,"sustained tone does not create repeated strong attacks");
        allocations=0;watchAllocations=true;
        analyser.prepare(rate);analyser.begin(4,135);
        for(int n=0;n<12000;++n)analyser.process(n%97==0?std::numeric_limits<float>::quiet_NaN():.1f,4+n/rate*2.25);
        watchAllocations=false;
        check(allocations==0,"prepare/begin/process allocate no memory");
        bool finite=true;for(int t=0;t<analyser.result().ticks;++t)finite=finite&&std::isfinite(analyser.result().accents[t])&&std::isfinite(analyser.result().activity[t]);
        check(finite,"NaN audio cannot poison analysis");
    }
    GuideAnalyser analyser;analyser.prepare(std::numeric_limits<double>::quiet_NaN());analyser.begin(-8,std::numeric_limits<double>::infinity());
    analyser.process(.1f,-8);analyser.process(.2f,-7.99);const auto before=analyser.result();
    analyser.process(1,-8.1);analyser.process(1,std::numeric_limits<double>::quiet_NaN());
    check(analyser.result().ticks==before.ticks&&analyser.result().accents==before.accents,"backwards or invalid host positions do not overwrite captured guide");
    analyser.begin(0,120);analyser.process(1,1000000);
    check(analyser.result().ticks==0,"positions beyond 128 bars do not overrun storage");
}
void learnedRhythm() {
    const auto first=guideWith(8,{9,30,42,57,78}),second=guideWith(8,{3,18,39,54,87});auto s=fixed();
    s.follow=0;const auto free=generate(first,s);s.follow=1;const auto followFirst=generate(first,s),followSecond=generate(second,s);
    const double low=accentCoverage(free,first),high=accentCoverage(followFirst,first);
    std::cout<<"Guide accent coverage Follow0="<<low<<" Follow1="<<high<<'\n';
    check(high>.95&&high>low+.4,"Follow transfers actual off-grid accents into kick placement");
    check(accentCoverage(followSecond,second)>.95,"different guitar accent map creates matching different kicks");
    check(accentCoverage(followSecond,first)<.35,"generated kicks are not an unrelated fixed loop");
    check(!equal(followFirst,followSecond),"guide content changes the generated performance");
    check(followFirst.startBeat==16&&followFirst.events.front().beat<4,"events are relative to the preserved host anchor");
    auto empty=first;empty.hasSignal=false;check(generate(empty,s).events.empty(),"hasSignal false never creates drums");
    empty=Guide{};empty.hasSignal=true;empty.ticks=384;check(generate(empty,s).events.empty(),"empty arrays cannot create a learned pattern even with a stale signal flag");
}
void musicalControls() {
    const auto g=guideWith(8,{0,12,24,36,48,60,72,84});auto s=fixed();s.section=2;s.complexity=.85f;s.follow=.35f;s.doubleKick=.9f;s.fills=.7f;
    std::array<Pattern,4> styles;
    for(int style=0;style<4;++style){s.style=style;styles[style]=generate(g,s);std::cout<<"Style "<<style<<" hits="<<styles[style].events.size()<<" kicks="<<pieces(styles[style],Piece::Kick)<<" crashes="<<pieces(styles[style],Piece::Crash)<<'\n';}
    for(int a=0;a<4;++a)for(int b=a+1;b<4;++b)check(!equal(styles[a],styles[b]),"genre performance differs "+std::to_string(a)+"/"+std::to_string(b));
    check(pieces(styles[1],Piece::Ride)>pieces(styles[0],Piece::Ride),"metal chorus uses ride-led cymbal phrasing");
    check(pieces(styles[1],Piece::Kick)>pieces(styles[3],Piece::Kick),"metal has more double-kick density than emo");
    check(pieces(styles[2],Piece::Crash)>pieces(styles[3],Piece::Crash),"screamo chorus has stronger crash punctuation");
    s=fixed();s.follow=.4f;s.section=1;const auto verse=generate(g,s);s.section=3;const auto breakdown=generate(g,s);
    int normalBackbeats=0,halfBackbeats=0;
    for(const auto&e:verse.events)if(e.piece==Piece::Snare&&(std::fmod(e.beat,4)==1||std::fmod(e.beat,4)==3)&&e.velocity>.5)++normalBackbeats;
    for(const auto&e:breakdown.events)if(e.piece==Piece::Snare&&std::fmod(e.beat,4)==2)++halfBackbeats;
    check(normalBackbeats==16&&halfBackbeats==8,"verse has stable two/four backbeat; breakdown has half-time backbeat");
    s=fixed();s.style=1;s.follow=.4f;s.doubleKick=0;const auto noDoubles=generate(g,s);s.doubleKick=1;const auto doubles=generate(g,s);
    check(pieces(doubles,Piece::Kick)>pieces(noDoubles,Piece::Kick)+8,"double-kick control adds structured kick runs");
    s=fixed();s.fills=0;const auto noFills=generate(g,s);s.fills=1;const auto withFills=generate(g,s);
    check(pieces(noFills,Piece::TomHigh)+pieces(noFills,Piece::TomLow)==0,"zero fills leaves normal groove intact");
    check(pieces(withFills,Piece::TomHigh)+pieces(withFills,Piece::TomLow)>0,"phrase fills include descending tom movement");
    bool purposeful=true;for(const auto&e:withFills.events)if(e.piece==Piece::TomHigh||e.piece==Piece::TomLow)purposeful=purposeful&&(static_cast<int>(e.beat/4)%4==3)&&std::fmod(e.beat,4)>=3;
    check(purposeful,"fills occur at four-bar phrase ends, not arbitrary bars");
    s=fixed();s.style=2;s.follow=.2f;s.complexity=0;const auto simple=generate(g,s);s.complexity=1;const auto complex=generate(g,s);
    check(complex.events.size()>simple.events.size()+20,"complexity controls subdivision and ghost-note density");
    s=fixed();s.intensity=0;const auto soft=generate(g,s);s.intensity=1;const auto hard=generate(g,s);
    check(averageVelocity(hard)>averageVelocity(soft)+.25f,"intensity changes performance dynamics");
    s=fixed();s.triplet=true;s.follow=0;s.complexity=.4f;const auto triplets=generate(g,s);bool thirds=true,offbeat=false;
    for(const auto&e:triplets.events){thirds=thirds&&std::abs(e.beat*3-std::round(e.beat*3))<1e-7;offbeat=offbeat||std::abs(e.beat-std::round(e.beat))>.2;}
    check(thirds&&offbeat,"triplet mode places unhumanized groove on thirds of beats");
    auto dynamics=g;for(int t=0;t<4*barTicks;++t)dynamics.activity[t]*=.08f;s=fixed();s.section=0;s.follow=.3f;
    const auto automatic=generate(dynamics,s);s.section=1;const auto forcedVerse=generate(dynamics,s);
    check(!equal(automatic,forcedVerse),"Auto energy changes section orchestration across strong energy changes");
}
void silenceAndHumanization() {
    auto g=guideWith(5,{0,12,24,36,48,60,72,84});for(int t=2*barTicks;t<3*barTicks;++t){g.activity[t]=0;g.accents[t]=0;}
    auto s=fixed();s.follow=.5f;s.humanize=1;s.respectGaps=true;const auto gaps=generate(g,s);
    check(eventsIn(gaps,8,12)==0,"respect-gaps leaves a full silent bar empty, including humanization");
    s.respectGaps=false;const auto continuous=generate(g,s);check(eventsIn(continuous,8,12)>6,"respect-gaps can be disabled for a continuous groove");
    s=fixed();s.humanize=.8f;const auto first=generate(g,s),repeat=generate(g,s);
    check(equal(first,repeat),"seeded timing/velocity humanization is sample-exact deterministic");
    s.seed++;check(!equal(first,generate(g,s)),"new seed creates a new reproducible performance");
    s.seed--;s.humanize=0;const auto grid=generate(g,s);bool unquantized=false;
    for(const auto&e:first.events)unquantized=unquantized||std::abs(e.beat*ticksPerBeat-std::round(e.beat*ticksPerBeat))>.001;
    check(unquantized&&!equal(first,grid),"humanization affects timing as well as velocity");
    g.ticks=2*barTicks+13;s=fixed();const auto partial=generate(g,s);
    check(partial.bars==3,"partial captured bar rounds up the pattern bar count");
    check(std::all_of(partial.events.begin(),partial.events.end(),[&](const Event&e){return e.beat<g.ticks/double(ticksPerBeat);}),"partial capture does not invent events beyond observed duration");
}
void boundedAndInvalid() {
    for(double tempo:{20.,60.,120.,240.,400.})for(int style=0;style<4;++style)for(int section=1;section<=3;++section) {
        auto g=guideWith(4,{0,3,6,9,12,18,24,30,36,42,48,54,60,66,72,78,84,90});g.bpm=tempo;
        auto s=fixed();s.style=style;s.section=section;s.complexity=1;s.doubleKick=1;s.intensity=1;s.fills=1;s.follow=1;s.humanize=1;s.triplet=(style&1)!=0;
        const auto p=generate(g,s);bool valid=true,hands=true,collisionFree=true;
        double previous=-1,lastKick=-1000;std::array<double,2> handTimes{{-1000,-1000}};
        std::array<double,8> pieceTimes;pieceTimes.fill(-1000);
        double groupBeat=-1;int groupHands=0,groupCymbals=0;
        for(const auto&e:p.events) {
            const int piece=static_cast<int>(e.piece);const double seconds=e.beat*60/tempo;
            valid=valid&&std::isfinite(e.beat)&&std::isfinite(e.velocity)&&e.beat>=previous&&e.beat>=0&&e.beat<16&&e.velocity>=.12f&&e.velocity<=1&&piece>=0&&piece<8;
            previous=e.beat;
            if(e.beat!=groupBeat){groupBeat=e.beat;groupHands=groupCymbals=0;}
            if(e.piece==Piece::Kick){collisionFree=collisionFree&&seconds-lastKick>=.055-1e-9;lastKick=seconds;}
            else {
                ++groupHands;const int hand=handTimes[0]<=handTimes[1]?0:1;
                hands=hands&&seconds-handTimes[hand]>=.065-1e-9;handTimes[hand]=seconds;
                collisionFree=collisionFree&&seconds-pieceTimes[piece]>=.035-1e-9;pieceTimes[piece]=seconds;
                if(e.piece==Piece::HatClosed||e.piece==Piece::HatOpen||e.piece==Piece::Crash||e.piece==Piece::Ride)++groupCymbals;
            }
            collisionFree=collisionFree&&groupHands<=2&&groupCymbals<=1;
        }
        check(valid&&!p.events.empty(),"finite sorted bounded events for tempo/style/section "+std::to_string(tempo)+"/"+std::to_string(style)+"/"+std::to_string(section));
        check(hands&&collisionFree,"humanized limb/collision limits hold at "+std::to_string(tempo)+"/"+std::to_string(style)+"/"+std::to_string(section));
    }
    auto invalid=guideWith(1,{0,24,48,72});invalid.startBeat=std::numeric_limits<double>::quiet_NaN();invalid.bpm=std::numeric_limits<double>::infinity();
    invalid.accents[12]=std::numeric_limits<float>::quiet_NaN();invalid.activity[5]=std::numeric_limits<float>::infinity();
    auto s=fixed();s.style=999;s.section=-2;s.complexity=std::numeric_limits<float>::quiet_NaN();s.humanize=std::numeric_limits<float>::infinity();s.follow=-100;
    const auto output=generate(invalid,s);check(output.startBeat==0&&output.bpm==120&&!output.events.empty(),"invalid metadata/settings use finite bounded defaults");
    invalid.ticks=maxTicks+500;const auto limited=generate(invalid,s);check(limited.bars==maxBars,"malformed duration is bounded to the fixed 128-bar storage");
    const std::array<int,8> notes{{36,38,42,46,50,45,49,51}};
    for(int n=0;n<8;++n)check(midiNote(static_cast<Piece>(n))==notes[n],"General MIDI drum note mapping "+std::to_string(n));
}
}
int main() {
    analyser();learnedRhythm();musicalControls();silenceAndHumanization();boundedAndInvalid();
    std::cout<<"Breakwater core: "<<checks-failures<<"/"<<checks<<" checks passed\n";
    return failures?1:0;
}
