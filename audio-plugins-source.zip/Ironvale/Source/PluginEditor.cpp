#include "PluginEditor.h"
#include "PluginProcessor.h"
#include "Parameters.h"
#include <cmath>
#include <vector>

namespace
{
const juce::Colour background { 0xff101214 };
const juce::Colour surface { 0xff1a1c1f };
const juce::Colour raised { 0xff24272a };
const juce::Colour edge { 0xff383b3e };
const juce::Colour ink { 0xffeee7dc };
const juce::Colour quiet { 0xff989b9d };
const juce::Colour echo { 0xffce956b };
const juce::Colour space { 0xffa6c1bc };

juce::Font face (float height, bool bold = false)
{
    return juce::Font (height, bold ? juce::Font::bold : juce::Font::plain);
}

void drawTextLabel (juce::Graphics& g, const juce::String& value, juce::Rectangle<int> bounds,
           float height, juce::Colour colour, juce::Justification align = juce::Justification::centredLeft,
           bool bold = false)
{
    g.setColour (colour);
    g.setFont (face (height, bold));
    g.drawText (value, bounds, align);
}

class IronvaleLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    IronvaleLookAndFeel()
    {
        setColour (juce::PopupMenu::backgroundColourId, surface);
        setColour (juce::PopupMenu::textColourId, ink);
        setColour (juce::PopupMenu::highlightedBackgroundColourId, raised.brighter (0.15f));
        setColour (juce::PopupMenu::highlightedTextColourId, echo);
        setColour (juce::TooltipWindow::backgroundColourId, raised);
        setColour (juce::TooltipWindow::textColourId, ink);
        setColour (juce::TooltipWindow::outlineColourId, edge);
        setColour (juce::Label::textColourId, ink);
        setColour (juce::ComboBox::textColourId, ink);
        setColour (juce::ComboBox::backgroundColourId, background);
        setColour (juce::ComboBox::outlineColourId, edge);
        setColour (juce::TextButton::buttonColourId, raised);
        setColour (juce::TextButton::buttonOnColourId, echo);
        setColour (juce::TextButton::textColourOffId, quiet);
        setColour (juce::TextButton::textColourOnId, ink);
        setColour (juce::Slider::textBoxTextColourId, ink);
        setColour (juce::Slider::textBoxBackgroundColourId, juce::Colours::transparentBlack);
        setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        setColour (juce::Slider::textBoxHighlightColourId, echo.withAlpha (0.25f));
    }

    juce::Font getComboBoxFont (juce::ComboBox&) override { return face (13.0f); }
    juce::Font getLabelFont (juce::Label& label) override { return label.getFont(); }
    juce::Font getTextButtonFont (juce::TextButton&, int) override { return face (11.0f, true); }

    juce::Label* createSliderTextBox (juce::Slider& slider) override
    {
        // Keep JUCE's slider-label accessibility and editing behavior, but give
        // both display and edit states a consistent, restrained inset surface.
        auto* label = juce::LookAndFeel_V4::createSliderTextBox (slider);
        const auto accent = slider.findColour (juce::Slider::rotarySliderFillColourId);
        label->getProperties().set ("ironvaleValue", true);
        label->setFont (face (12.0f));
        label->setBorderSize (juce::BorderSize<int> (0, 4, 0, 4));
        label->setColour (juce::Label::textColourId, ink);
        label->setColour (juce::Label::outlineColourId, juce::Colours::transparentBlack);
        label->setColour (juce::Label::backgroundColourId, background);
        label->setColour (juce::Label::textWhenEditingColourId, ink);
        label->setColour (juce::Label::backgroundWhenEditingColourId, background);
        label->setColour (juce::Label::outlineWhenEditingColourId, accent.withAlpha (0.75f));
        label->setColour (juce::TextEditor::textColourId, ink);
        label->setColour (juce::TextEditor::backgroundColourId, background);
        label->setColour (juce::TextEditor::outlineColourId, juce::Colours::transparentBlack);
        label->setColour (juce::TextEditor::focusedOutlineColourId, accent.withAlpha (0.75f));
        label->setColour (juce::TextEditor::highlightColourId, accent.withAlpha (0.25f));
        label->setColour (juce::TextEditor::highlightedTextColourId, ink);
        return label;
    }

    void drawLabel (juce::Graphics& g, juce::Label& label) override
    {
        if (! static_cast<bool> (label.getProperties()["ironvaleValue"])
            && dynamic_cast<juce::Slider*> (label.getParentComponent()) == nullptr)
        {
            juce::LookAndFeel_V4::drawLabel (g, label);
            return;
        }

        const auto bounds = label.getLocalBounds().toFloat().reduced (0.5f);
        g.setColour (background.withAlpha (label.isEnabled() ? 0.88f : 0.4f));
        g.fillRoundedRectangle (bounds, 4.5f);
        g.setColour (edge.withAlpha (label.isMouseOverOrDragging() ? 0.95f : 0.48f));
        g.drawRoundedRectangle (bounds, 4.5f, 1.0f);
        if (! label.isBeingEdited())
        {
            g.setFont (face (12.0f));
            g.setColour (ink.withAlpha (label.isEnabled() ? 0.94f : 0.4f));
            g.drawText (label.getText(), label.getLocalBounds().reduced (4, 0), juce::Justification::centred);
        }
    }

    static bool isValueEditor (juce::TextEditor& editor)
    {
        if (auto* label = dynamic_cast<juce::Label*> (editor.getParentComponent()))
            return static_cast<bool> (label->getProperties()["ironvaleValue"])
                   || dynamic_cast<juce::Slider*> (label->getParentComponent()) != nullptr;
        return false;
    }

    void fillTextEditorBackground (juce::Graphics& g, int width, int height, juce::TextEditor& editor) override
    {
        if (! isValueEditor (editor))
        {
            juce::LookAndFeel_V4::fillTextEditorBackground (g, width, height, editor);
            return;
        }
        g.setColour (background);
        g.fillRoundedRectangle (0.0f, 0.0f, (float) width, (float) height, 4.5f);
    }

    void drawTextEditorOutline (juce::Graphics& g, int width, int height, juce::TextEditor& editor) override
    {
        if (! isValueEditor (editor))
        {
            juce::LookAndFeel_V4::drawTextEditorOutline (g, width, height, editor);
            return;
        }
        g.setColour (editor.findColour (juce::TextEditor::focusedOutlineColourId));
        g.drawRoundedRectangle (0.5f, 0.5f, (float) width - 1.0f, (float) height - 1.0f, 4.5f, 1.0f);
    }

    void drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                           float position, float startAngle, float endAngle, juce::Slider& slider) override
    {
        const auto area = juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height)
                              .reduced (7.0f);
        const auto radius = juce::jmin (area.getWidth(), area.getHeight()) * 0.5f;
        const auto centre = area.getCentre();
        const auto accent = slider.findColour (juce::Slider::rotarySliderFillColourId)
                                 .withMultipliedAlpha (slider.isEnabled() ? 1.0f : 0.35f);
        const auto angle = startAngle + position * (endAngle - startAngle);
        const auto ring = radius - 1.5f;
        juce::Path track, active;
        track.addCentredArc (centre.x, centre.y, ring, ring, 0.0f, startAngle, endAngle, true);
        active.addCentredArc (centre.x, centre.y, ring, ring, 0.0f, startAngle, angle, true);
        g.setColour (edge);
        g.strokePath (track, juce::PathStrokeType (2.3f));
        g.setColour (accent);
        g.strokePath (active, juce::PathStrokeType (2.3f, juce::PathStrokeType::curved,
                                                 juce::PathStrokeType::rounded));
        for (int i = 0; i <= 10; ++i)
        {
            const auto tickAngle = startAngle + (endAngle - startAngle) * (float) i / 10.0f;
            const auto inner = ring + 4.0f;
            const auto outer = ring + 6.0f;
            g.setColour (edge.brighter (0.15f));
            g.drawLine (centre.x + std::sin (tickAngle) * inner, centre.y - std::cos (tickAngle) * inner,
                        centre.x + std::sin (tickAngle) * outer, centre.y - std::cos (tickAngle) * outer, 1.0f);
        }
        const auto disc = juce::Rectangle<float> (radius * 1.48f, radius * 1.48f).withCentre (centre);
        g.setColour (juce::Colours::black.withAlpha (0.28f));
        g.fillEllipse (disc.translated (0.0f, 2.0f).expanded (1.0f));
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff404246), centre.x, disc.getY(),
                                               juce::Colour (0xff222427), centre.x, disc.getBottom(), false));
        g.fillEllipse (disc);
        g.setColour (juce::Colour (0xff535458));
        g.drawEllipse (disc.reduced (0.5f), 1.0f);
        g.setColour (accent);
        g.drawLine (centre.x + std::sin (angle) * radius * 0.42f,
                    centre.y - std::cos (angle) * radius * 0.42f,
                    centre.x + std::sin (angle) * radius * 0.63f,
                    centre.y - std::cos (angle) * radius * 0.63f, 2.3f);
        if (slider.hasKeyboardFocus (true))
        {
            g.setColour (accent.withAlpha (0.65f));
            g.drawEllipse (disc.expanded (3.0f), 1.0f);
        }
    }

    void drawLinearSlider (juce::Graphics& g, int x, int y, int width, int height,
                           float sliderPosition, float, float,
                           juce::Slider::SliderStyle, juce::Slider& slider) override
    {
        const auto cy = (float) y + (float) height * 0.5f;
        const auto start = (float) x;
        const auto finish = (float) (x + width);
        g.setColour (edge);
        g.drawLine (start, cy, finish, cy, 3.0f);
        g.setColour (slider.findColour (juce::Slider::trackColourId)
                          .withMultipliedAlpha (slider.isEnabled() ? 1.0f : 0.3f));
        g.drawLine (start, cy, sliderPosition, cy, 3.0f);
        g.fillEllipse (sliderPosition - 4.0f, cy - 4.0f, 8.0f, 8.0f);
    }

    void drawComboBox (juce::Graphics& g, int width, int height, bool, int, int, int, int,
                       juce::ComboBox& box) override
    {
        const auto bounds = juce::Rectangle<float> (0.5f, 0.5f, (float) width - 1.0f, (float) height - 1.0f);
        g.setColour (background);
        g.fillRoundedRectangle (bounds, 6.0f);
        g.setColour (box.hasKeyboardFocus (true) ? echo : edge);
        g.drawRoundedRectangle (bounds, 6.0f, 1.0f);
        juce::Path chevron;
        const auto cx = (float) width - 15.0f;
        const auto cy = (float) height * 0.5f;
        chevron.startNewSubPath (cx - 3.5f, cy - 1.5f);
        chevron.lineTo (cx, cy + 2.0f);
        chevron.lineTo (cx + 3.5f, cy - 1.5f);
        g.setColour (quiet);
        g.strokePath (chevron, juce::PathStrokeType (1.4f));
    }

    void drawButtonBackground (juce::Graphics& g, juce::Button& button, const juce::Colour&,
                               bool highlighted, bool down) override
    {
        auto bounds = button.getLocalBounds().toFloat().reduced (0.5f);
        auto accent = button.findColour (juce::TextButton::buttonOnColourId);
        g.setColour (button.getToggleState() ? accent.withAlpha (down ? 0.22f : 0.12f)
                                             : (highlighted ? raised.brighter (0.12f) : raised));
        g.fillRoundedRectangle (bounds, 6.0f);
        g.setColour ((button.getToggleState() || button.hasKeyboardFocus (true)) ? accent : edge);
        g.drawRoundedRectangle (bounds, 6.0f, 1.0f);
    }
};

void formatSlider (juce::Slider& slider, const juce::String& unit)
{
    slider.textFromValueFunction = [unit] (double value)
    {
        if (unit == "Hz" && value >= 1000.0) return juce::String (value / 1000.0, 1) + " kHz";
        if (unit == "Hz") return juce::String (value, 0) + " Hz";
        if (unit == "rate") return juce::String (value, 2) + " Hz";
        if (unit == "s") return juce::String (value, 2) + " s";
        if (unit == "ms") return juce::String (value, value < 100.0 ? 1 : 0) + " ms";
        if (unit == "dB") return juce::String (value, 1) + " dB";
        if (unit == "BPM") return juce::String (value, 1);
        if (unit == ":1") return juce::String (value, 1) + ":1";
        if (unit.isEmpty()) return juce::String (value, 2);
        return juce::String (value, 0) + unit;
    };
    slider.valueFromTextFunction = [unit] (const juce::String& value)
    {
        return value.getDoubleValue() * ((unit == "Hz" && value.containsIgnoreCase ("k")) ? 1000.0 : 1.0);
    };
}

class ParameterControl final : public juce::Component
{
public:
    ParameterControl (juce::AudioProcessorValueTreeState& state, const juce::String& id,
                      const juce::String& name, const juce::String& unit, juce::Colour accent,
                      const juce::String& tip, bool horizontal = false)
        : compact (horizontal)
    {
        label.setText (name, juce::dontSendNotification);
        label.setFont (face (10.5f, true));
        label.setColour (juce::Label::textColourId, quiet);
        label.setJustificationType (compact ? juce::Justification::centredLeft : juce::Justification::centred);
        label.setInterceptsMouseClicks (false, false);
        const auto accessibleName = state.getParameter (id)->getName (128);
        setName (accessibleName);
        slider.setName (accessibleName);
        slider.setTitle (accessibleName);
        slider.setDescription (tip);
        slider.setTooltip (tip + " Double-click to reset; drag or type a value. Shift-drag for fine adjustment.");
        slider.setSliderStyle (compact ? juce::Slider::LinearHorizontal : juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle (compact ? juce::Slider::TextBoxRight : juce::Slider::TextBoxBelow,
                               false, compact ? 80 : 84, 22);
        slider.setColour (juce::Slider::rotarySliderFillColourId, accent);
        slider.setColour (juce::Slider::trackColourId, accent);
        slider.setMouseDragSensitivity (220);
        slider.setWantsKeyboardFocus (true);
        if (auto* parameter = state.getParameter (id))
            slider.setDoubleClickReturnValue (true, parameter->convertFrom0to1 (parameter->getDefaultValue()));
        addAndMakeVisible (label);
        addAndMakeVisible (slider);
        attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (state, id, slider);
        formatSlider (slider, unit);
        slider.updateText();
    }

    void resized() override
    {
        auto bounds = getLocalBounds();
        label.setBounds (bounds.removeFromTop (18));
        slider.setBounds (bounds);
    }

    juce::Slider slider;

private:
    bool compact;
    juce::Label label;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
};


class ChoiceSegments final : public juce::Component
{
public:
    ChoiceSegments (juce::AudioProcessorValueTreeState& state, const juce::String& id, const juce::StringArray& names)
    {
        for (int i = 0; i < names.size(); ++i)
        {
            auto button = std::make_unique<juce::TextButton> (names[i].toUpperCase());
            button->setTitle (names[i]);
            button->setName (id + " " + names[i]);
            button->setWantsKeyboardFocus (true);
            button->setClickingTogglesState (false);
            button->onClick = [this, i] { if (attachment) attachment->setValueAsCompleteGesture ((float) i); };
            addAndMakeVisible (*button);
            buttons.push_back (std::move (button));
        }
        if (auto* parameter = state.getParameter (id))
        {
            attachment = std::make_unique<juce::ParameterAttachment> (*parameter, [this] (float v)
            {
                for (int i = 0; i < (int) buttons.size(); ++i)
                    buttons[(size_t) i]->setToggleState (i == (int) std::round (v), juce::dontSendNotification);
            });
            attachment->sendInitialUpdate();
        }
    }
    void resized() override
    {
        const int count = (int) buttons.size();
        for (int i = 0; i < count; ++i)
            buttons[(size_t) i]->setBounds (i * getWidth() / count, 0, getWidth() / count - 6, getHeight());
    }
private:
    std::vector<std::unique_ptr<juce::TextButton>> buttons;
    std::unique_ptr<juce::ParameterAttachment> attachment;
};

class StompSwitch final : public juce::Button
{
public:
    StompSwitch (const juce::String& name, juce::Colour colour) : juce::Button (name), accent (colour)
    {
        setClickingTogglesState (true);
        setWantsKeyboardFocus (true);
        setTitle (name + " on or off");
        setTooltip ("Click to engage or bypass " + name.toLowerCase() + ". All pedal switches stay available on every page.");
    }
    void paintButton (juce::Graphics& g, bool hover, bool down) override
    {
        const auto bounds = getLocalBounds().toFloat().reduced (0.5f);
        const bool on = getToggleState();
        const auto colour = accent.withMultipliedAlpha (isEnabled() ? 1.0f : 0.35f);
        g.setColour (on && isEnabled() ? colour.withAlpha (0.10f) : background);
        g.fillRoundedRectangle (bounds, 7.0f);
        g.setColour (hover || hasKeyboardFocus (true) ? colour : edge);
        g.drawRoundedRectangle (bounds, 7.0f, 1.0f);
        g.setColour (on && isEnabled() ? colour : edge);
        g.fillEllipse (12.0f, 13.0f, 5.0f, 5.0f);
        drawTextLabel (g, getButtonText(), { 24, 7, getWidth() - 30, 18 }, 10.0f, isEnabled() ? ink : quiet, juce::Justification::centredLeft, true);
        const auto circle = juce::Rectangle<float> (25.0f, 25.0f).withCentre ({ 25.0f, 47.0f });
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff67696b), circle.getX(), circle.getY(), juce::Colour (0xff2c2e30), circle.getX(), circle.getBottom(), false));
        g.fillEllipse (circle.reduced (down ? 2.0f : 0.0f));
        g.setColour (on ? colour : quiet);
        g.drawEllipse (circle, 1.2f);
        g.setColour (juce::Colours::black.withAlpha (0.3f));
        g.drawEllipse (circle.reduced (5.0f), 1.0f);
        drawTextLabel (g, ! isEnabled() ? "BASS RIG ONLY" : (on ? "ENGAGED" : "BYPASSED"), { 48, 38, getWidth() - 54, 19 }, 9.0f, on && isEnabled() ? colour : quiet);
    }
private:
    juce::Colour accent;
};
}

struct IronvaleAudioProcessorEditor::Interface final : public juce::Component
{
    explicit Interface (IronvaleAudioProcessorEditor& editor, IronvaleAudioProcessor& owner)
        : processor (owner), tooltip (&editor, 650),
          rig (owner.parameters, "rig", { "Guitar", "Bass" }),
          channel (owner.parameters, "channel", { "Clean", "Edge", "Crunch", "Lead" })
    {
        setLookAndFeel (&look);
        tooltip.setLookAndFeel (&look);
        addAndMakeVisible (rig);
        addAndMakeVisible (channel);
        const juce::StringArray pageNames { "01   AMP & CAB", "02   PEDALBOARD", "03   STEREO ECHO" };
        for (int i = 0; i < 3; ++i)
        {
            tabs[(size_t) i].setButtonText (pageNames[i]);
            tabs[(size_t) i].onClick = [this, i] { setPage (i); };
            addAndMakeVisible (tabs[(size_t) i]);
        }
        setupToggle (bypass, "bypass", "BYPASS RIG", ink, -1, "Bypass the entire signal chain, including amplifier, cabinet and pedals.");
        setupToggle (ampOn, "ampEnabled", "AMP ON", echo, 0, "Enable the preamp, tone stack and power amp.");
        setupToggle (gateOn, "gateEnabled", "GATE ON", ink, 0, "Enable the input noise gate. Adjust threshold and release below.");
        setupToggle (cabOn, "cabEnabled", "CAB ON", echo, 0, "Enable the cabinet stage. Switch off when using an external cabinet processor.");
        setupToggle (sync, "sync", "TEMPO SYNC", space, 2, "Use musical note durations at the host tempo. Turn off for millisecond timing.");
        setupToggle (tails, "spillover", "TAILS", space, 2, "Let repeats decay after bypassing the stereo echo pedal.");
        setupChoice (cabinet, "cabinet", 0, "Cabinet configuration. Original factory cabinet responses or a custom mono impulse response.");
        setupChoice (modPosition, "modPosition", 1, "Place chorus and phaser before the amp or in the post-cabinet FX loop.");
        setupChoice (delayMode, "delayMode", 2, "Select pristine digital, tape-coloured or alternating ping-pong repeats.");
        setupChoice (noteL, "noteL", 2, "Musical note length for the left delay.");
        setupChoice (noteR, "noteR", 2, "Musical note length for the right delay.");
        setupChoice (rhythmL, "rhythmL", 2, "Straight notes, dotted notes (1.5 times) or triplets (two thirds).");
        setupChoice (rhythmR, "rhythmR", 2, "Straight notes, dotted notes (1.5 times) or triplets (two thirds).");

        addControl ("ampGain", "GAIN", echo, 0, "Drive the selected preamp channel from clean headroom to saturation.");
        addControl ("bassDb", "BASS", echo, 0, "Low-frequency tone shaping.");
        addControl ("lowMidDb", "LOW MID", echo, 0, "Cut or boost the sweepable low-mid band.");
        addControl ("midFreq", "MID FREQ", echo, 0, "Centre frequency of the low-mid band.");
        addControl ("highMidDb", "HIGH MID", echo, 0, "Shape articulation and upper-mid bite.");
        addControl ("trebleDb", "TREBLE", echo, 0, "Adjust high-frequency brightness.");
        addControl ("ampMaster", "MASTER", echo, 0, "Drive the power amplifier. Use Output to adjust the final level independently.");
        addControl ("presence", "PRESENCE", echo, 0, "Power-amp high-frequency response.");
        addControl ("resonance", "RESONANCE", echo, 0, "Power-amp low-frequency resonance and weight.");
        addControl ("tight", "TIGHTNESS", echo, 0, "Control low-frequency focus before saturation.");
        addControl ("sag", "SAG", echo, 0, "Amount of power-supply compression and recovery.");
        addControl ("inputDb", "INPUT", ink, 0, "Set the input level before the noise gate and pedalboard.", true);
        addControl ("outputDb", "OUTPUT", ink, 0, "Final output trim. Check the output peak meter for headroom.", true);
        addControl ("gateThreshold", "GATE THRESHOLD", quiet, 0, "Noise-gate opening threshold. Lower values preserve quieter playing.", true);
        addControl ("gateRelease", "GATE RELEASE", quiet, 0, "How gently the gate closes after the input falls below the threshold.", true);
        addControl ("cabMic", "MIC EDGE", echo, 0, "Move the virtual mic character from a brighter centre toward a warmer edge.");
        addControl ("cabRoom", "ROOM", echo, 0, "Blend short stereo room reflections around the cabinet.");
        addControl ("cabLowCut", "LOW CUT", quiet, 0, "Remove cabinet rumble and tighten the lowest frequencies.", true);
        addControl ("cabHighCut", "HIGH CUT", quiet, 0, "Soften cabinet fizz and high-frequency energy.", true);

        addControl ("compThreshold", "THRESHOLD", pedalColours[0], 1, "Level above which the compressor reduces dynamics.");
        addControl ("compRatio", "RATIO", pedalColours[0], 1, "Compression strength above threshold.");
        addControl ("compAttack", "ATTACK", pedalColours[0], 1, "How quickly the compressor reacts to transients.");
        addControl ("compRelease", "RELEASE", pedalColours[0], 1, "How quickly gain recovers after compression.");
        addControl ("compMakeup", "MAKEUP", pedalColours[0], 1, "Restore level after compression.");
        addControl ("compMix", "BLEND", pedalColours[0], 1, "Blend compressed and dry signals for parallel compression.");
        addControl ("odDrive", "DRIVE", pedalColours[1], 1, "Sweep the overdrive pedal from a light edge to strong clipping.");
        addControl ("odTone", "TONE", pedalColours[1], 1, "Adjust overdrive brightness.");
        addControl ("odLevelDb", "LEVEL", pedalColours[1], 1, "Overdrive output level; higher levels push the amplifier harder.");
        addControl ("dirtAmount", "DIRT", pedalColours[2], 1, "Bass-only saturation amount. Increase for a more aggressive texture.");
        addControl ("dirtBlend", "BLEND", pedalColours[2], 1, "Blend bass distortion with the clean low-frequency foundation.");
        addControl ("dirtTone", "TONE", pedalColours[2], 1, "Shape the distorted bass high-frequency content.");
        addControl ("chorusRate", "RATE", pedalColours[3], 1, "Stereo chorus modulation speed.");
        addControl ("chorusDepth", "DEPTH", pedalColours[3], 1, "Stereo chorus pitch movement.");
        addControl ("chorusMix", "MIX", pedalColours[3], 1, "Blend the stereo chorus with the dry signal.");
        addControl ("phaserRate", "RATE", pedalColours[4], 1, "Phaser sweep speed.");
        addControl ("phaserDepth", "DEPTH", pedalColours[4], 1, "Phaser sweep range.");
        addControl ("phaserFeedback", "FEEDBACK", pedalColours[4], 1, "Increase the intensity and resonance of the phaser sweep.");
        addControl ("phaserMix", "MIX", pedalColours[4], 1, "Blend phaser and dry signal.");

        addControl ("timeMsL", "LEFT TIME", space, 2, "Left delay time in milliseconds. Available when Tempo Sync is off.", true);
        addControl ("timeMsR", "RIGHT TIME", space, 2, "Right delay time in milliseconds. Available when Tempo Sync is off.", true);
        addControl ("bpm", "INTERNAL TEMPO", space, 2, "Tempo used when the host supplies no tempo. Tap also sets this value.", true);
        addControl ("feedback", "FEEDBACK", space, 2, "How much of each repeat feeds back into the delay.");
        addControl ("delayMix", "WET MIX", space, 2, "Balance dry signal with stereo delay repeats.");
        addControl ("delayDuck", "DUCKING", space, 2, "Lower repeats under your playing; let them bloom in the spaces.");
        addControl ("delayLowCut", "LOW CUT", space, 2, "Reduce low-frequency energy in the repeats.");
        addControl ("delayHighCut", "HIGH CUT", space, 2, "Darken the repeats for a softer echo.");
        const char* switchIDs[] { "compEnabled", "odEnabled", "dirtEnabled", "chorusEnabled", "phaserEnabled", "delayEnabled" };
        const char* switchNames[] { "COMPRESSOR", "OVERDRIVE", "BASS DIRT", "CHORUS", "PHASER", "STEREO ECHO" };
        for (int i = 0; i < 6; ++i)
        {
            stomps[(size_t) i] = std::make_unique<StompSwitch> (switchNames[i], pedalColours[(size_t) i]);
            addAndMakeVisible (*stomps[(size_t) i]);
            buttonAttachments.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>
                (processor.parameters, switchIDs[i], *stomps[(size_t) i]));
        }
        preset.setName ("Factory preset");
        preset.setTitle ("Factory preset");
        preset.setTooltip ("Load a complete factory rig, including amp, cabinet and pedals.");
        preset.addItemList (processor.getFactoryPresetNames(), 1);
        preset.setSelectedItemIndex (processor.getCurrentProgram(), juce::dontSendNotification);
        preset.onChange = [this]
        {
            if (preset.getSelectedItemIndex() >= 0)
            {
                processor.loadFactoryPreset (preset.getSelectedItemIndex());
                currentProgram = processor.getCurrentProgram();
                status = "FACTORY RIG";
                update();
                repaint();
            }
        };
        addAndMakeVisible (preset);
        setupAction (save, "SAVE", -1, "Save all rig controls and any imported cabinet to an Ironvale preset.", [this] { chooseFile (1); });
        setupAction (load, "LOAD", -1, "Load an Ironvale preset.", [this] { chooseFile (0); });
        setupAction (loadIR, "IMPORT IR", 0, "Import a WAV or AIFF cabinet impulse response. The cabinet uses a mono response up to 2048 samples.", [this] { chooseFile (2); });
        setupAction (tap, "TAP", 2, "Tap quarter notes for the internal tempo. Host tempo takes priority when available.", [this] { processor.tapTempo(); });
        setupAction (panic, "CLEAR TAILS", -1, "Reset all effect history immediately, including echo and cabinet room tails.", [this] { processor.requestPanic(); });
        currentProgram = processor.getCurrentProgram();
        setPage (0);
        update();
    }

    ~Interface() override
    {
        chooser.reset();
        for (auto& item : controls) item->slider.setLookAndFeel (nullptr);
        tooltip.setLookAndFeel (nullptr);
        setLookAndFeel (nullptr);
    }
    const ironvale::ParameterSpec& spec (const juce::String& id) const
    {
        for (const auto& p : ironvale::parameterSpecs) if (id == p.id) return p;
        jassertfalse;
        return ironvale::parameterSpecs.front();
    }
    void addToPage (juce::Component& component, int page)
    {
        addAndMakeVisible (component);
        if (page >= 0) pageMembers.emplace_back (&component, page);
    }
    void setupChoice (juce::ComboBox& box, const juce::String& id, int page, const juce::String& tip)
    {
        const auto& p = spec (id);
        box.addItemList (juce::StringArray::fromTokens (p.choices, "|", ""), 1);
        box.setName (p.name);
        box.setTitle (p.name);
        box.setTooltip (tip);
        box.setWantsKeyboardFocus (true);
        addToPage (box, page);
        comboAttachments.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (processor.parameters, id, box));
    }
    void setupToggle (juce::TextButton& button, const juce::String& id, const juce::String& title,
                      juce::Colour accent, int page, const juce::String& tip)
    {
        button.setButtonText (title);
        button.setName (spec (id).name);
        button.setClickingTogglesState (true);
        button.setColour (juce::TextButton::buttonOnColourId, accent);
        button.setTooltip (tip);
        button.setWantsKeyboardFocus (true);
        addToPage (button, page);
        buttonAttachments.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.parameters, id, button));
    }
    void setupAction (juce::TextButton& button, const juce::String& title, int page,
                      const juce::String& tip, std::function<void()> action)
    {
        button.setButtonText (title);
        button.setTooltip (tip);
        button.setWantsKeyboardFocus (true);
        button.onClick = std::move (action);
        addToPage (button, page);
    }
    void addControl (const juce::String& id, const juce::String& title, juce::Colour accent,
                     int page, const juce::String& tip, bool compact = false)
    {
        juce::String unit = spec (id).unit;
        if (id == "chorusRate" || id == "phaserRate") unit = "rate";
        auto item = std::make_unique<ParameterControl> (processor.parameters, id, title, unit, accent, tip, compact);
        addToPage (*item, page);
        item->slider.setLookAndFeel (&look);
        ids.push_back (id);
        controls.push_back (std::move (item));
    }
    ParameterControl& control (const juce::String& id)
    {
        for (size_t i = 0; i < ids.size(); ++i) if (ids[i] == id) return *controls[i];
        jassertfalse;
        return *controls.front();
    }
    float value (const char* id) const
    {
        if (const auto* p = processor.parameters.getRawParameterValue (id)) return p->load (std::memory_order_relaxed);
        return 0.0f;
    }
    void setPage (int page)
    {
        activePage = page;
        for (const auto& member : pageMembers) member.first->setVisible (member.second == page);
        for (int i = 0; i < 3; ++i) tabs[(size_t) i].setToggleState (i == page, juce::dontSendNotification);
        repaint();
    }
    double delayTime (bool right) const
    {
        if (value ("sync") < 0.5f) return value (right ? "timeMsR" : "timeMsL");
        const double beats[] { 0.0625, 0.125, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0 };
        const double rhythms[] { 1.0, 1.5, 2.0 / 3.0 };
        return juce::jlimit (1.0, 8000.0, 60000.0 / juce::jmax (20.0, processor.currentBpm.load())
            * beats[juce::jlimit (0, 7, (int) value (right ? "noteR" : "noteL"))]
            * rhythms[juce::jlimit (0, 2, (int) value (right ? "rhythmR" : "rhythmL"))]);
    }
    void update()
    {
        const bool bass = value ("rig") > 0.5f;
        const bool synced = value ("sync") > 0.5f;
        const bool hostTempo = processor.hostTempoActive.load();
        ampOn.setButtonText (value ("ampEnabled") > 0.5f ? "AMP ON" : "AMP OFF");
        cabOn.setButtonText (value ("cabEnabled") > 0.5f ? "CAB ON" : "CAB OFF");
        gateOn.setButtonText (value ("gateEnabled") > 0.5f ? "GATE ON" : "GATE OFF");
        for (auto* id : { "dirtAmount", "dirtBlend", "dirtTone" }) control (id).setEnabled (bass);
        stomps[2]->setEnabled (bass);
        for (auto* box : { &noteL, &noteR, &rhythmL, &rhythmR }) box->setEnabled (synced);
        control ("timeMsL").setEnabled (! synced);
        control ("timeMsR").setEnabled (! synced);
        control ("bpm").setEnabled (! hostTempo);
        tap.setEnabled (! hostTempo);
        const auto input = juce::jlimit (0.0f, 8.0f, processor.inputPeak.load());
        const auto output = juce::jlimit (0.0f, 8.0f, processor.outputPeak.load());
        inputMeter = juce::jmax (input, inputMeter * 0.86f);
        outputMeter = juce::jmax (output, outputMeter * 0.86f);
        clipFrames = output >= 1.0f ? 36 : juce::jmax (0, clipFrames - 1);
        if (processor.getCurrentProgram() != currentProgram)
        {
            currentProgram = processor.getCurrentProgram();
            preset.setSelectedItemIndex (currentProgram, juce::dontSendNotification);
            status = "FACTORY RIG";
            repaint();
        }
        const auto newCab = (int) value ("cabinet");
        const auto newRig = (int) value ("rig");
        const auto irName = processor.getCabinetIRName();
        if (newCab != lastCab || newRig != lastRig || irName != lastIR)
        {
            lastCab = newCab; lastRig = newRig; lastIR = irName;
            repaint();
        }
        repaint (923, 24, 229, 64);
        repaint (28, 653, 1124, 24);
        if (activePage == 1) repaint (45, 603, 190, 14);
        if (activePage == 2)
        {
            repaint (48, 366, 504, 30);
            repaint (48, 535, 190, 69);
        }
    }

    void resized() override
    {
        preset.setBounds (328, 42, 350, 34);
        save.setBounds (690, 42, 66, 34);
        load.setBounds (764, 42, 66, 34);
        rig.setBounds (28, 117, 256, 42);
        channel.setBounds (335, 117, 500, 42);
        bypass.setBounds (1008, 117, 144, 42);
        for (int i = 0; i < 3; ++i) tabs[(size_t) i].setBounds (28 + i * 198, 180, 186, 32);
        panic.setBounds (1010, 180, 142, 32);
        ampOn.setBounds (546, 246, 94, 30);
        gateOn.setBounds (650, 246, 108, 30);
        cabOn.setBounds (1044, 246, 88, 30);
        const char* top[] { "ampGain", "bassDb", "lowMidDb", "midFreq", "highMidDb", "trebleDb" };
        for (int i = 0; i < 6; ++i) control (top[i]).setBounds (42 + i * 122, 290, 112, 115);
        const char* power[] { "ampMaster", "presence", "resonance", "tight", "sag" };
        for (int i = 0; i < 5; ++i) control (power[i]).setBounds (63 + i * 142, 430, 112, 115);
        control ("inputDb").setBounds (48, 573, 164, 53);
        control ("outputDb").setBounds (230, 573, 164, 53);
        control ("gateThreshold").setBounds (412, 573, 164, 53);
        control ("gateRelease").setBounds (594, 573, 164, 53);
        cabinet.setBounds (820, 288, 312, 34);
        control ("cabMic").setBounds (977, 335, 76, 108);
        control ("cabRoom").setBounds (1058, 335, 76, 108);
        loadIR.setBounds (820, 479, 106, 31);
        control ("cabLowCut").setBounds (820, 525, 312, 48);
        control ("cabHighCut").setBounds (820, 581, 312, 48);
        const char* comp[] { "compThreshold", "compRatio", "compAttack", "compRelease", "compMakeup", "compMix" };
        const char* drive[] { "odDrive", "odTone", "odLevelDb" };
        const char* dirt[] { "dirtAmount", "dirtBlend", "dirtTone" };
        const char* chorus[] { "chorusRate", "chorusDepth", "chorusMix" };
        const char* phaser[] { "phaserRate", "phaserDepth", "phaserFeedback", "phaserMix" };
        auto placePedal = [this] (const char** names, int n, int column)
        {
            for (int i = 0; i < n; ++i)
                control (names[i]).setBounds (40 + column * 228 + (i % 2) * 98, 277 + (i / 2) * 108, 94, 104);
        };
        placePedal (comp, 6, 0); placePedal (drive, 3, 1); placePedal (dirt, 3, 2);
        placePedal (chorus, 3, 3); placePedal (phaser, 4, 4);
        modPosition.setBounds (910, 624, 242, 30);
        delayMode.setBounds (332, 246, 222, 34);
        sync.setBounds (48, 308, 140, 32);
        tails.setBounds (200, 308, 100, 32);
        tap.setBounds (452, 308, 102, 32);
        noteL.setBounds (48, 403, 98, 34);
        rhythmL.setBounds (156, 403, 132, 34);
        noteR.setBounds (314, 403, 98, 34);
        rhythmR.setBounds (422, 403, 132, 34);
        control ("timeMsL").setBounds (48, 457, 240, 57);
        control ("timeMsR").setBounds (314, 457, 240, 57);
        control ("bpm").setBounds (270, 550, 284, 58);
        control ("feedback").setBounds (622, 306, 150, 142);
        control ("delayMix").setBounds (800, 306, 150, 142);
        control ("delayDuck").setBounds (978, 306, 150, 142);
        control ("delayLowCut").setBounds (708, 478, 150, 142);
        control ("delayHighCut").setBounds (894, 478, 150, 142);
        for (int i = 0; i < 6; ++i) stomps[(size_t) i]->setBounds (28 + i * 190, 687, 174, 70);
    }
    void card (juce::Graphics& g, juce::Rectangle<float> area)
    {
        g.setColour (juce::Colours::black.withAlpha (0.24f));
        g.fillRoundedRectangle (area.translated (0.0f, 3.0f), 9.0f);
        g.setColour (surface);
        g.fillRoundedRectangle (area, 9.0f);
        g.setColour (edge.withAlpha (0.8f));
        g.drawRoundedRectangle (area.reduced (0.5f), 9.0f, 1.0f);
    }
    void heading (juce::Graphics& g, const juce::String& text, int x, int y, int width, juce::Colour colour = echo)
    {
        g.setColour (colour);
        g.fillRect (x, y + 4, 3, 18);
        drawTextLabel (g, text, { x + 14, y, width - 14, 26 }, 16.0f, ink, juce::Justification::centredLeft, true);
    }
    void paint (juce::Graphics& g) override
    {
        g.fillAll (background);
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff25272a), 0.0f, 0.0f, background, 1180.0f, 400.0f, false));
        g.fillRect (0, 0, 1180, 169);
        for (int y = 0; y < 100; y += 3)
        {
            g.setColour (ink.withAlpha (0.012f));
            g.drawHorizontalLine (y, 0.0f, 1180.0f);
        }
        g.setColour (echo);
        juce::Path mark;
        mark.startNewSubPath (31.0f, 35.0f); mark.lineTo (44.0f, 63.0f); mark.lineTo (57.0f, 35.0f);
        mark.startNewSubPath (32.0f, 61.0f); mark.lineTo (44.0f, 35.0f); mark.lineTo (56.0f, 61.0f);
        g.strokePath (mark, juce::PathStrokeType (2.0f));
        drawTextLabel (g, "IRONVALE", { 72, 26, 235, 42 }, 31.0f, ink, juce::Justification::centredLeft, true);
        drawTextLabel (g, "GUITAR + BASS AMPLIFICATION", { 74, 67, 250, 15 }, 9.0f, quiet);
        drawTextLabel (g, status, { 329, 22, 500, 15 }, 9.0f, quiet);
        drawTextLabel (g, "INSTRUMENT", { 29, 98, 240, 15 }, 9.0f, quiet);
        drawTextLabel (g, "AMPLIFIER CHANNEL", { 336, 98, 490, 15 }, 9.0f, quiet);
        drawTextLabel (g, "GLOBAL", { 1009, 98, 142, 15 }, 9.0f, quiet);
        g.setColour (edge);
        g.drawHorizontalLine (168, 28.0f, 1152.0f);
        drawMeter (g, 930, 29, "IN", inputMeter, false);
        drawMeter (g, 930, 59, "OUT", outputMeter, clipFrames > 0);
        if (activePage == 0) drawAmpPage (g);
        if (activePage == 1) drawPedalPage (g);
        if (activePage == 2) drawEchoPage (g);
        drawTextLabel (g, value ("modPosition") < 0.5f
            ? "INPUT  >  GATE  >  COMP  >  DRIVE / BASS DIRT  >  CHORUS  >  PHASER  >  AMP  >  CAB  >  STEREO ECHO"
            : "INPUT  >  GATE  >  COMP  >  DRIVE / BASS DIRT  >  AMP  >  CAB  >  CHORUS  >  PHASER  >  STEREO ECHO",
            { 29, 660, 1123, 17 }, 9.0f, quiet);
        drawTextLabel (g, "ORIGINAL AMP MODELS  /  STEREO PEDALBOARD", { 29, 775, 530, 15 }, 9.0f, quiet.withAlpha (0.75f));
        drawTextLabel (g, "DOUBLE-CLICK TO RESET  /  TYPE VALUES FOR PRECISION", { 630, 775, 522, 15 }, 9.0f, quiet.withAlpha (0.75f), juce::Justification::centredRight);
    }
    void drawAmpPage (juce::Graphics& g)
    {
        card (g, { 28.0f, 228.0f, 756.0f, 418.0f });
        card (g, { 800.0f, 228.0f, 352.0f, 418.0f });
        heading (g, value ("rig") > 0.5f ? "BASS AMPLIFIER" : "GUITAR AMPLIFIER", 48, 246, 480);
        heading (g, "CABINET", 820, 246, 206);
        g.setColour (edge.withAlpha (0.7f));
        g.drawHorizontalLine (417, 48.0f, 764.0f);
        g.drawHorizontalLine (560, 48.0f, 764.0f);
        drawCabinet (g, { 820.0f, 337.0f, 145.0f, 130.0f });
        const auto irName = processor.getCabinetIRName();
        drawTextLabel (g, irName, { 936, 479, 196, 31 }, 10.0f, irName.startsWithIgnoreCase ("IR load failed") ? juce::Colour (0xffe09585) : quiet);
    }
    void drawCabinet (juce::Graphics& g, juce::Rectangle<float> area)
    {
        const int selected = (int) value ("cabinet");
        const int speakers = selected <= 1 ? 1 : (selected <= 3 ? 2 : (selected <= 5 ? 4 : 8));
        if (selected == 7)
        {
            g.setColour (echo.withAlpha (0.1f));
            g.fillRoundedRectangle (area, 5.0f);
            g.setColour (echo.withAlpha (0.7f));
            g.drawRoundedRectangle (area.reduced (0.5f), 5.0f, 1.0f);
            drawTextLabel (g, "USER", area.toNearestInt().withHeight (55).translated (0, 18), 21.0f, ink, juce::Justification::centred, true);
            drawTextLabel (g, "CABINET IR", area.toNearestInt().withHeight (18).translated (0, 77), 9.0f, echo, juce::Justification::centred);
            return;
        }
        auto box = area.reduced (speakers == 1 ? 24.0f : 11.0f, 2.0f);
        g.setColour (juce::Colour (0xff0c0d0e));
        g.fillRoundedRectangle (box, 4.0f);
        g.setColour (juce::Colour (0xff424447));
        g.drawRoundedRectangle (box, 4.0f, 1.5f);
        g.setColour (quiet.withAlpha (0.10f));
        for (float x = box.getX() + 6.0f; x < box.getRight() - 4.0f; x += 4.0f)
            g.drawVerticalLine ((int) x, box.getY() + 5.0f, box.getBottom() - 5.0f);
        const int columns = speakers > 1 ? 2 : 1;
        const int rows = speakers / columns;
        auto grille = box.reduced (7.0f, 8.0f);
        const float cellW = grille.getWidth() / (float) columns, cellH = grille.getHeight() / (float) rows;
        const float diameter = juce::jmin (cellW, cellH) - 7.0f;
        for (int row = 0; row < rows; ++row)
            for (int col = 0; col < columns; ++col)
            {
                const auto disc = juce::Rectangle<float> (diameter, diameter).withCentre
                    ({ grille.getX() + ((float) col + 0.5f) * cellW, grille.getY() + ((float) row + 0.5f) * cellH });
                g.setColour (juce::Colour (0xff282a2d));
                g.fillEllipse (disc);
                g.setColour (echo.withAlpha (0.5f));
                g.drawEllipse (disc, 1.0f);
                g.setColour (quiet.withAlpha (0.28f));
                g.drawEllipse (disc.reduced (diameter * 0.13f), 1.0f);
                g.setColour (juce::Colour (0xff101214));
                g.fillEllipse (disc.reduced (diameter * 0.31f));
            }
        for (auto x : { box.getX() + 4.0f, box.getRight() - 4.0f })
            for (auto y : { box.getY() + 4.0f, box.getBottom() - 4.0f })
            {
                g.setColour (quiet.withAlpha (0.7f));
                g.fillEllipse (x - 1.0f, y - 1.0f, 2.0f, 2.0f);
            }
    }
    void drawPedalPage (juce::Graphics& g)
    {
        const char* names[] { "COMPRESSOR", "OVERDRIVE", "BASS DIRT", "CHORUS", "PHASER" };
        for (int i = 0; i < 5; ++i)
        {
            card (g, { 28.0f + (float) i * 228.0f, 228.0f, 212.0f, 390.0f });
            heading (g, names[i], 44 + i * 228, 243, 185, pedalColours[(size_t) i]);
        }
        const float reduction = std::abs (processor.compressionDb.load());
        drawTextLabel (g, "GAIN REDUCTION  " + juce::String (reduction, 1) + " dB", { 44, 603, 182, 14 }, 8.5f, pedalColours[0]);
        pedalNote (g, 1, "LIGHT PUSH TO HEAVY DRIVE", "Use Level to push the amp.\nDrive adds pedal saturation.");
        pedalNote (g, 2, value ("rig") > 0.5f ? "BASS DIRT AVAILABLE" : "SELECT THE BASS RIG", "Add grit while keeping\na clean low-end foundation.");
        pedalNote (g, 3, "WIDTH & MOVEMENT", "A stereo chorus for subtle\nthickening or a wide shimmer.");
        pedalNote (g, 4, "SWEPT PHASE", "Sweep, depth and resonance.\nBlend to preserve your attack.");
        drawTextLabel (g, "CHORUS + PHASER LOCATION", { 628, 628, 267, 18 }, 10.0f, quiet, juce::Justification::centredRight);
    }
    void pedalNote (juce::Graphics& g, int column, const juce::String& title, const juce::String& body)
    {
        const int x = 44 + column * 228;
        g.setColour (edge);
        g.drawHorizontalLine (520, (float) x, (float) x + 180.0f);
        drawTextLabel (g, title, { x, 538, 180, 18 }, 8.5f, pedalColours[(size_t) column], juce::Justification::centredLeft, true);
        g.setFont (face (11.0f));
        g.setColour (quiet);
        g.drawFittedText (body, { x, 563, 180, 39 }, juce::Justification::centredLeft, 2);
    }
    void drawEchoPage (juce::Graphics& g)
    {
        card (g, { 28.0f, 228.0f, 546.0f, 418.0f });
        card (g, { 590.0f, 228.0f, 562.0f, 418.0f });
        heading (g, "STEREO ECHO", 48, 246, 270, space);
        heading (g, "REPEATS & TONE", 612, 246, 510, space);
        drawTextLabel (g, "LEFT", { 48, 371, 110, 18 }, 10.0f, quiet, juce::Justification::centredLeft, true);
        drawTextLabel (g, "RIGHT", { 314, 371, 110, 18 }, 10.0f, quiet, juce::Justification::centredLeft, true);
        drawTextLabel (g, juce::String (delayTime (false), 1) + " ms", { 158, 371, 130, 18 }, 11.0f, space, juce::Justification::centredRight);
        drawTextLabel (g, juce::String (delayTime (true), 1) + " ms", { 424, 371, 130, 18 }, 11.0f, space, juce::Justification::centredRight);
        g.setColour (edge);
        g.drawHorizontalLine (531, 48.0f, 554.0f);
        drawTextLabel (g, processor.hostTempoActive.load() ? "HOST TEMPO" : "INTERNAL TEMPO", { 48, 546, 190, 18 }, 9.0f, quiet);
        drawTextLabel (g, juce::String (processor.currentBpm.load(), 1), { 47, 567, 155, 36 }, 31.0f, ink);
        drawTextLabel (g, "BPM", { 191, 579, 48, 18 }, 9.0f, quiet);
        drawTextLabel (g, "STRAIGHT  /  DOTTED  /  TRIPLET    -    8 SECOND MAXIMUM", { 48, 622, 507, 14 }, 9.0f, quiet);
    }
    void drawMeter (juce::Graphics& g, int x, int y, const juce::String& label, float peak, bool clipping)
    {
        const auto db = juce::Decibels::gainToDecibels (peak, -60.0f);
        const auto fraction = juce::jlimit (0.0f, 1.0f, (db + 60.0f) / 60.0f);
        drawTextLabel (g, label, { x, y, 32, 17 }, 9.0f, quiet);
        for (int i = 0; i < 20; ++i)
        {
            const auto colour = i >= 18 ? juce::Colour (0xffe09585) : (i >= 15 ? echo : space);
            g.setColour (fraction > (float) i / 20.0f ? colour : edge);
            g.fillRoundedRectangle ((float) x + 37.0f + (float) i * 6.3f, (float) y + 3.0f, 4.5f, 10.0f, 0.5f);
        }
        drawTextLabel (g, clipping ? "CLIP" : (db <= -59.9f ? "-inf" : juce::String (db, 1)),
                       { x + 170, y, 49, 17 }, 10.0f, clipping ? juce::Colour (0xffe09585) : quiet, juce::Justification::centredRight);
    }
    void chooseFile (int kind)
    {
        if (chooser != nullptr) return;
        const bool saving = kind == 1;
        const bool importing = kind == 2;
        const auto initial = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory)
            .getChildFile (saving ? "Ironvale Rig.ironvale" : "");
        chooser = std::make_unique<juce::FileChooser> (importing ? "Import cabinet impulse response" : (saving ? "Save Ironvale rig" : "Load Ironvale rig"),
            initial, importing ? "*.wav;*.aif;*.aiff" : "*.ironvale", true);
        const int flags = saving ? juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles | juce::FileBrowserComponent::warnAboutOverwriting
                                 : juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles;
        const juce::Component::SafePointer<Interface> safe (this);
        chooser->launchAsync (flags, [safe, kind] (const juce::FileChooser& dialog)
        {
            if (safe == nullptr) return;
            auto selected = dialog.getResult();
            if (selected != juce::File())
            {
                if (kind == 2)
                {
                    safe->processor.loadCabinetIR (selected);
                    safe->status = safe->processor.getCabinetIRName();
                }
                else if (kind == 1)
                {
                    selected = selected.withFileExtension ("ironvale");
                    const bool saved = safe->processor.savePresetToFile (selected);
                    safe->status = saved ? "SAVED / " + selected.getFileNameWithoutExtension().toUpperCase() : "PRESET COULD NOT BE SAVED";
                }
                else if (safe->processor.loadPresetFromFile (selected))
                {
                    safe->preset.setSelectedId (0, juce::dontSendNotification);
                    safe->preset.setText (selected.getFileNameWithoutExtension(), juce::dontSendNotification);
                    safe->currentProgram = safe->processor.getCurrentProgram();
                    safe->status = "USER RIG";
                }
                else safe->status = "INVALID OR UNREADABLE PRESET";
                safe->update();
                safe->repaint();
            }
            juce::MessageManager::callAsync ([safe] { if (safe != nullptr) safe->chooser.reset(); });
        });
    }
    IronvaleAudioProcessor& processor;
    IronvaleLookAndFeel look;
    juce::TooltipWindow tooltip;
    ChoiceSegments rig, channel;
    const std::array<juce::Colour, 6> pedalColours {{ juce::Colour (0xffb7b6ca), juce::Colour (0xffce956b),
        juce::Colour (0xffc5b073), juce::Colour (0xff8bbdb4), juce::Colour (0xff8baec6), juce::Colour (0xffa6c1bc) }};
    std::array<juce::TextButton, 3> tabs;
    std::array<std::unique_ptr<StompSwitch>, 6> stomps;
    juce::ComboBox preset, cabinet, modPosition, delayMode, noteL, noteR, rhythmL, rhythmR;
    juce::TextButton save, load, loadIR, tap, panic, bypass, ampOn, cabOn, gateOn, sync, tails;
    std::vector<std::pair<juce::Component*, int>> pageMembers;
    std::vector<juce::String> ids;
    std::vector<std::unique_ptr<ParameterControl>> controls;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAttachments;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAttachments;
    std::unique_ptr<juce::FileChooser> chooser;
    juce::String status { "FACTORY RIG" }, lastIR;
    int activePage = 0, currentProgram = -1, clipFrames = 0, lastCab = -1, lastRig = -1;
    float inputMeter = 0.0f, outputMeter = 0.0f;
};

IronvaleAudioProcessorEditor::IronvaleAudioProcessorEditor (IronvaleAudioProcessor& owner)
    : juce::AudioProcessorEditor (&owner), ui (std::make_unique<Interface> (*this, owner))
{
    setOpaque (true);
    addAndMakeVisible (*ui);
    setResizable (true, true);
    setResizeLimits (944, 640, 1652, 1120);
    getConstrainer()->setFixedAspectRatio (1180.0 / 800.0);
    setSize (1180, 800);
    startTimerHz (24);
}
IronvaleAudioProcessorEditor::~IronvaleAudioProcessorEditor()
{
    stopTimer();
    ui.reset();
}
void IronvaleAudioProcessorEditor::paint (juce::Graphics& g) { g.fillAll (background); }
void IronvaleAudioProcessorEditor::resized()
{
    if (ui != nullptr)
    {
        const auto scale = juce::jmin ((float) getWidth() / 1180.0f, (float) getHeight() / 800.0f);
        ui->setTransform (juce::AffineTransform::scale (scale));
        ui->setBounds (0, 0, 1180, 800);
    }
}
void IronvaleAudioProcessorEditor::timerCallback() { ui->update(); }
