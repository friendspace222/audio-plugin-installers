#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>
#include <cstring>
#include <numeric>
#include <utility>

namespace {
using P=ironvale::Param;
struct Preset { const char* name; std::vector<std::pair<P,float>> values; };
const std::vector<Preset>& factory()
{
    static const std::vector<Preset> presets {
        {"01  Glasshouse Clean",{{P::cabinet,0},{P::ampGain,2.5f},{P::cabLowCut,60},{P::trebleDb,1.5f},{P::outputDb,-3}}},
        {"02  Studio Sparkle",{{P::cabinet,2},{P::ampGain,3},{P::compEnabled,1},{P::compMix,65},{P::compThreshold,-24},{P::chorusEnabled,1},{P::chorusMix,18},{P::presence,58},{P::outputDb,-3}}},
        {"03  Edge of Midnight",{{P::channel,1},{P::ampGain,4.5f},{P::cabinet,1},{P::sag,50},{P::bassDb,1},{P::trebleDb,-1}}},
        {"04  Small Club Blues",{{P::channel,1},{P::ampGain,6},{P::cabinet,2},{P::odEnabled,1},{P::odDrive,20},{P::odTone,38},{P::midFreq,650},{P::lowMidDb,2.5f},{P::sag,65},{P::outputDb,-7}}},
        {"05  Copper Crunch",{{P::channel,2},{P::ampGain,5},{P::cabinet,4},{P::highMidDb,2},{P::resonance,45},{P::outputDb,-12},{P::sag,45},{P::tight,35},{P::cabLowCut,45},{P::lowMidDb,1.5f},{P::midFreq,650}}},
        {"06  Arena Rhythm",{{P::channel,2},{P::ampGain,7},{P::cabinet,4},{P::tight,65},{P::presence,58},{P::bassDb,1.5f},{P::outputDb,-12},{P::sag,35},{P::cabLowCut,45},{P::lowMidDb,1},{P::midFreq,650}}},
        {"07  Modern Steel",{{P::channel,3},{P::ampGain,6.5f},{P::cabinet,5},{P::tight,80},{P::gateThreshold,-52},{P::odEnabled,1},{P::odDrive,10},{P::odLevelDb,3},{P::lowMidDb,-0.5f},{P::highMidDb,1.5f},{P::resonance,65},{P::outputDb,-13},{P::cabLowCut,40},{P::midFreq,450},{P::sag,20}}},
        {"08  Low Tuned Atlas",{{P::channel,3},{P::ampGain,5.5f},{P::cabinet,5},{P::tight,90},{P::gateThreshold,-50},{P::gateRelease,55},{P::cabLowCut,38},{P::cabHighCut,6500},{P::lowMidDb,-0.5f},{P::resonance,70},{P::outputDb,-14},{P::midFreq,450},{P::highMidDb,1.5f},{P::sag,15}}},
        {"09  Singing Lead",{{P::channel,3},{P::ampGain,7},{P::cabinet,4},{P::lowMidDb,3},{P::midFreq,900},{P::delayEnabled,1},{P::feedback,30},{P::delayMix,20},{P::delayDuck,45},{P::sag,45},{P::outputDb,-10}}},
        {"10  Dotted Skyline",{{P::ampGain,3},{P::cabinet,3},{P::delayEnabled,1},{P::noteL,3},{P::noteR,3},{P::rhythmL,1},{P::rhythmR,1},{P::feedback,48},{P::delayMix,32},{P::chorusEnabled,1},{P::chorusMix,16},{P::outputDb,-3}}},
        {"11  Phase Motion",{{P::channel,2},{P::ampGain,4.5f},{P::cabinet,4},{P::phaserEnabled,1},{P::modPosition,0},{P::phaserRate,.35f},{P::phaserDepth,80},{P::phaserMix,48},{P::outputDb,-11}}},
        {"12  Triplet Lead",{{P::channel,3},{P::ampGain,6},{P::cabinet,5},{P::delayEnabled,1},{P::noteL,3},{P::noteR,4},{P::rhythmL,2},{P::rhythmR,2},{P::feedback,38},{P::delayMix,26},{P::outputDb,-10}}},
        {"13  Bass / Clear Foundation",{{P::rig,1},{P::cabinet,1},{P::ampGain,3},{P::bassDb,2},{P::cabLowCut,30},{P::cabHighCut,9000},{P::midFreq,400},{P::presence,30},{P::tight,15},{P::compEnabled,1},{P::compThreshold,-20},{P::compAttack,25},{P::compMix,65},{P::outputDb,-4},{P::gateThreshold,-75},{P::gateRelease,180}}},
        {"14  Bass / Warm 2x12",{{P::rig,1},{P::channel,1},{P::cabinet,3},{P::ampGain,4},{P::cabLowCut,30},{P::cabHighCut,6000},{P::bassDb,2},{P::lowMidDb,1.5f},{P::midFreq,350},{P::tight,20},{P::outputDb,-6},{P::presence,30},{P::gateThreshold,-75},{P::gateRelease,180}}},
        {"15  Bass / 4x12 Punch",{{P::rig,1},{P::channel,1},{P::cabinet,5},{P::ampGain,4.5f},{P::cabLowCut,28},{P::resonance,60},{P::lowMidDb,2},{P::midFreq,500},{P::compEnabled,1},{P::compAttack,30},{P::outputDb,-7},{P::tight,15},{P::presence,30},{P::gateThreshold,-75},{P::gateRelease,180}}},
        {"16  Bass / 8x12 Monument",{{P::rig,1},{P::cabinet,6},{P::ampGain,4},{P::cabLowCut,25},{P::bassDb,3},{P::lowMidDb,1},{P::midFreq,300},{P::resonance,70},{P::presence,30},{P::tight,10},{P::outputDb,-6},{P::gateThreshold,-75},{P::gateRelease,180}}},
        {"17  Bass / Grain & Weight",{{P::rig,1},{P::channel,1},{P::cabinet,3},{P::ampGain,4},{P::cabLowCut,30},{P::dirtEnabled,1},{P::dirtAmount,35},{P::dirtBlend,40},{P::dirtTone,40},{P::tight,20},{P::outputDb,-7},{P::presence,30},{P::gateThreshold,-75},{P::gateRelease,180}}},
        {"18  Bass / Broken Concrete",{{P::rig,1},{P::channel,2},{P::cabinet,6},{P::ampGain,5},{P::cabLowCut,25},{P::dirtEnabled,1},{P::dirtAmount,82},{P::dirtBlend,70},{P::dirtTone,60},{P::highMidDb,2},{P::tight,25},{P::outputDb,-10},{P::presence,35},{P::gateThreshold,-70},{P::gateRelease,180}}},
        {"19  Bass / Chorus Current",{{P::rig,1},{P::cabinet,3},{P::ampGain,3},{P::cabLowCut,30},{P::chorusEnabled,1},{P::chorusRate,.5f},{P::chorusDepth,45},{P::chorusMix,22},{P::delayEnabled,1},{P::delayMix,12},{P::feedback,22},{P::outputDb,-4},{P::presence,30},{P::tight,15},{P::gateThreshold,-75},{P::gateRelease,180}}},
        {"20  Bass / Slap Definition",{{P::rig,1},{P::cabinet,6},{P::ampGain,2.5f},{P::cabLowCut,28},{P::bassDb,2.5f},{P::lowMidDb,-4},{P::midFreq,500},{P::trebleDb,2},{P::presence,65},{P::compEnabled,1},{P::compThreshold,-24},{P::compRatio,5},{P::compAttack,20},{P::compMix,70},{P::outputDb,-5},{P::tight,15},{P::gateThreshold,-75},{P::gateRelease,180}}},
        {"21  American Glass / Clean",{{P::speakerModel,1},{P::ampModel,1},{P::channel,0},{P::cabinet,2},{P::ampGain,3.0f},{P::ampMaster,5},{P::presence,42},{P::resonance,30},{P::sag,15},{P::tight,20},{P::cabLowCut,55},{P::cabHighCut,10000},{P::cabMic,25},{P::cabRoom,7},{P::gateThreshold,-75},{P::outputDb,2.5f}}},
        {"22  American Glass / Breakup",{{P::speakerModel,1},{P::ampModel,1},{P::channel,1},{P::cabinet,0},{P::ampGain,6},{P::ampMaster,6},{P::presence,42},{P::resonance,35},{P::sag,38},{P::tight,25},{P::cabLowCut,50},{P::cabHighCut,8500},{P::cabMic,35},{P::cabRoom,7},{P::gateThreshold,-75},{P::outputDb,-3.2f}}},
        {"23  British Stack / Classic",{{P::speakerModel,2},{P::ampModel,2},{P::channel,2},{P::cabinet,4},{P::ampGain,5.2f},{P::ampMaster,6.5f},{P::presence,48},{P::resonance,42},{P::sag,40},{P::tight,42},{P::cabLowCut,45},{P::cabHighCut,8500},{P::cabMic,35},{P::cabRoom,5},{P::gateThreshold,-70},{P::outputDb,-8.9f}}},
        {"24  British Stack / Hot",{{P::speakerModel,2},{P::ampModel,2},{P::channel,3},{P::cabinet,4},{P::ampGain,6.5f},{P::ampMaster,5},{P::presence,52},{P::resonance,45},{P::sag,25},{P::tight,60},{P::cabLowCut,45},{P::cabHighCut,8000},{P::cabMic,38},{P::cabRoom,5},{P::gateThreshold,-65},{P::outputDb,-7.9f}}},
        {"25  Citrus Drive / Crunch",{{P::speakerModel,3},{P::ampModel,3},{P::channel,2},{P::cabinet,3},{P::ampGain,4.8f},{P::ampMaster,5.5f},{P::presence,40},{P::resonance,48},{P::sag,50},{P::tight,25},{P::cabLowCut,42},{P::cabHighCut,7500},{P::cabMic,35},{P::cabRoom,5},{P::gateThreshold,-72},{P::outputDb,-8.6f}}},
        {"26  Citrus Drive / Heavy",{{P::speakerModel,5},{P::ampModel,3},{P::channel,3},{P::cabinet,4},{P::ampGain,6.2f},{P::ampMaster,5},{P::presence,45},{P::resonance,52},{P::sag,40},{P::tight,45},{P::cabLowCut,42},{P::cabHighCut,7200},{P::cabMic,40},{P::cabRoom,5},{P::gateThreshold,-65},{P::outputDb,-4.2f}}},
        {"27  California Heavy / Chunk",{{P::speakerModel,5},{P::ampModel,4},{P::channel,3},{P::cabinet,5},{P::ampGain,5.8f},{P::ampMaster,5},{P::presence,48},{P::resonance,65},{P::sag,20},{P::tight,72},{P::cabLowCut,38},{P::cabHighCut,7500},{P::cabMic,38},{P::cabRoom,5},{P::gateThreshold,-62},{P::outputDb,-5.8f}}},
        {"28  California Heavy / Liquid",{{P::speakerModel,3},{P::ampModel,4},{P::channel,3},{P::cabinet,5},{P::ampGain,7},{P::ampMaster,5.5f},{P::presence,42},{P::resonance,55},{P::sag,50},{P::tight,50},{P::lowMidDb,1.5f},{P::midFreq,800},{P::cabLowCut,40},{P::cabHighCut,7000},{P::cabMic,45},{P::cabRoom,6},{P::gateThreshold,-70},{P::outputDb,-9.6f}}},
        {"29  British Chime / Clear",{{P::speakerModel,4},{P::ampModel,5},{P::channel,0},{P::cabinet,2},{P::ampGain,3},{P::ampMaster,5},{P::presence,55},{P::resonance,28},{P::sag,35},{P::tight,20},{P::cabLowCut,55},{P::cabHighCut,11000},{P::cabMic,22},{P::cabRoom,8},{P::gateThreshold,-75},{P::outputDb,2.4f}}},
        {"30  British Chime / Breakup",{{P::speakerModel,4},{P::ampModel,5},{P::channel,1},{P::cabinet,2},{P::ampGain,5.5f},{P::ampMaster,6},{P::presence,48},{P::resonance,32},{P::sag,55},{P::tight,30},{P::cabLowCut,50},{P::cabHighCut,9500},{P::cabMic,30},{P::cabRoom,8},{P::gateThreshold,-75},{P::outputDb,-5.2f}}}
    };
    return presets;
}
}

juce::AudioProcessorValueTreeState::ParameterLayout IronvaleAudioProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    for(const auto& s:ironvale::parameterSpecs)
    {
        // Later AU parameters receive a higher version hint so Logic's saved
        // automation ordering for the original 67 controls remains unchanged.
        const bool voice=juce::String(s.id)=="ampModel" || juce::String(s.id)=="speakerModel";
        juce::ParameterID id(s.id,voice ? 2 : 1);
        if(s.kind==ironvale::Kind::Boolean)
            layout.add(std::make_unique<juce::AudioParameterBool>(id,s.name,s.defaultValue>.5f));
        else if(s.kind==ironvale::Kind::Choice)
            layout.add(std::make_unique<juce::AudioParameterChoice>(id,s.name,juce::StringArray::fromTokens(s.choices,"|",""),static_cast<int>(s.defaultValue)));
        else
            layout.add(std::make_unique<juce::AudioParameterFloat>(id,s.name,
                juce::NormalisableRange<float>(s.minimum,s.maximum,s.step,s.skew),s.defaultValue,
                juce::AudioParameterFloatAttributes().withLabel(s.unit)));
    }
    return layout;
}
IronvaleAudioProcessor::IronvaleAudioProcessor()
 : AudioProcessor(BusesProperties().withInput("Instrument",juce::AudioChannelSet::stereo(),true)
                                  .withOutput("Output",juce::AudioChannelSet::stereo(),true)),
   parameters(*this,nullptr,"IronvaleState",createLayout())
{
    for(std::size_t i=0;i<raw.size();++i)raw[i]=parameters.getRawParameterValue(ironvale::parameterSpecs[i].id);
    setLatencySamples(ironvale::Engine::latencySamples);
    (void)factory();
}
ironvale::Settings IronvaleAudioProcessor::readSettings() const
{
    ironvale::Settings result;
    for(std::size_t i=0;i<raw.size();++i)result.set(static_cast<P>(i),raw[i]->load(std::memory_order_relaxed));
    return result;
}
bool IronvaleAudioProcessor::isBusesLayoutSupported(const BusesLayout& l) const
{
    const auto in=l.getMainInputChannelSet(),out=l.getMainOutputChannelSet();
    return (in==juce::AudioChannelSet::mono() && (out==juce::AudioChannelSet::mono()||out==juce::AudioChannelSet::stereo()))
         || (in==juce::AudioChannelSet::stereo() && out==juce::AudioChannelSet::stereo());
}
void IronvaleAudioProcessor::prepareToPlay(double rate,int blockSize)
{
    const juce::ScopedLock lock(irStateLock);
    rate=std::isfinite(rate)?juce::jlimit(8000.0,192000.0,rate):48000.0;
    processingRate.store(rate);
    monoScratch.setSize(1,juce::jmax(1,blockSize));
    engine.setSettings(readSettings());engine.prepare(rate);
    auto ir=resampleImpulse(storedIR,storedIRRate,rate);
    engine.setUserImpulse(ir.data(),(int)ir.size());
    engine.reset();
    // A prior load may have queued coefficients for the previous sample rate.
    // prepareToPlay runs while audio is stopped; serialize producers and discard that queue.
    while(irMailbox.test_and_set(std::memory_order_acquire))juce::Thread::yield();
    irPending.store(false,std::memory_order_release);
    irMailbox.clear(std::memory_order_release);
    inputPeak.store(0);outputPeak.store(0);compressionDb.store(0);
}
void IronvaleAudioProcessor::releaseResources(){engine.reset();}
void IronvaleAudioProcessor::processBlock(juce::AudioBuffer<float>& audio,juce::MidiBuffer& midi){process(audio,midi,false);}
void IronvaleAudioProcessor::processBlockBypassed(juce::AudioBuffer<float>& audio,juce::MidiBuffer& midi){process(audio,midi,true);}
void IronvaleAudioProcessor::process(juce::AudioBuffer<float>& audio,juce::MidiBuffer& midi,bool bypassed)
{
    juce::ScopedNoDenormals noDenormals;midi.clear();
    const int n=audio.getNumSamples(),channels=audio.getNumChannels();
    if(n<=0||channels<=0)return;
    for(int c=getTotalNumInputChannels();c<channels;++c)audio.clear(c,0,n);
    if(getTotalNumInputChannels()==1&&channels>=2)audio.copyFrom(1,0,audio,0,0,n);
    auto settings=readSettings();bool hostTempo=false;
    if(auto* head=getPlayHead())if(auto position=head->getPosition())if(auto tempo=position->getBpm())
        if(std::isfinite(*tempo)&&*tempo>=20&&*tempo<=300){settings.set(P::bpm,(float)*tempo);hostTempo=true;}
    currentBpm.store(settings.get(P::bpm));hostTempoActive.store(hostTempo);
    if(panicRequested.exchange(false))engine.reset();
    if(irPending.load(std::memory_order_acquire)&&!irMailbox.test_and_set(std::memory_order_acquire))
    {
        if(irPending.exchange(false))engine.setUserImpulse(queuedIR.data(),queuedIRLength);
        irMailbox.clear(std::memory_order_release);
    }
    engine.setSettings(settings);
    float in=0;for(int c=0;c<juce::jmin(2,channels);++c)in=juce::jmax(in,audio.getMagnitude(c,0,n));
    if(channels>=2)engine.process(audio.getWritePointer(0),audio.getWritePointer(1),n,bypassed);
    else
    {
        const int capacity=monoScratch.getNumSamples();if(capacity<=0)return;
        for(int offset=0;offset<n;)
        {
            const int count=juce::jmin(capacity,n-offset);
            auto* l=audio.getWritePointer(0,offset);auto* r=monoScratch.getWritePointer(0);
            juce::FloatVectorOperations::copy(r,l,count);engine.process(l,r,count,bypassed);
            for(int i=0;i<count;++i)l[i]=.5f*(l[i]+r[i]);offset+=count;
        }
    }
    float out=0;for(int c=0;c<juce::jmin(2,channels);++c)out=juce::jmax(out,audio.getMagnitude(c,0,n));
    inputPeak.store(juce::jmax(in,inputPeak.load()*.90f));outputPeak.store(juce::jmax(out,outputPeak.load()*.90f));
    compressionDb.store(engine.compressorReductionDb());
}
double IronvaleAudioProcessor::getTailLengthSeconds() const
{
    auto s=readSettings();
    const double seconds=.001*(s.on(P::sync)?std::max(ironvale::Pedals::noteMilliseconds(s.choice(P::noteL),s.choice(P::rhythmL),currentBpm.load()),
                            ironvale::Pedals::noteMilliseconds(s.choice(P::noteR),s.choice(P::rhythmR),currentBpm.load()))
                        :std::max(s.get(P::timeMsL),s.get(P::timeMsR)));
    const double feedback=s.get(P::feedback)*.01;
    return seconds*(feedback>.001?std::ceil(std::log(.001)/std::log(feedback))+1:2)+.3;
}
juce::AudioProcessorParameter* IronvaleAudioProcessor::getBypassParameter() const{return parameters.getParameter("bypass");}
juce::AudioProcessorEditor* IronvaleAudioProcessor::createEditor(){return new IronvaleAudioProcessorEditor(*this);}
int IronvaleAudioProcessor::getNumPrograms(){return (int)factory().size();}
const juce::String IronvaleAudioProcessor::getProgramName(int index){return juce::isPositiveAndBelow(index,(int)factory().size())?factory()[(std::size_t)index].name:juce::String();}
juce::StringArray IronvaleAudioProcessor::getFactoryPresetNames() const{juce::StringArray r;for(const auto& p:factory())r.add(p.name);return r;}
void IronvaleAudioProcessor::loadFactoryPreset(int index)
{
    if(!juce::isPositiveAndBelow(index,(int)factory().size()))return;
    ironvale::Settings values;for(const auto& v:factory()[(std::size_t)index].values)values.set(v.first,v.second);
    for(std::size_t i=0;i<ironvale::parameterCount;++i)if(auto* p=parameters.getParameter(ironvale::parameterSpecs[i].id))
    {p->beginChangeGesture();p->setValueNotifyingHost(p->convertTo0to1(values.values[i]));p->endChangeGesture();}
    selectedPreset.store(index);
}
void IronvaleAudioProcessor::tapTempo()
{
    const double now=juce::Time::getMillisecondCounterHiRes(),delta=now-lastTap;lastTap=now;
    if(delta<200||delta>3000){tapCount=0;return;}
    tapIntervals[(std::size_t)(tapCount++%4)]=delta;const int count=juce::jmin(4,tapCount);
    double sum=0;for(int i=0;i<count;++i)sum+=tapIntervals[(std::size_t)i];
    auto* p=parameters.getParameter("bpm");p->beginChangeGesture();p->setValueNotifyingHost(p->convertTo0to1((float)(60000*count/sum)));p->endChangeGesture();
}

std::vector<float> IronvaleAudioProcessor::resampleImpulse(const std::vector<float>& source,double from,double to) const
{
    if(source.empty()||!std::isfinite(from)||!std::isfinite(to)||from<8000||to<8000)return {};
    const int count=juce::jmin(ironvale::AmpCore::maxIRSamples,juce::jmax(1,(int)std::ceil(static_cast<double>(source.size())*to/from)));
    std::vector<float> result((std::size_t)count);
    const double cutoff=std::min(1.0,to/from)*.95;
    constexpr double pi=3.14159265358979323846;
    for(int i=0;i<count;++i)
    {
        if(std::abs(from-to)<.001)
            result[(std::size_t)i]=source[(std::size_t)i];
        else
        {
        const double position=i*from/to;const int centre=(int)std::floor(position);double y=0,weight=0;
        for(int j=centre-15;j<=centre+16;++j)
        {
            const double delta=j-position;
            if(std::abs(delta)>=16)continue;
            const double sinc=std::abs(delta)<1e-10?cutoff:std::sin(pi*delta*cutoff)/(pi*delta);
            const double w=sinc*(.5+.5*std::cos(pi*delta/16));weight+=w;
            if(j>=0&&j<(int)source.size())y+=w*source[(std::size_t)j];
        }
        // IRs describe convolution weights: preserve their integral as sample density changes.
        result[(std::size_t)i]=(float)(std::abs(weight)>1e-12?y/weight*from/to:0);
        }
        if(count>64&&i>count-64)result[(std::size_t)i]*=.5f*(1.0f+std::cos((float)(pi*(i-count+64)/64.0)));
    }
    double total=0;for(auto value:result)total+=std::abs(value);
    if(total>2)for(auto& value:result)value=(float)(value*2/total);
    return result;
}
void IronvaleAudioProcessor::queueImpulse()
{
    const juce::ScopedLock lock(irStateLock);
    const auto prepared=resampleImpulse(storedIR,storedIRRate,processingRate.load());
    // Only the producer can wait. The callback makes one try and defers if busy.
    while(irMailbox.test_and_set(std::memory_order_acquire))juce::Thread::yield();
    queuedIRLength=(int)prepared.size();std::copy(prepared.begin(),prepared.end(),queuedIR.begin());
    irPending.store(true,std::memory_order_release);irMailbox.clear(std::memory_order_release);
}
juce::String IronvaleAudioProcessor::getCabinetIRName() const{const juce::ScopedLock lock(irStateLock);return irName;}
void IronvaleAudioProcessor::loadCabinetIR(const juce::File& file)
{
    juce::AudioFormatManager formats;formats.registerBasicFormats();
    std::unique_ptr<juce::AudioFormatReader> reader(formats.createReaderFor(file));
    auto failure=[&](const juce::String& why){const juce::ScopedLock lock(irStateLock);irName="IR load failed: "+why;};
    if(!reader||reader->numChannels<1||reader->numChannels>2||reader->lengthInSamples<1||reader->sampleRate<8000||reader->sampleRate>384000)
    {failure("use a mono/stereo WAV or AIFF");return;}
    const int count=(int)std::min<juce::int64>(reader->lengthInSamples,131072);
    juce::AudioBuffer<float> audio((int)reader->numChannels,count);
    if(!reader->read(&audio,0,count,0,true,true)){failure("could not read audio");return;}
    std::vector<float> data((std::size_t)count);float peak=0;
    for(int i=0;i<count;++i)
    {
        float value=audio.getSample(0,i);if(audio.getNumChannels()>1)value=.5f*(value+audio.getSample(1,i));
        if(!std::isfinite(value)){failure("non-finite sample");return;}
        data[(std::size_t)i]=value;peak=std::max(peak,std::abs(value));
    }
    if(peak<1e-8f){failure("empty or silent impulse");return;}
    auto first=std::find_if(data.begin(),data.end(),[&](float v){return std::abs(v)>peak*1e-4f;});data.erase(data.begin(),first);
    {const juce::ScopedLock lock(irStateLock);storedIR=data;storedIRRate=reader->sampleRate;irName=file.getFileName();queueImpulse();}
    auto* choice=parameters.getParameter("cabinet");choice->beginChangeGesture();choice->setValueNotifyingHost(choice->convertTo0to1(7));choice->endChangeGesture();
}

juce::ValueTree IronvaleAudioProcessor::snapshotState()
{
    auto state=parameters.copyState();state.setProperty("schemaVersion",1,nullptr);state.setProperty("factoryPreset",selectedPreset.load(),nullptr);
    const juce::ScopedLock lock(irStateLock);
    if(!storedIR.empty())
    {
        juce::MemoryBlock data(storedIR.data(),storedIR.size()*sizeof(float));
        state.setProperty("cabinetIR",data.toBase64Encoding(),nullptr);state.setProperty("cabinetIRRate",storedIRRate,nullptr);
        state.setProperty("cabinetIRName",irName,nullptr);
    }
    return state;
}
bool IronvaleAudioProcessor::restoreState(const juce::ValueTree& state)
{
    if(!state.isValid()||!state.hasType("IronvaleState"))return false;
    std::vector<float> impulse;double rate=48000;
    if(state.hasProperty("cabinetIR"))
    {
        juce::MemoryBlock bytes;if(!bytes.fromBase64Encoding(state.getProperty("cabinetIR").toString())||bytes.getSize()%sizeof(float)!=0||bytes.getSize()>131072*sizeof(float))return false;
        impulse.resize(bytes.getSize()/sizeof(float));if(!impulse.empty())std::memcpy(impulse.data(),bytes.getData(),bytes.getSize());
        rate=(double)state.getProperty("cabinetIRRate",48000);
        if(!std::isfinite(rate)||rate<8000||rate>384000)return false;
        for(auto value:impulse)if(!std::isfinite(value)||std::abs(value)>100)return false;
    }
    auto clean=parameters.copyState();
    // Pre-0.3 sessions have no voice selector. Always restore Original, even
    // when an older preset is loaded into an instance using a newer voice.
    for(const auto* id:{"ampModel","speakerModel"})
        if(!state.getChildWithProperty("id",id).isValid())
            clean.getChildWithProperty("id",id).setProperty("value",0.0f,nullptr);
    for(const auto& child:state)
    {
        const auto id=child.getProperty("id").toString();
        if(auto* p=parameters.getParameter(id))
        {
            const float value=(float)child.getProperty("value");if(!std::isfinite(value))return false;
            auto target=clean.getChildWithProperty("id",id);
            if(target.isValid())target.setProperty("value",p->convertFrom0to1(p->convertTo0to1(value)),nullptr);
        }
    }
    parameters.replaceState(clean);
    {const juce::ScopedLock lock(irStateLock);storedIR=impulse;storedIRRate=rate;irName=impulse.empty()?"No user IR loaded - factory fallback":state.getProperty("cabinetIRName","Embedded user IR").toString();queueImpulse();}
    selectedPreset.store(juce::jlimit(0,(int)factory().size()-1,(int)state.getProperty("factoryPreset",0)));
    return true;
}
void IronvaleAudioProcessor::getStateInformation(juce::MemoryBlock& data){if(auto xml=snapshotState().createXml())copyXmlToBinary(*xml,data);}
void IronvaleAudioProcessor::setStateInformation(const void* data,int count)
{if(count>0&&count<2*1024*1024)if(auto xml=getXmlFromBinary(data,count))restoreState(juce::ValueTree::fromXml(*xml));}
bool IronvaleAudioProcessor::savePresetToFile(const juce::File& file)
{
    if (auto xml = snapshotState().createXml())
        if (xml->writeTo (file)) return true;
    juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::WarningIcon,
        "Preset not saved", "Ironvale could not write to this location.");
    return false;
}
bool IronvaleAudioProcessor::loadPresetFromFile(const juce::File& file)
{if(file.getSize()>2*1024*1024)return false;if(auto xml=juce::XmlDocument::parse(file))return restoreState(juce::ValueTree::fromXml(*xml));return false;}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new IronvaleAudioProcessor();}
