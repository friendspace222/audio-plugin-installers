#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <complex>
#include "MeasuredCabinetData.h"

namespace ironvale::cabinetvoices {

// Original speaker-family approximations, not measurements of branded drivers.
// Speaker resonances and cone-breakup contours are independent of the selected
// enclosure. This is an offline IR builder: call only during prepare(), then
// use the existing allocation-free partitioned convolver on the audio thread.
// Voice IDs match speakerModel: 1 American Ceramic, 2 British Green,
// 3 British Vintage, 4 Alnico Chime, 5 measured Vintage30/SM57 4x12.
// ID 0 must retain the legacy factory IR. The measured choice is a fixed rig:
// it ignores the enclosure argument and applies no synthetic speaker/box EQ.
constexpr int voiceCount = 5;
constexpr int modeledVoiceCount = 4;
constexpr int maxSamples = 2048;

namespace detail {
constexpr double pi = 3.14159265358979323846;
struct Filter {
    double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;
    double tick(double x) noexcept {
        const double y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }
};
inline Filter normalized(double b0, double b1, double b2, double a0, double a1, double a2) noexcept {
    return {b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0, 0, 0};
}
inline Filter pass(double rate, double frequency, double q, bool high) noexcept {
    const double w = 2 * pi * std::clamp(frequency, 5.0, rate * 0.43) / rate;
    const double c = std::cos(w), s = std::sin(w) / (2 * q);
    const double b = (high ? 1 + c : 1 - c) * 0.5;
    return normalized(b, high ? -2 * b : 2 * b, b, 1 + s, -2 * c, 1 - s);
}
inline Filter bell(double rate, double frequency, double db, double q) noexcept {
    const double w = 2 * pi * std::clamp(frequency, 5.0, rate * 0.43) / rate;
    const double a = std::pow(10.0, db / 40.0), c = std::cos(w), s = std::sin(w) / (2 * q);
    return normalized(1 + s * a, -2 * c, 1 - s * a, 1 + s / a, -2 * c, 1 - s / a);
}
struct Resonance { double hz, db, q; };
struct Speaker {
    double fundamental, cutoff;
    std::array<Resonance, 7> cone;
};
inline const Speaker& speaker(int voice) noexcept {
    // Broad family voicing informed by the manufacturers' published descriptions;
    // the resonant frequencies/gains here are original design choices. The narrow
    // peaks and notches represent linear cone modes, not nonlinear cone distortion.
    static constexpr std::array<Speaker, modeledVoiceCount> speakers {{
        {113, 6500, {{{260, 1.2, 0.7}, {750, -0.5, 0.65}, {1700, 4.0, 1.0},
                      {3000, 1.0, 1.6}, {3900, -5.0, 3.4}, {4800, 3.2, 2.4}, {6600, -5.0, 2.0}}}},
        {75, 4850, {{{180, 1.3, 0.8}, {700, 2.0, 0.8}, {1550, 3.0, 1.2},
                     {2650, -4.2, 3.0}, {3400, 3.8, 2.5}, {4600, -5.5, 2.0}, {6100, -3.0, 1.5}}}},
        {75, 5650, {{{150, 1.6, 0.8}, {520, -2.0, 0.85}, {1350, 2.6, 1.3},
                     {2750, 4.8, 2.0}, {3650, -5.5, 3.5}, {4700, 3.0, 2.6}, {6500, -4.0, 2.0}}}},
        {75, 5900, {{{170, 2.0, 0.75}, {750, -1.0, 0.8}, {1650, -3.2, 1.0},
                     {2350, 2.0, 1.5}, {3400, 5.8, 2.1}, {4450, -4.0, 3.2}, {5250, 2.8, 2.8}}}}
    }};
    return speakers[static_cast<size_t>(std::clamp(voice, 1, modeledVoiceCount) - 1)];
}
inline void calibrate(float* output, int length, double rate) noexcept {
    // Common four-point calibration prevents speaker changes being judged merely
    // by volume. It is a single scalar: it preserves spectral/phase differences.
    double energy = 0;
    for (const double hz : {250.0, 500.0, 1000.0, 2000.0}) {
        std::complex<double> sum{};
        for (int n = 0; n < length; ++n) {
            const double angle = -2 * pi * hz * n / rate;
            sum += static_cast<double>(output[n]) * std::complex<double>(std::cos(angle), std::sin(angle));
        }
        energy += std::norm(sum);
    }
    const double gain = 0.80 / std::max(0.1, std::sqrt(energy / 4));
    for (int n = 0; n < length; ++n) output[n] = static_cast<float>(output[n] * gain);
}
inline void measured(float* output, int length, double rate) noexcept {
    // Band-limited windowed-sinc conversion is done once during prepare. Source
    // timing/polarity stay intact; no minimum-phase reconstruction or added box
    // reflections. At 48 kHz the original PCM samples are used directly.
    constexpr int radius = 32;
    const double ratio = measuredSourceRate / rate;
    const double cutoff = std::min(1.0, rate / measuredSourceRate);
    // The embedded capture spans 85.33 ms. At unusual very low host rates
    // the requested output can be longer, so taper the available capture and
    // zero-pad rather than abruptly cut its source tail at the embedding edge.
    const int available = std::min(length, std::max(1, static_cast<int>((measuredPcm.size() - 1) / ratio)));
    const int fadeStart = available * 3 / 4;
    for (int n = 0; n < length; ++n) {
        if (n >= available) { output[n] = 0; continue; }
        double x = 0;
        if (rate == measuredSourceRate) {
            x = measuredPcm[static_cast<size_t>(n)] / 8388608.0;
        } else {
            const double position = n * ratio;
            const int centre = static_cast<int>(std::floor(position));
            for (int k = centre - radius; k <= centre + radius; ++k) {
                if (k < 0 || k >= static_cast<int>(measuredPcm.size())) continue;
                const double distance = position - k;
                if (std::abs(distance) > radius) continue;
                const double phase = pi * distance * cutoff;
                const double sinc = std::abs(phase) < 1.0e-12 ? 1.0 : std::sin(phase) / phase;
                const double window = 0.42 + 0.5 * std::cos(pi * distance / radius)
                    + 0.08 * std::cos(2 * pi * distance / radius);
                x += measuredPcm[static_cast<size_t>(k)] / 8388608.0 * cutoff * sinc * window;
            }
            x *= ratio;
        }
        if (n >= fadeStart) {
            const double phase = static_cast<double>(n - fadeStart) / std::max(1, available - 1 - fadeStart);
            x *= 0.5 + 0.5 * std::cos(pi * phase);
        }
        output[n] = static_cast<float>(x);
    }
    calibrate(output, length, rate);
}
} // namespace detail

inline void make(float* output, int length, double rate, int cabinet, int voice) noexcept {
    if (output == nullptr || length <= 0) return;
    length = std::min(length, maxSamples);
    rate = std::isfinite(rate) ? std::clamp(rate, 8000.0, 384000.0) : 48000.0;
    if (voice == 5) { detail::measured(output, length, rate); return; }
    cabinet = std::clamp(cabinet, 0, 6);
    const auto& speaker = detail::speaker(voice);
    // Open enclosures have a broader, smaller low-frequency boost and a
    // stronger acoustic rolloff. The closed 4x12/8x12 retain the low body.
    static constexpr double bodyHz[7] = {118, 112, 108, 100, 96, 88, 82};
    static constexpr double bodyDb[7] = {1.8, 3.2, 2.3, 4.1, 4.7, 5.4, 5.9};
    static constexpr double lowCut[7] = {52, 38, 46, 33, 30, 27, 25};
    static constexpr double reflection[7] = {0.07, 0.13, 0.10, 0.17, 0.20, 0.23, 0.26};
    const double resonance = bodyHz[cabinet] * (0.70 + 0.30 * speaker.fundamental / 90.0);
    std::array<detail::Filter, 12> filters{};
    filters[0] = detail::pass(rate, lowCut[cabinet], 0.70710678118, true);
    filters[1] = detail::bell(rate, resonance, bodyDb[cabinet], cabinet == 0 || cabinet == 2 ? 0.65 : 0.95);
    filters[2] = detail::bell(rate, 235, 0.5 + 0.16 * cabinet, 0.75);
    for (int i = 0; i < 7; ++i) {
        const auto& mode = speaker.cone[static_cast<size_t>(i)];
        // Modes beyond usable bandwidth are omitted at unusual low sample rates.
        // Folding their frequency down would create a spurious Nyquist peak.
        if (mode.hz < rate * 0.43)
            filters[static_cast<size_t>(3 + i)] = detail::bell(rate, mode.hz, mode.db, mode.q);
    }
    // A fourth-order acoustic rolloff eliminates the wideband fizz of the old
    // two one-pole response while preserving each driver's upper-mid character.
    filters[10] = detail::pass(rate, speaker.cutoff, 0.54119610015, false);
    filters[11] = detail::pass(rate, speaker.cutoff, 1.30656296488, false);
    std::array<double, maxSamples> clean{};
    for (int n = 0; n < length; ++n) {
        double x = n == 0 ? 1.0 : 0.0;
        for (auto& filter : filters) x = filter.tick(x);
        clean[static_cast<size_t>(n)] = x;
    }
    const int first = std::max(1, static_cast<int>(rate * (0.00025 + cabinet * 0.000053)));
    const int second = std::max(1, static_cast<int>(rate * (0.00071 + cabinet * 0.000093)));
    const int third = std::max(1, static_cast<int>(rate * (0.00121 + cabinet * 0.00011)));
    for (int n = 0; n < length; ++n) {
        double x = clean[static_cast<size_t>(n)];
        if (n >= first) x += reflection[cabinet] * clean[static_cast<size_t>(n - first)];
        if (n >= second) x -= 0.45 * reflection[cabinet] * clean[static_cast<size_t>(n - second)];
        if (n >= third) x += 0.18 * reflection[cabinet] * clean[static_cast<size_t>(n - third)];
        const int fadeStart = length * 3 / 4;
        if (n >= fadeStart) {
            const double phase = static_cast<double>(n - fadeStart) / std::max(1, length - 1 - fadeStart);
            x *= 0.5 + 0.5 * std::cos(detail::pi * phase);
        }
        output[n] = static_cast<float>(x);
    }
    detail::calibrate(output, length, rate);
}

} // namespace ironvale::cabinetvoices
