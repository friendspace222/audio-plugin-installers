#pragma once

#include "Parameters.h"
#include <memory>

namespace ironvale {

// Original, circuit-inspired guitar/bass amplifier. All audio-thread methods
// use storage allocated in prepare(). No captured commercial amplifier models.
class AmpCore {
public:
    static constexpr int latencySamples = 32;
    static constexpr int maxIRSamples = 2048;
    AmpCore();
    ~AmpCore();
    AmpCore(const AmpCore&) = delete;
    AmpCore& operator=(const AmpCore&) = delete;

    void prepare(double sampleRate);
    void reset();
    void setSettings(const Settings& settings);
    Stereo process(Stereo input);
    // Caller supplies a mono impulse already resampled to this instance's rate.
    // Copies into fixed storage; passing nullptr/zero clears the custom slot.
    void setUserImpulse(const float* mono, int length);

private:
    struct Impl;
    std::unique_ptr<Impl> impl;
};

} // namespace ironvale
