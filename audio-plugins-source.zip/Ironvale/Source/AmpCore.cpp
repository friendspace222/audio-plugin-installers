#include "AmpCore.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <complex>
#include <cstddef>

namespace ironvale {
namespace {
constexpr float pi = 3.14159265358979323846f;
constexpr int osFactor = 4, osTaps = 129;
constexpr int block = 64, fftSize = 128;
constexpr int partitions = AmpCore::maxIRSamples / block;
using Complex = std::complex<float>;
using Spectrum = std::array<Complex, fftSize>;
inline float clamp(float x, float lo, float hi) { return std::max(lo, std::min(hi, x)); }
inline float dbGain(float d) { return std::pow(10.0f, d * 0.05f); }
inline float sane(float x) { return std::isfinite(x) ? clamp(x, -32.0f, 32.0f) : 0.0f; }
inline float denormal(float x) { return std::abs(x) < 1.0e-25f ? 0.0f : x; }
inline float soft(float x) { return std::tanh(x); }

struct Smooth {
    float value = 0.0f, target = 0.0f, coefficient = 0.001f;
    void time(double sr, double seconds = 0.02) { coefficient = static_cast<float>(1.0 - std::exp(-1.0 / (sr * seconds))); }
    float next() { value += coefficient * (target - value); return value; }
    void snap() { value = target; }
};

struct Pole {
    float state = 0.0f;
    float low(float x, float coefficient) { state = denormal(state + coefficient * (x - state)); return state; }
    void reset() { state = 0.0f; }
};
float poleCoefficient(float frequency, double rate) {
    return 1.0f - std::exp(-2.0f * pi * std::min(frequency, static_cast<float>(rate * 0.45)) / static_cast<float>(rate));
}

// RBJ cookbook biquads, transposed direct form II. Coefficient interpolation
// is restricted to stable, low-Q shelf and bell settings.
struct Coeff {
    double b0 = 1.0, b1 = 0.0, b2 = 0.0, a1 = 0.0, a2 = 0.0;
    void approach(const Coeff& b, float t) {
        b0 += t * (b.b0 - b0); b1 += t * (b.b1 - b1); b2 += t * (b.b2 - b2);
        a1 += t * (b.a1 - a1); a2 += t * (b.a2 - a2);
    }
};
Coeff bell(double sr, float hz, float gain, float q = 0.7f) {
    const double a = std::pow(10.0, gain / 40.0);
    const double w = 6.2831853071795864769 * std::min(static_cast<double>(hz), sr * 0.4) / sr;
    const double alpha = std::sin(w) / (2.0 * q), c = std::cos(w), d = 1.0 + alpha / a;
    return {(1.0f + alpha * a) / d, -2.0f * c / d, (1.0f - alpha * a) / d,
            -2.0f * c / d, (1.0f - alpha / a) / d};
}
Coeff shelf(double sr, float hz, float gain, bool high) {
    const double a = std::pow(10.0, gain / 40.0);
    const double w = 6.2831853071795864769 * std::min(static_cast<double>(hz), sr * 0.4) / sr;
    const double c = std::cos(w), beta = std::sin(w) * std::sqrt(2.0 * a);
    double b0, b1, b2, a0, a1, a2;
    if (high) {
        b0 = a * ((a + 1) + (a - 1) * c + beta); b1 = -2 * a * ((a - 1) + (a + 1) * c); b2 = a * ((a + 1) + (a - 1) * c - beta);
        a0 = (a + 1) - (a - 1) * c + beta; a1 = 2 * ((a - 1) - (a + 1) * c); a2 = (a + 1) - (a - 1) * c - beta;
    } else {
        b0 = a * ((a + 1) - (a - 1) * c + beta); b1 = 2 * a * ((a - 1) - (a + 1) * c); b2 = a * ((a + 1) - (a - 1) * c - beta);
        a0 = (a + 1) + (a - 1) * c + beta; a1 = -2 * ((a - 1) + (a + 1) * c); a2 = (a + 1) + (a - 1) * c - beta;
    }
    return {b0/a0, b1/a0, b2/a0, a1/a0, a2/a0};
}
struct Biquad {
    // Double state and coefficients matter for bass filters at 4x 192 kHz:
    // single-precision pole interpolation can otherwise cross the unit circle.
    double z1 = 0.0, z2 = 0.0;
    float tick(float x, const Coeff& c) {
        const double y = c.b0 * x + z1;
        z1 = c.b1 * x - c.a1 * y + z2; z2 = c.b2 * x - c.a2 * y;
        if (std::abs(z1) < 1.0e-30) z1 = 0;
        if (std::abs(z2) < 1.0e-30) z2 = 0;
        return static_cast<float>(y);
    }
    void reset() { z1 = z2 = 0.0f; }
};

struct FFT {
    std::array<int, fftSize> reverse{};
    std::array<Complex, fftSize / 2> roots{};
    FFT() {
        for (int n = 0; n < fftSize; ++n) {
            int j = 0, a = n;
            for (int k = 0; k < 7; ++k) { j = (j << 1) | (a & 1); a >>= 1; }
            reverse[n] = j;
        }
        for (int n = 0; n < fftSize / 2; ++n) {
            const float phase = -2.0f * pi * n / fftSize;
            roots[n] = Complex(std::cos(phase), std::sin(phase));
        }
    }
    void transform(Spectrum& x, bool inverse = false) const {
        for (int n = 0; n < fftSize; ++n) if (n < reverse[n]) std::swap(x[n], x[reverse[n]]);
        for (int len = 2; len <= fftSize; len <<= 1) {
            const int stride = fftSize / len;
            for (int offset = 0; offset < fftSize; offset += len)
                for (int n = 0; n < len / 2; ++n) {
                    const Complex w = inverse ? std::conj(roots[n * stride]) : roots[n * stride];
                    const Complex u = x[offset + n], v = x[offset + n + len / 2] * w;
                    x[offset + n] = u + v; x[offset + n + len / 2] = u - v;
                }
        }
        if (inverse) for (auto& value : x) value *= 1.0f / fftSize;
    }
};
struct Impulse {
    std::array<float, block> head{};
    std::array<Spectrum, partitions> spectra{};
    int count = 1;
    void make(const float* samples, int length, const FFT& fft) {
        head.fill(0.0f);
        for (auto& partition : spectra) partition.fill({});
        length = std::max(0, std::min(length, AmpCore::maxIRSamples));
        count = std::max(1, (length + block - 1) / block);
        for (int n = 0; n < std::min(length, block); ++n) head[n] = samples[n];
        for (int p = 1; p < count; ++p) {
            for (int n = 0; n < block && p * block + n < length; ++n) spectra[p][n] = samples[p * block + n];
            fft.transform(spectra[p]);
        }
    }
};

// First 64 taps are direct, later taps use partitioned overlap-add. The first
// sample of an IR is audible immediately: cabinet convolution adds no latency.
struct CabinetConvolver {
    struct Lane {
        std::array<float, block> recent{}, input{}, tail{}, overlap{};
        std::array<Spectrum, partitions> history{};
    };
    std::array<Lane, 2> lane{};
    Impulse current{};
    const Impulse* target = nullptr;
    int position = 0, historyIndex = 0;
    float morph = 0.04f;
    void reset(const Impulse* impulse) {
        for (auto& l : lane) {
            l.recent.fill(0); l.input.fill(0); l.tail.fill(0); l.overlap.fill(0);
            for (auto& h : l.history) h.fill({});
        }
        target = impulse; if (target) current = *target;
        position = historyIndex = 0;
    }
    Stereo tick(Stereo input, const FFT& fft) {
        float result[2]{};
        const float ins[2] = {input.l, input.r};
        for (int channel = 0; channel < 2; ++channel) {
            auto& l = lane[channel]; l.recent[position] = l.input[position] = ins[channel];
            float y = l.tail[position]; int at = position;
            for (int tap = 0; tap < block; ++tap) { y += current.head[tap] * l.recent[at]; at = (at - 1) & (block - 1); }
            result[channel] = y;
        }
        if (++position == block) {
            position = 0;
            if (target) {
                current.count = std::max(current.count, target->count);
                for (int n = 0; n < block; ++n) current.head[n] += morph * (target->head[n] - current.head[n]);
                for (int p = 1; p < current.count; ++p)
                    for (int n = 0; n < fftSize; ++n) current.spectra[p][n] += morph * (target->spectra[p][n] - current.spectra[p][n]);
            }
            for (auto& l : lane) {
                Spectrum& in = l.history[historyIndex]; in.fill({});
                for (int n = 0; n < block; ++n) in[n] = l.input[n];
                fft.transform(in);
                Spectrum sum{};
                for (int p = 1; p < current.count; ++p) {
                    const auto& past = l.history[(historyIndex - (p - 1) + partitions) % partitions];
                    const auto& ir = current.spectra[p];
                    for (int n = 0; n < fftSize; ++n) sum[n] += past[n] * ir[n];
                }
                fft.transform(sum, true);
                for (int n = 0; n < block; ++n) {
                    l.tail[n] = denormal(sum[n].real() + l.overlap[n]);
                    l.overlap[n] = denormal(sum[n + block].real());
                }
            }
            historyIndex = (historyIndex + 1) % partitions;
        }
        return {result[0], result[1]};
    }
};

struct Oversampler {
    std::array<float, osTaps> coefficients{};
    struct Lane { std::array<float, osTaps> up{}, down{}; };
    std::array<Lane, 2> lane{};
    int upIndex = 0, downIndex = 0, phase = 0;
    void prepare() {
        // Blackman-windowed lowpass, cutoff 0.1125 of the 4x rate. Both
        // linear-phase stages have 64 high-rate samples of group delay.
        float total = 0;
        for (int n = 0; n < osTaps; ++n) {
            const int k = n - (osTaps - 1) / 2;
            const float sinc = k == 0 ? 0.225f : std::sin(pi * 0.225f * k) / (pi * k);
            const float window = 0.42f - 0.5f * std::cos(2 * pi * n / (osTaps - 1)) + 0.08f * std::cos(4 * pi * n / (osTaps - 1));
            coefficients[n] = sinc * window; total += coefficients[n];
        }
        for (auto& c : coefficients) c /= total;
        reset();
    }
    void reset() { for (auto& l : lane) { l.up.fill(0); l.down.fill(0); } upIndex = downIndex = phase = 0; }
    Stereo up(Stereo x) {
        lane[0].up[upIndex] = x.l; lane[1].up[upIndex] = x.r;
        // Polyphase interpolation skips the three inserted zeros per input
        // sample. This preserves the exact FIR while reducing CPU on old Macs.
        Stereo out{}; int at = upIndex - phase;
        if (at < 0) at += osTaps;
        for (int n = phase; n < osTaps; n += osFactor) {
            const float c = coefficients[n] * osFactor;
            out.l += lane[0].up[at] * c; out.r += lane[1].up[at] * c;
            at -= osFactor; if (at < 0) at += osTaps;
        }
        phase = (phase + 1) & (osFactor - 1);
        if (++upIndex == osTaps) upIndex = 0; return out;
    }
    Stereo down(Stereo x, bool emit) {
        lane[0].down[downIndex] = x.l; lane[1].down[downIndex] = x.r;
        Stereo out{};
        if (emit) {
            int at = downIndex;
            for (int n = 0; n < osTaps; ++n) {
                out.l += lane[0].down[at] * coefficients[n]; out.r += lane[1].down[at] * coefficients[n];
                if (--at < 0) at = osTaps - 1;
            }
        }
        if (++downIndex == osTaps) downIndex = 0; return out;
    }
};

// Minimum-phase-like causal synthetic cabinet response: a bandlimited speaker
// pulse plus cabinet/body resonances and short baffle reflections. These are
// original mathematical models, not recordings or third-party IRs.
void makeCabinet(float* output, int length, double rate, int rig, int cabinet) {
    static constexpr float guitarCut[7] = {5600, 5200, 5400, 4900, 4400, 6000, 4200};
    static constexpr float bassCut[7] = {6100, 4900, 5600, 4500, 4000, 5300, 3700};
    static constexpr float resonance[7] = {115, 105, 98, 88, 82, 72, 58};
    static constexpr float depth[7] = {0.12f, 0.20f, 0.17f, 0.24f, 0.28f, 0.31f, 0.38f};
    Pole lp1, lp2, hp; Biquad body, bite, scoop;
    const float cut = (rig ? bassCut : guitarCut)[cabinet];
    const float lc = poleCoefficient(cut, rate), hc = poleCoefficient(rig ? 28.0f : (cabinet == 6 ? 48.0f : 64.0f), rate);
    const float res = resonance[cabinet] * (rig ? 0.66f : 1.0f);
    const Coeff b = bell(rate, res, 4.0f + cabinet * 0.65f, 0.75f);
    const Coeff p = bell(rate, rig ? 1250.0f + cabinet * 150 : 1700.0f + cabinet * 180, rig ? 1.5f : 3.5f, 1.0f);
    const Coeff s = bell(rate, rig ? 410.0f : 670.0f, -2.5f - cabinet * 0.45f, 0.8f);
    std::array<float, AmpCore::maxIRSamples> clean{};
    for (int n = 0; n < length; ++n) {
        float x = n == 0 ? 1.0f : 0.0f;
        x = lp2.low(lp1.low(x, lc), lc); x -= hp.low(x, hc);
        x = scoop.tick(bite.tick(body.tick(x, b), p), s);
        clean[n] = x;
    }
    const int bounce1 = std::max(1, static_cast<int>(rate * (0.00021 + cabinet * 0.000047)));
    const int bounce2 = std::max(1, static_cast<int>(rate * (0.00062 + cabinet * 0.000082)));
    for (int n = 0; n < length; ++n) {
        float x = clean[n];
        if (n >= bounce1) x += depth[cabinet] * clean[n - bounce1];
        if (n >= bounce2) x -= depth[cabinet] * 0.58f * clean[n - bounce2];
        const float tail = std::exp(-static_cast<float>(n) / static_cast<float>(rate * (rig ? 0.006 : 0.004)));
        x += (rig ? 0.0014f : 0.0010f) * (1.0f + cabinet * 0.11f) * tail * std::sin(2 * pi * res * n / static_cast<float>(rate));
        // Smooth truncated tails to zero, including at high sample rates.
        if (n > length * 3 / 4) x *= 0.5f + 0.5f * std::cos(pi * (n - length * 3 / 4) / (length / 4.0f));
        output[n] = x;
    }
    // Calibrate gain at a mid-band reference without peak-normalizing resonances.
    Complex response{};
    const float reference = rig ? 220.0f : 440.0f;
    for (int n = 0; n < length; ++n) {
        const float angle = -2 * pi * reference * n / static_cast<float>(rate);
        response += output[n] * Complex(std::cos(angle), std::sin(angle));
    }
    const float gain = 0.85f / std::max(0.1f, std::abs(response));
    for (int n = 0; n < length; ++n) output[n] *= gain;
}
} // namespace

struct AmpCore::Impl {
    double rate = 48000.0, highRate = 192000.0;
    Settings settings{};
    FFT fft{};
    std::array<Impulse, 14> factories{};
    Impulse user{};
    CabinetConvolver convolver{};
    Oversampler oversampler{};
    bool prepared = false, initialized = false, hasUser = false;
    int rig = 0, channel = 0, cabinet = 0;
    std::array<Stereo, latencySamples> dryDelay{};
    int dryIndex = 0;
    Smooth ampMix, cabMix, odMix, dirtMix, processMix;
    Smooth gain, master, drive, odLevel, odTone, dirtAmount, dirtBlend, dirtTone;
    Smooth sag, tight, presence, resonance, mic, room, cabLow, cabHigh, bassRig;
    std::array<Smooth, 4> channelMix{};
    std::array<Coeff, 6> eq{}, eqTarget{};
    struct Lane {
        Pole inputHigh, odHigh, odLow, dirtLow, dirtSmooth, inter1, inter2, powerDC, envelope, cabinetHigh, cabinetLow1, cabinetLow2, micLow;
        std::array<Biquad, 6> eq{};
    };
    std::array<Lane, 2> lane{};
    std::array<std::array<float, 16384>, 2> roomDelay{};
    int roomIndex = 0, roomTap1 = 0, roomTap2 = 0, roomTap3 = 0;
    float eqSlew = 0.001f, dcCoefficient = 0, envelopeCoefficient = 0, odHpCoefficient = 0, dirtSplitCoefficient = 0;

    void forEachSmooth(void (*operation)(Smooth&, double), double arg) {
        Smooth* values[] = {&ampMix,&cabMix,&odMix,&dirtMix,&processMix,&gain,&master,&drive,&odLevel,&odTone,
            &dirtAmount,&dirtBlend,&dirtTone,&sag,&tight,&presence,&resonance,&mic,&room,&cabLow,&cabHigh,&bassRig};
        for (auto* value : values) operation(*value, arg);
        for (auto& value : channelMix) operation(value, arg);
    }
    const Impulse* selected() const {
        if (cabinet == 7 && hasUser) return &user;
        return &factories[rig * 7 + std::min(cabinet, 6)];
    }
    void set(const Settings& s) {
        settings = s;
        rig = std::max(0, std::min(1, s.choice(Param::rig)));
        channel = std::max(0, std::min(3, s.choice(Param::channel)));
        cabinet = std::max(0, std::min(7, s.choice(Param::cabinet)));
        ampMix.target = s.on(Param::ampEnabled) ? 1.0f : 0.0f;
        cabMix.target = s.on(Param::cabEnabled) ? 1.0f : 0.0f;
        odMix.target = s.on(Param::odEnabled) ? 1.0f : 0.0f;
        dirtMix.target = s.on(Param::dirtEnabled) && rig ? 1.0f : 0.0f;
        processMix.target = ampMix.target || odMix.target || dirtMix.target ? 1.0f : 0.0f;
        gain.target = clamp(s.get(Param::ampGain), 0, 10);
        master.target = clamp(s.get(Param::ampMaster), 0, 10) * 0.1f;
        drive.target = clamp(s.get(Param::odDrive), 0, 100) * 0.01f;
        odLevel.target = dbGain(clamp(s.get(Param::odLevelDb), -12, 18));
        odTone.target = poleCoefficient(1000 + 14000 * clamp(s.get(Param::odTone), 0, 100) * 0.01f, highRate);
        dirtAmount.target = clamp(s.get(Param::dirtAmount), 0, 100) * 0.01f;
        dirtBlend.target = clamp(s.get(Param::dirtBlend), 0, 100) * 0.01f;
        dirtTone.target = poleCoefficient(700 + 10500 * clamp(s.get(Param::dirtTone), 0, 100) * 0.01f, highRate);
        sag.target = clamp(s.get(Param::sag), 0, 100) * 0.01f;
        tight.target = poleCoefficient((rig ? 20.0f : 28.0f) + (rig ? 65.0f : 185.0f) * clamp(s.get(Param::tight), 0, 100) * 0.01f, highRate);
        presence.target = clamp(s.get(Param::presence), 0, 100) * 0.01f;
        resonance.target = clamp(s.get(Param::resonance), 0, 100) * 0.01f;
        mic.target = clamp(s.get(Param::cabMic), 0, 100) * 0.01f;
        room.target = clamp(s.get(Param::cabRoom), 0, 100) * 0.01f;
        cabLow.target = poleCoefficient(clamp(s.get(Param::cabLowCut), 20, 250), rate);
        cabHigh.target = poleCoefficient(clamp(s.get(Param::cabHighCut), 2000, 18000), rate);
        bassRig.target = rig ? 1.0f : 0.0f;
        for (int c = 0; c < 4; ++c) channelMix[c].target = c == channel ? 1.0f : 0.0f;
        eqTarget[0] = shelf(highRate, rig ? 75.0f : 110.0f, clamp(s.get(Param::bassDb), -15, 15), false);
        eqTarget[1] = bell(highRate, clamp(s.get(Param::midFreq), 150, 2500), clamp(s.get(Param::lowMidDb), -15, 15));
        eqTarget[2] = bell(highRate, rig ? 1600.0f : 2400.0f, clamp(s.get(Param::highMidDb), -15, 15));
        eqTarget[3] = shelf(highRate, rig ? 3500.0f : 4500.0f, clamp(s.get(Param::trebleDb), -15, 15), true);
        eqTarget[4] = shelf(highRate, 3800, (presence.target - 0.5f) * 12.0f, true);
        eqTarget[5] = shelf(highRate, rig ? 58.0f : 85.0f, (resonance.target - 0.5f) * 10.0f, false);
        if (prepared) convolver.target = selected();
        if (!initialized) {
            forEachSmooth([](Smooth& p, double) { p.snap(); }, 0);
            eq = eqTarget; initialized = true;
        }
    }
    void clear() {
        oversampler.reset(); dryDelay.fill({}); dryIndex = 0;
        for (auto& l : lane) l = Lane{};
        for (auto& r : roomDelay) r.fill(0);
        roomIndex = 0;
        forEachSmooth([](Smooth& p, double) { p.snap(); }, 0);
        eq = eqTarget;
        convolver.reset(selected());
    }

    Stereo tick(Stereo input) {
        input.l = sane(input.l); input.r = sane(input.r);
        const Stereo dry = dryDelay[dryIndex]; dryDelay[dryIndex] = input;
        if (++dryIndex == latencySamples) dryIndex = 0;
        const float am = ampMix.next(), om = odMix.next(), dm = dirtMix.next();
        const float gr = gain.next(), ma = master.next(), od = drive.next(), ol = odLevel.next(), ot = odTone.next();
        const float da = dirtAmount.next(), db = dirtBlend.next(), dt = dirtTone.next();
        const float sg = sag.next(), th = tight.next(), br = bassRig.next();
        std::array<float, 4> channels{};
        for (int c = 0; c < 4; ++c) channels[c] = channelMix[c].next();
        const float lowpass1 = poleCoefficient(12500 - br * 1500, highRate);
        const float lowpass2 = poleCoefficient(10500 - br * 1500, highRate);
        Stereo processed{};
        for (int sub = 0; sub < osFactor; ++sub) {
            Stereo hi = oversampler.up(sub == 0 ? input : Stereo{});
            for (int e = 0; e < 6; ++e) eq[e].approach(eqTarget[e], eqSlew);
            float values[2] = {hi.l, hi.r};
            for (int c = 0; c < 2; ++c) {
                auto& l = lane[c]; float x = values[c];
                // Smooth overdrive with frequency-selective feedback and level.
                const float odInput = x - l.odHigh.low(x, odHpCoefficient);
                const float odGain = 1.0f + od * od * 35.0f;
                float over = soft(odInput * odGain) / std::sqrt(1.0f + odGain * 0.48f);
                over = l.odLow.low(over, ot) * ol;
                x += om * (over - x);
                // The bass dirt pedal retains the fundamental/low band. Its
                // amount and parallel blend are independent of amp gain.
                const float lows = l.dirtLow.low(x, dirtSplitCoefficient);
                const float highs = x - lows;
                const float dirtGain = 1.0f + 65.0f * da * da;
                float dirty = soft(highs * dirtGain) / std::sqrt(1.0f + dirtGain * 0.20f);
                dirty = l.dirtSmooth.low(dirty, dt);
                const float dirtySignal = lows + highs * (1.0f - db) + dirty * db;
                x += dm * (dirtySignal - x);
                const float before = x;
                float pre = x - l.inputHigh.low(x, th);
                const float env = l.envelope.low(std::abs(pre), envelopeCoefficient);
                const float supply = 1.0f / (1.0f + sg * env * 1.7f);
                // Channel crossfades interpolate stage drive, bias and topology;
                // the input and filter histories remain continuous.
                const float stageDrive = channels[0] * (0.65f + gr * 0.15f)
                    + channels[1] * (1.2f + gr * 0.85f)
                    + channels[2] * (3.0f + gr * 2.6f)
                    + channels[3] * (6.0f + gr * 5.5f);
                const float distortion = channels[1] * 0.20f + channels[2] * 0.65f + channels[3];
                const float bias = distortion * (0.025f + 0.025f * br);
                float shaped = (soft(pre * stageDrive * supply + bias) - soft(bias));
                // Keep clean gain transparent while balancing high-gain channels.
                shaped *= channels[0] * (1.0f / std::max(0.65f, stageDrive)) + (1.0f - channels[0]) * 0.75f;
                shaped = l.inter1.low(shaped, lowpass1);
                const float stage2Drive = 1.0f + distortion * (1.8f + gr * 0.16f);
                const float second = soft(shaped * stage2Drive - bias) + soft(bias);
                shaped += distortion * (second * 0.72f - shaped);
                shaped = l.inter2.low(shaped, lowpass2);
                for (int e = 0; e < 4; ++e) shaped = l.eq[e].tick(shaped, eq[e]);
                const float powerDrive = 1.0f + ma * 0.8f * distortion;
                const float powered = soft(shaped * powerDrive * supply) / powerDrive;
                shaped += (0.12f + 0.65f * distortion) * (powered - shaped);
                for (int e = 4; e < 6; ++e) shaped = l.eq[e].tick(shaped, eq[e]);
                // Finite output-stage rail voltage also applies to the clean
                // channel. At ordinary levels this is transparent; extreme
                // stacked EQ boosts saturate the modeled power stage instead
                // of relying on the outer emergency nonfinite/level guard.
                shaped = 3.0f * soft(shaped / 3.0f);
                shaped -= l.powerDC.low(shaped, dcCoefficient);
                shaped *= ma * 2.0f;
                values[c] = before + am * (shaped - before);
            }
            const Stereo decimated = oversampler.down({values[0], values[1]}, sub == 0);
            if (sub == 0) processed = decimated;
        }
        const float pm = processMix.next();
        Stereo signal{dry.l + pm * (processed.l - dry.l), dry.r + pm * (processed.r - dry.r)};
        Stereo cab = convolver.tick(signal, fft);
        const float cm = cabMix.next(), cl = cabLow.next(), ch = cabHigh.next(), mi = mic.next(), ro = room.next();
        const float micCoefficient = poleCoefficient(2000.0f, rate);
        float values[2] = {cab.l, cab.r};
        for (int c = 0; c < 2; ++c) {
            auto& l = lane[c]; float x = values[c];
            x -= l.cabinetHigh.low(x, cl);
            x = l.cabinetLow2.low(l.cabinetLow1.low(x, ch), ch);
            const float low = l.micLow.low(x, micCoefficient);
            // 0 = bright/near, 100 = dark/off-axis. The body remains audible.
            x = low + (x - low) * (1.35f - mi * 1.05f);
            roomDelay[c][roomIndex] = x; values[c] = x;
        }
        const int mask = static_cast<int>(roomDelay[0].size()) - 1;
        const float roomL = roomDelay[0][(roomIndex - roomTap1) & mask] * 0.36f
            + roomDelay[1][(roomIndex - roomTap2) & mask] * 0.26f
            - roomDelay[0][(roomIndex - roomTap3) & mask] * 0.15f;
        const float roomR = roomDelay[1][(roomIndex - roomTap2) & mask] * 0.36f
            + roomDelay[0][(roomIndex - roomTap1) & mask] * 0.26f
            - roomDelay[1][(roomIndex - roomTap3 - 19) & mask] * 0.15f;
        roomIndex = (roomIndex + 1) & mask;
        cab = {values[0] + ro * roomL, values[1] + ro * roomR};
        return {sane(signal.l + cm * (cab.l - signal.l)), sane(signal.r + cm * (cab.r - signal.r))};
    }
};

AmpCore::AmpCore() : impl(std::make_unique<Impl>()) {}
AmpCore::~AmpCore() = default;
void AmpCore::prepare(double sampleRate) {
    auto& p = *impl; p.rate = std::max(8000.0, std::min(384000.0, sampleRate)); p.highRate = p.rate * osFactor;
    p.forEachSmooth([](Smooth& smooth, double sr) { smooth.time(sr); }, p.rate);
    p.eqSlew = static_cast<float>(1.0 - std::exp(-1.0 / (p.highRate * 0.025)));
    p.dcCoefficient = poleCoefficient(8, p.highRate);
    p.envelopeCoefficient = poleCoefficient(9, p.highRate);
    p.odHpCoefficient = poleCoefficient(90, p.highRate);
    p.dirtSplitCoefficient = poleCoefficient(180, p.highRate);
    p.roomTap1 = static_cast<int>(p.rate * 0.0113);
    p.roomTap2 = static_cast<int>(p.rate * 0.0171);
    p.roomTap3 = static_cast<int>(p.rate * 0.0297);
    p.convolver.morph = static_cast<float>(1.0 - std::exp(-block / (p.rate * 0.035)));
    p.oversampler.prepare();
    std::array<float, maxIRSamples> impulse{};
    const int length = std::min(maxIRSamples, std::max(512, static_cast<int>(p.rate * 0.023)));
    for (int rig = 0; rig < 2; ++rig) for (int cab = 0; cab < 7; ++cab) {
        makeCabinet(impulse.data(), length, p.rate, rig, cab);
        p.factories[rig * 7 + cab].make(impulse.data(), length, p.fft);
    }
    // A custom impulse is rate-specific; clear it when the host changes rates.
    impulse.fill(0); impulse[0] = 1.0f; p.user.make(impulse.data(), 1, p.fft); p.hasUser = false;
    p.prepared = true; p.initialized = false; p.set(p.settings); p.clear();
}
void AmpCore::reset() { if (impl->prepared) impl->clear(); }
void AmpCore::setSettings(const Settings& settings) { impl->set(settings); }
Stereo AmpCore::process(Stereo input) { return impl->prepared ? impl->tick(input) : Stereo{}; }
void AmpCore::setUserImpulse(const float* mono, int length) {
    auto& p = *impl;
    if (!p.prepared) return;
    std::array<float, maxIRSamples> clean{};
    length = std::max(0, std::min(length, maxIRSamples));
    if (mono == nullptr || length == 0) {
        clean[0] = 1.0f; p.user.make(clean.data(), 1, p.fft); p.hasUser = false;
    } else {
        float energy = 0;
        for (int n = 0; n < length; ++n) { clean[n] = sane(mono[n]); energy += clean[n] * clean[n]; }
        if (energy > 16.0f) {
            const float scale = 4.0f / std::sqrt(energy);
            for (int n = 0; n < length; ++n) clean[n] *= scale;
        }
        p.user.make(clean.data(), length, p.fft); p.hasUser = energy > 1.0e-12f;
    }
    p.convolver.target = p.selected();
}

} // namespace ironvale
