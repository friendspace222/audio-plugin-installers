#include "AmpCore.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <complex>
#include <cstddef>

namespace ironvale {
namespace {
constexpr float pi = 3.14159265358979323846f;
constexpr int osFactor = 4, osTaps = 129;
constexpr int block = 64, fftSize = 128;
constexpr int partitions = AmpCore::maxIRSamples / block;
using Complex = std::complex<float>;
using Spectrum = std::array<Complex, fftSize>;
inline float clamp(float x, float lo, float hi) { return std::max(lo, std::min(hi, x)); }
inline float dbGain(float d) { return std::pow(10.0f, d * 0.05f); }
inline float sane(float x) { return std::isfinite(x) ? clamp(x, -32.0f, 32.0f) : 0.0f; }
inline float denormal(float x) { return std::abs(x) < 1.0e-25f ? 0.0f : x; }
inline float soft(float x) { return std::tanh(x); }

struct Smooth {
    float value = 0.0f, target = 0.0f, coefficient = 0.001f;
    void time(double sr, double seconds = 0.02) { coefficient = static_cast<float>(1.0 - std::exp(-1.0 / (sr * seconds))); }
    float next() { value += coefficient * (target - value); return value; }
    void snap() { value = target; }
};

struct Pole {
    float state = 0.0f;
    float low(float x, float coefficient) { state = denormal(state + coefficient * (x - state)); return state; }
    void reset() { state = 0.0f; }
};
float poleCoefficient(float frequency, double rate) {
    return 1.0f - std::exp(-2.0f * pi * std::min(frequency, static_cast<float>(rate * 0.45)) / static_cast<float>(rate));
}

// RBJ cookbook biquads, transposed direct form II. Coefficient interpolation
// is restricted to stable, low-Q shelf and bell settings.
struct Coeff {
    double b0 = 1.0, b1 = 0.0, b2 = 0.0, a1 = 0.0, a2 = 0.0;
    void approach(const Coeff& b, float t) {
        b0 += t * (b.b0 - b0); b1 += t * (b.b1 - b1); b2 += t * (b.b2 - b2);
        a1 += t * (b.a1 - a1); a2 += t * (b.a2 - a2);
    }
};
Coeff bell(double sr, float hz, float gain, float q = 0.7f) {
    const double a = std::pow(10.0, gain / 40.0);
    const double w = 6.2831853071795864769 * std::min(static_cast<double>(hz), sr * 0.4) / sr;
    const double alpha = std::sin(w) / (2.0 * q), c = std::cos(w), d = 1.0 + alpha / a;
    return {(1.0f + alpha * a) / d, -2.0f * c / d, (1.0f - alpha * a) / d,
            -2.0f * c / d, (1.0f - alpha / a) / d};
}
Coeff shelf(double sr, float hz, float gain, bool high) {
    const double a = std::pow(10.0, gain / 40.0);
    const double w = 6.2831853071795864769 * std::min(static_cast<double>(hz), sr * 0.4) / sr;
    const double c = std::cos(w), beta = std::sin(w) * std::sqrt(2.0 * a);
    double b0, b1, b2, a0, a1, a2;
    if (high) {
        b0 = a * ((a + 1) + (a - 1) * c + beta); b1 = -2 * a * ((a - 1) + (a + 1) * c); b2 = a * ((a + 1) + (a - 1) * c - beta);
        a0 = (a + 1) - (a - 1) * c + beta; a1 = 2 * ((a - 1) - (a + 1) * c); a2 = (a + 1) - (a - 1) * c - beta;
    } else {
        b0 = a * ((a + 1) - (a - 1) * c + beta); b1 = 2 * a * ((a - 1) - (a + 1) * c); b2 = a * ((a + 1) - (a - 1) * c - beta);
        a0 = (a + 1) + (a - 1) * c + beta; a1 = -2 * ((a - 1) + (a + 1) * c); a2 = (a + 1) + (a - 1) * c - beta;
    }
    return {b0/a0, b1/a0, b2/a0, a1/a0, a2/a0};
}
struct Biquad {
    // Double state and coefficients matter for bass filters at 4x 192 kHz:
    // single-precision pole interpolation can otherwise cross the unit circle.
    double z1 = 0.0, z2 = 0.0;
    float tick(float x, const Coeff& c) {
        const double y = c.b0 * x + z1;
        z1 = c.b1 * x - c.a1 * y + z2; z2 = c.b2 * x - c.a2 * y;
        if (std::abs(z1) < 1.0e-30) z1 = 0;
        if (std::abs(z2) < 1.0e-30) z2 = 0;
        return static_cast<float>(y);
    }
    void reset() { z1 = z2 = 0.0f; }
};

// A smooth asymmetric triode-like stage with bounded grid-charge memory and
// AC coupling. This is an original reduced model, not a circuit solver or a
// claim to reproduce a particular commercial amplifier. Grid-current recovery
// changes the knee on an attack instead of flattening every note identically.
struct ValveStage {
    Pole charge, coupling;
    float tick(float input, float drive, float bias, float memory,
               float attack, float release, float couplingCoefficient) {
        const float driven = input * drive;
        const float demand = clamp(driven - 0.72f, 0.0f, 2.0f);
        const float charged = charge.low(demand, demand > charge.state ? attack : release);
        const float operatingPoint = bias - memory * charged;
        const float zero = soft(operatingPoint);
        const float slope = std::max(0.65f, 1.0f - zero * zero);
        float out = (soft(driven + operatingPoint) - zero) / slope;
        out -= coupling.low(out, couplingCoefficient);
        return out;
    }
};

struct FFT {
    std::array<int, fftSize> reverse{};
    std::array<Complex, fftSize / 2> roots{};
    FFT() {
        for (int n = 0; n < fftSize; ++n) {
            int j = 0, a = n;
            for (int k = 0; k < 7; ++k) { j = (j << 1) | (a & 1); a >>= 1; }
            reverse[n] = j;
        }
        for (int n = 0; n < fftSize / 2; ++n) {
            const float phase = -2.0f * pi * n / fftSize;
            roots[n] = Complex(std::cos(phase), std::sin(phase));
        }
    }
    void transform(Spectrum& x, bool inverse = false) const {
        for (int n = 0; n < fftSize; ++n) if (n < reverse[n]) std::swap(x[n], x[reverse[n]]);
        for (int len = 2; len <= fftSize; len <<= 1) {
            const int stride = fftSize / len;
            for (int offset = 0; offset < fftSize; offset += len)
                for (int n = 0; n < len / 2; ++n) {
                    const Complex w = inverse ? std::conj(roots[n * stride]) : roots[n * stride];
                    const Complex u = x[offset + n], v = x[offset + n + len / 2] * w;
                    x[offset + n] = u + v; x[offset + n + len / 2] = u - v;
                }
        }
        if (inverse) for (auto& value : x) value *= 1.0f / fftSize;
    }
};
struct Impulse {
    std::array<float, block> head{};
    std::array<Spectrum, partitions> spectra{};
    int count = 1;
    void make(const float* samples, int length, const FFT& fft) {
        head.fill(0.0f);
        for (auto& partition : spectra) partition.fill({});
        length = std::max(0, std::min(length, AmpCore::maxIRSamples));
        count = std::max(1, (length + block - 1) / block);
        for (int n = 0; n < std::min(length, block); ++n) head[n] = samples[n];
        for (int p = 1; p < count; ++p) {
            for (int n = 0; n < block && p * block + n < length; ++n) spectra[p][n] = samples[p * block + n];
            fft.transform(spectra[p]);
        }
    }
};

// First 64 taps are direct, later taps use partitioned overlap-add. The first
// sample of an IR is audible immediately: cabinet convolution adds no latency.
struct CabinetConvolver {
    struct Lane {
        std::array<float, block> recent{}, input{}, tail{}, overlap{};
        std::array<Spectrum, partitions> history{};
    };
    std::array<Lane, 2> lane{};
    Impulse current{};
    const Impulse* target = nullptr;
    int position = 0, historyIndex = 0;
    float morph = 0.04f;
    void reset(const Impulse* impulse) {
        for (auto& l : lane) {
            l.recent.fill(0); l.input.fill(0); l.tail.fill(0); l.overlap.fill(0);
            for (auto& h : l.history) h.fill({});
        }
        target = impulse; if (target) current = *target;
        position = historyIndex = 0;
    }
    Stereo tick(Stereo input, const FFT& fft) {
        float result[2]{};
        const float ins[2] = {input.l, input.r};
        for (int channel = 0; channel < 2; ++channel) {
            auto& l = lane[channel]; l.recent[position] = l.input[position] = ins[channel];
            float y = l.tail[position]; int at = position;
            for (int tap = 0; tap < block; ++tap) { y += current.head[tap] * l.recent[at]; at = (at - 1) & (block - 1); }
            result[channel] = y;
        }
        if (++position == block) {
            position = 0;
            if (target) {
                current.count = std::max(current.count, target->count);
                for (int n = 0; n < block; ++n) current.head[n] += morph * (target->head[n] - current.head[n]);
                for (int p = 1; p < current.count; ++p)
                    for (int n = 0; n < fftSize; ++n) current.spectra[p][n] += morph * (target->spectra[p][n] - current.spectra[p][n]);
            }
            for (auto& l : lane) {
                Spectrum& in = l.history[historyIndex]; in.fill({});
                for (int n = 0; n < block; ++n) in[n] = l.input[n];
                fft.transform(in);
                Spectrum sum{};
                for (int p = 1; p < current.count; ++p) {
                    const auto& past = l.history[(historyIndex - (p - 1) + partitions) % partitions];
                    const auto& ir = current.spectra[p];
                    for (int n = 0; n < fftSize; ++n) sum[n] += past[n] * ir[n];
                }
                fft.transform(sum, true);
                for (int n = 0; n < block; ++n) {
                    l.tail[n] = denormal(sum[n].real() + l.overlap[n]);
                    l.overlap[n] = denormal(sum[n + block].real());
                }
            }
            historyIndex = (historyIndex + 1) % partitions;
        }
        return {result[0], result[1]};
    }
};

struct Oversampler {
    std::array<float, osTaps> coefficients{};
    struct Lane { std::array<float, osTaps> up{}, down{}; };
    std::array<Lane, 2> lane{};
    int upIndex = 0, downIndex = 0, phase = 0;
    void prepare() {
        // Blackman-windowed lowpass, cutoff 0.1125 of the 4x rate. Both
        // linear-phase stages have 64 high-rate samples of group delay.
        float total = 0;
        for (int n = 0; n < osTaps; ++n) {
            const int k = n - (osTaps - 1) / 2;
            const float sinc = k == 0 ? 0.225f : std::sin(pi * 0.225f * k) / (pi * k);
            const float window = 0.42f - 0.5f * std::cos(2 * pi * n / (osTaps - 1)) + 0.08f * std::cos(4 * pi * n / (osTaps - 1));
            coefficients[n] = sinc * window; total += coefficients[n];
        }
        for (auto& c : coefficients) c /= total;
        reset();
    }
    void reset() { for (auto& l : lane) { l.up.fill(0); l.down.fill(0); } upIndex = downIndex = phase = 0; }
    Stereo up(Stereo x) {
        lane[0].up[upIndex] = x.l; lane[1].up[upIndex] = x.r;
        // Polyphase interpolation skips the three inserted zeros per input
        // sample. This preserves the exact FIR while reducing CPU on old Macs.
        Stereo out{}; int at = upIndex - phase;
        if (at < 0) at += osTaps;
        for (int n = phase; n < osTaps; n += osFactor) {
            const float c = coefficients[n] * osFactor;
            out.l += lane[0].up[at] * c; out.r += lane[1].up[at] * c;
            at -= osFactor; if (at < 0) at += osTaps;
        }
        phase = (phase + 1) & (osFactor - 1);
        if (++upIndex == osTaps) upIndex = 0; return out;
    }
    Stereo down(Stereo x, bool emit) {
        lane[0].down[downIndex] = x.l; lane[1].down[downIndex] = x.r;
        Stereo out{};
        if (emit) {
            int at = downIndex;
            for (int n = 0; n < osTaps; ++n) {
                out.l += lane[0].down[at] * coefficients[n]; out.r += lane[1].down[at] * coefficients[n];
                if (--at < 0) at = osTaps - 1;
            }
        }
        if (++downIndex == osTaps) downIndex = 0; return out;
    }
};

// Original causal speaker/cabinet transfer functions. Separate cone breakup,
// broad cabinet body and close-mic reflections avoid the old single low-pass
// and broad mid scoop. Larger enclosures retain low fundamental energy, while
// the 90-140 Hz guitar resonance supplies the body of a palm-muted attack.
// These are mathematical voices, not measured or licensed cabinet captures.
void makeCabinet(float* output, int length, double rate, int rig, int cabinet) {
    static constexpr float guitarCut[7] = {5100, 4800, 5300, 4650, 4350, 4850, 4250};
    static constexpr float bassCut[7] = {6300, 5300, 5900, 5200, 4800, 6100, 5300};
    static constexpr float guitarBody[7] = {127, 118, 117, 106, 101, 92, 86};
    static constexpr float bassBody[7] = {77, 68, 65, 58, 53, 48, 43};
    static constexpr float bodyDb[7] = {2.8f, 3.6f, 4.0f, 4.8f, 5.8f, 6.7f, 7.0f};
    static constexpr float depth[7] = {0.09f, 0.15f, 0.12f, 0.20f, 0.25f, 0.29f, 0.32f};
    Pole lp1, lp2, hp;
    std::array<Biquad, 8> filters{};
    const float cut = (rig ? bassCut : guitarCut)[cabinet];
    const float lc = poleCoefficient(cut, rate);
    const float hc = poleCoefficient(rig ? (cabinet >= 4 ? 12.0f : 18.0f) : (cabinet >= 3 ? 30.0f : 44.0f), rate);
    const float res = (rig ? bassBody : guitarBody)[cabinet];
    const std::array<Coeff,8> coefficients {{
        bell(rate, res, bodyDb[cabinet] + (rig ? 0.8f : 0.0f), rig ? 0.65f : 0.85f),
        bell(rate, rig ? 145.0f : 210.0f, 1.3f + cabinet * 0.18f, 0.65f),
        bell(rate, rig ? 360.0f : (cabinet == 4 ? 630.0f : 480.0f), rig ? -0.3f : -2.2f, 0.85f),
        bell(rate, rig ? 1150.0f : (cabinet == 4 ? 1500.0f : 1850.0f), rig ? 3.0f : 2.1f, 1.1f),
        bell(rate, rig ? 2600.0f : 3050.0f + cabinet * 90.0f, rig ? -1.0f : -2.2f, 2.4f),
        bell(rate, rig ? 3600.0f : 3900.0f - cabinet * 80.0f, rig ? -1.8f : 1.8f, 1.8f),
        shelf(rate, rig ? 160.0f : 190.0f, cabinet >= 4 ? (rig ? 1.7f : 1.0f) : 0.0f, false),
        shelf(rate, 500.0f, rig ? 3.5f : 0.0f, true)
    }};
    std::array<float, AmpCore::maxIRSamples> clean{};
    for (int n = 0; n < length; ++n) {
        float x = n == 0 ? 1.0f : 0.0f;
        x = lp2.low(lp1.low(x, lc), lc); x -= hp.low(x, hc);
        for (int f = 0; f < 8; ++f) x = filters[f].tick(x, coefficients[f]);
        clean[n] = x;
    }
    const int bounce1 = std::max(1, static_cast<int>(rate * (0.00028 + cabinet * 0.000055)));
    const int bounce2 = std::max(1, static_cast<int>(rate * (0.00083 + cabinet * 0.000105)));
    for (int n = 0; n < length; ++n) {
        float x = clean[n];
        if (n >= bounce1) x += depth[cabinet] * clean[n - bounce1];
        if (n >= bounce2) x -= depth[cabinet] * 0.40f * clean[n - bounce2];
        // Smooth truncated tails to zero, including at high sample rates.
        if (n > length * 3 / 4) x *= 0.5f + 0.5f * std::cos(pi * (n - length * 3 / 4) / (length / 4.0f));
        output[n] = x;
    }
    // Calibrate gain at a mid-band reference without peak-normalizing resonances.
    Complex response{};
    const float reference = rig ? 250.0f : 700.0f;
    for (int n = 0; n < length; ++n) {
        const float angle = -2 * pi * reference * n / static_cast<float>(rate);
        response += output[n] * Complex(std::cos(angle), std::sin(angle));
    }
    const float gain = 0.85f / std::max(0.1f, std::abs(response));
    for (int n = 0; n < length; ++n) output[n] *= gain;
}
} // namespace

struct AmpCore::Impl {
    double rate = 48000.0, highRate = 192000.0;
    Settings settings{};
    FFT fft{};
    std::array<Impulse, 14> factories{};
    Impulse user{};
    CabinetConvolver convolver{};
    Oversampler oversampler{};
    bool prepared = false, initialized = false, hasUser = false;
    int rig = 0, channel = 0, cabinet = 0;
    std::array<Stereo, latencySamples> dryDelay{};
    int dryIndex = 0;
    Smooth ampMix, cabMix, odMix, dirtMix, processMix;
    Smooth gain, master, drive, odLevel, odTone, dirtAmount, dirtBlend, dirtTone;
    Smooth sag, tight, presence, resonance, mic, room, cabLow, cabHigh, bassRig;
    std::array<Smooth, 4> channelMix{};
    std::array<Coeff, 6> eq{}, eqTarget{};
    std::array<Coeff, 2> voice{}, voiceTarget{};
    struct Lane {
        Pole inputHigh, inputBody, odHigh, odLow, dirtLow, dirtSmooth, dirtReject1, dirtReject2;
        Pole inter1, inter2, inter3, powerDC, envelope, foundation, transformer;
        Pole cabinetHigh, cabinetLow1, cabinetLow2, micLow;
        std::array<ValveStage, 3> valves{};
        std::array<Biquad, 2> voice{};
        std::array<Biquad, 6> eq{};
    };
    std::array<Lane, 2> lane{};
    std::array<std::array<float, 16384>, 2> roomDelay{};
    int roomIndex = 0, roomTap1 = 0, roomTap2 = 0, roomTap3 = 0;
    float eqSlew = 0.001f, dcCoefficient = 0, odHpCoefficient = 0, dirtSplitCoefficient = 0;
    float gridAttack = 0, gridRelease = 0, sagAttack = 0, sagRelease = 0;
    float bodyCoefficient = 0, foundationCoefficient = 0, dirtRejectCoefficient = 0;

    void forEachSmooth(void (*operation)(Smooth&, double), double arg) {
        Smooth* values[] = {&ampMix,&cabMix,&odMix,&dirtMix,&processMix,&gain,&master,&drive,&odLevel,&odTone,
            &dirtAmount,&dirtBlend,&dirtTone,&sag,&tight,&presence,&resonance,&mic,&room,&cabLow,&cabHigh,&bassRig};
        for (auto* value : values) operation(*value, arg);
        for (auto& value : channelMix) operation(value, arg);
    }
    const Impulse* selected() const {
        if (cabinet == 7 && hasUser) return &user;
        return &factories[rig * 7 + std::min(cabinet, 6)];
    }
    void set(const Settings& s) {
        settings = s;
        rig = std::max(0, std::min(1, s.choice(Param::rig)));
        channel = std::max(0, std::min(3, s.choice(Param::channel)));
        cabinet = std::max(0, std::min(7, s.choice(Param::cabinet)));
        ampMix.target = s.on(Param::ampEnabled) ? 1.0f : 0.0f;
        cabMix.target = s.on(Param::cabEnabled) ? 1.0f : 0.0f;
        odMix.target = s.on(Param::odEnabled) ? 1.0f : 0.0f;
        dirtMix.target = s.on(Param::dirtEnabled) && rig ? 1.0f : 0.0f;
        processMix.target = ampMix.target || odMix.target || dirtMix.target ? 1.0f : 0.0f;
        gain.target = clamp(s.get(Param::ampGain), 0, 10);
        master.target = clamp(s.get(Param::ampMaster), 0, 10) * 0.1f;
        drive.target = clamp(s.get(Param::odDrive), 0, 100) * 0.01f;
        odLevel.target = dbGain(clamp(s.get(Param::odLevelDb), -12, 18));
        odTone.target = poleCoefficient(1000 + 14000 * clamp(s.get(Param::odTone), 0, 100) * 0.01f, highRate);
        dirtAmount.target = clamp(s.get(Param::dirtAmount), 0, 100) * 0.01f;
        dirtBlend.target = clamp(s.get(Param::dirtBlend), 0, 100) * 0.01f;
        dirtTone.target = poleCoefficient(700 + 10500 * clamp(s.get(Param::dirtTone), 0, 100) * 0.01f, highRate);
        sag.target = clamp(s.get(Param::sag), 0, 100) * 0.01f;
        // Tight controls low-frequency drive as well as a gentle input cut.
        // It no longer removes the guitar fundamental before the amp can work.
        tight.target = clamp(s.get(Param::tight), 0, 100) * 0.01f;
        presence.target = clamp(s.get(Param::presence), 0, 100) * 0.01f;
        resonance.target = clamp(s.get(Param::resonance), 0, 100) * 0.01f;
        mic.target = clamp(s.get(Param::cabMic), 0, 100) * 0.01f;
        room.target = clamp(s.get(Param::cabRoom), 0, 100) * 0.01f;
        cabLow.target = poleCoefficient(clamp(s.get(Param::cabLowCut), 20, 250), rate);
        cabHigh.target = poleCoefficient(clamp(s.get(Param::cabHighCut), 2000, 18000), rate);
        bassRig.target = rig ? 1.0f : 0.0f;
        for (int c = 0; c < 4; ++c) channelMix[c].target = c == channel ? 1.0f : 0.0f;
        eqTarget[0] = shelf(highRate, rig ? 75.0f : 110.0f, clamp(s.get(Param::bassDb), -15, 15), false);
        eqTarget[1] = bell(highRate, clamp(s.get(Param::midFreq), 150, 2500), clamp(s.get(Param::lowMidDb), -15, 15));
        eqTarget[2] = bell(highRate, rig ? 1600.0f : 2400.0f, clamp(s.get(Param::highMidDb), -15, 15));
        eqTarget[3] = shelf(highRate, rig ? 3500.0f : 4500.0f, clamp(s.get(Param::trebleDb), -15, 15), true);
        eqTarget[4] = shelf(highRate, 3800, (presence.target - 0.5f) * 12.0f, true);
        eqTarget[5] = bell(highRate, rig ? 62.0f : 108.0f, 2.5f + (resonance.target - 0.5f) * 9.0f, 0.75f);
        // Distinct original voicings: open clean, warm edge, broad British-style
        // crunch mids, and a focused modern high-gain pre-emphasis.
        static constexpr float preHz[4] = {1500, 1150, 1450, 1900};
        static constexpr float preDb[4] = {0, 1.0f, 2.4f, 3.6f};
        static constexpr float midHz[4] = {700, 640, 780, 540};
        static constexpr float midDb[4] = {0, 1.0f, 2.1f, -1.2f};
        voiceTarget[0] = bell(highRate, rig ? preHz[channel] * 0.65f : preHz[channel], preDb[channel] * (rig ? 0.5f : 1.0f), 0.65f);
        voiceTarget[1] = bell(highRate, rig ? midHz[channel] * 0.6f : midHz[channel], midDb[channel] * (rig ? 0.5f : 1.0f), 0.7f);
        if (prepared) convolver.target = selected();
        if (!initialized) {
            forEachSmooth([](Smooth& p, double) { p.snap(); }, 0);
            eq = eqTarget; voice = voiceTarget; initialized = true;
        }
    }
    void clear() {
        oversampler.reset(); dryDelay.fill({}); dryIndex = 0;
        for (auto& l : lane) l = Lane{};
        for (auto& r : roomDelay) r.fill(0);
        roomIndex = 0;
        forEachSmooth([](Smooth& p, double) { p.snap(); }, 0);
        eq = eqTarget; voice = voiceTarget;
        convolver.reset(selected());
    }

    Stereo tick(Stereo input) {
        input.l = sane(input.l); input.r = sane(input.r);
        const Stereo dry = dryDelay[dryIndex]; dryDelay[dryIndex] = input;
        if (++dryIndex == latencySamples) dryIndex = 0;
        const float am = ampMix.next(), om = odMix.next(), dm = dirtMix.next();
        const float gr = gain.next(), ma = master.next(), od = drive.next(), ol = odLevel.next(), ot = odTone.next();
        const float da = dirtAmount.next(), db = dirtBlend.next(), dt = dirtTone.next();
        const float sg = sag.next(), th = tight.next(), br = bassRig.next();
        std::array<float, 4> channels{};
        for (int c = 0; c < 4; ++c) channels[c] = channelMix[c].next();
        const float distortion = channels[1] * 0.30f + channels[2] * 0.70f + channels[3];
        const float inputHighpass = poleCoefficient((1.0f - br) * (28.0f + 40.0f * th * th) + br * (14.0f + 12.0f * th * th), highRate);
        const float couplingCoefficient = poleCoefficient((1.0f - br) * (9.0f + 9.0f * distortion) + br * 5.0f, highRate);
        const float lowpass1 = poleCoefficient(10500.0f - distortion * 1800.0f - br * 800.0f, highRate);
        const float lowpass2 = poleCoefficient(8500.0f - distortion * 1500.0f - br * 700.0f, highRate);
        const float lowpass3 = poleCoefficient(9000.0f - distortion * 1800.0f, highRate);
        const float stage1Drive = channels[0] * (0.85f + gr * 0.12f)
            + channels[1] * (1.2f + gr * 0.65f)
            + channels[2] * (2.2f + gr * 1.15f)
            + channels[3] * (3.0f + gr * 1.85f);
        const float stage2Drive = 1.0f + channels[1] * (0.65f + gr * 0.09f)
            + channels[2] * (1.20f + gr * 0.14f)
            + channels[3] * (1.80f + gr * 0.22f);
        const float stage3Drive = 1.0f + channels[2] * 0.75f + channels[3] * (0.9f + gr * 0.12f);
        const float stage2Mix = channels[1] * 0.65f + channels[2] + channels[3];
        const float stage3Mix = channels[2] * 0.28f + channels[3];
        const float bias1 = channels[0] * 0.012f + channels[1] * 0.17f + channels[2] * 0.25f + channels[3] * 0.14f;
        const float stageTrim = channels[0] / std::max(0.70f, stage1Drive)
            + channels[1] * 0.82f + channels[2] * 0.71f + channels[3] * 0.64f;
        Stereo processed{};
        for (int sub = 0; sub < osFactor; ++sub) {
            Stereo hi = oversampler.up(sub == 0 ? input : Stereo{});
            for (int e = 0; e < 6; ++e) eq[e].approach(eqTarget[e], eqSlew);
            for (int e = 0; e < 2; ++e) voice[e].approach(voiceTarget[e], eqSlew);
            float values[2] = {hi.l, hi.r};
            for (int c = 0; c < 2; ++c) {
                auto& l = lane[c]; float x = values[c];
                // Smooth overdrive with frequency-selective feedback and level.
                const float odInput = x - l.odHigh.low(x, odHpCoefficient);
                const float odGain = 1.0f + od * od * 35.0f;
                float over = soft(odInput * odGain) / std::sqrt(1.0f + odGain * 0.48f);
                over = l.odLow.low(over, ot) * ol;
                x += om * (over - x);
                // The bass dirt pedal retains the fundamental/low band. Its
                // amount and parallel blend are independent of amp gain.
                const float lows = l.dirtLow.low(x, dirtSplitCoefficient);
                const float highs = x - lows;
                const float dirtGain = 1.0f + 65.0f * da * da;
                float dirty = soft(highs * dirtGain) / std::sqrt(1.0f + dirtGain * 0.20f);
                dirty = l.dirtSmooth.low(dirty, dt);
                // Remove newly generated LF from the dirty branch before it
                // rejoins the clean foundation; dirt must not flatten the B/E
                // string fundamental into the same clipped waveform.
                dirty -= l.dirtReject1.low(dirty, dirtRejectCoefficient);
                dirty -= l.dirtReject2.low(dirty, dirtRejectCoefficient);
                const float dirtySignal = lows + highs * (1.0f - db) + dirty * db;
                x += dm * (dirtySignal - x);
                const float before = x;
                float pre = x - l.inputHigh.low(x, inputHighpass);
                const float foundation = l.foundation.low(pre, foundationCoefficient);
                const float lowDrive = l.inputBody.low(pre, bodyCoefficient);
                pre -= lowDrive * th * distortion * (0.43f - 0.28f * br);
                pre = l.voice[0].tick(pre, voice[0]);
                const float supply = 1.0f / (1.0f + sg * l.envelope.state * (0.95f - br * 0.20f));
                float shaped = l.valves[0].tick(pre, stage1Drive * (0.92f + 0.08f * supply), bias1,
                    distortion * 0.10f, gridAttack, gridRelease, couplingCoefficient);
                shaped = l.inter1.low(shaped, lowpass1);
                const float second = l.valves[1].tick(shaped, stage2Drive, -0.22f + br * 0.06f,
                    distortion * 0.16f, gridAttack, gridRelease, couplingCoefficient);
                shaped += stage2Mix * (second * 0.86f - shaped);
                shaped = l.inter2.low(shaped, lowpass2);
                const float third = l.valves[2].tick(shaped, stage3Drive, 0.27f - br * 0.10f,
                    distortion * 0.12f, gridAttack, gridRelease, couplingCoefficient);
                shaped += stage3Mix * (third * 0.83f - shaped);
                shaped = l.inter3.low(shaped, lowpass3) * stageTrim;
                shaped = l.voice[1].tick(shaped, voice[1]);
                shaped += foundation * br * distortion * 0.65f;
                for (int e = 0; e < 4; ++e) shaped = l.eq[e].tick(shaped, eq[e]);
                // Supply droop follows output-stage current demand with fast
                // attack and slow recovery, not the tiny raw DI amplitude.
                const float demand = std::min(2.0f, std::abs(shaped) * (0.35f + ma * 1.8f));
                l.envelope.low(demand, demand > l.envelope.state ? sagAttack : sagRelease);
                const float powerDrive = 0.72f + ma * (0.60f + distortion * 1.2f);
                const float powerBias = 0.015f + distortion * 0.035f;
                const float powered = (soft(shaped * powerDrive / supply + powerBias) - soft(powerBias)) * supply / powerDrive;
                shaped += (0.18f + 0.72f * distortion) * (powered - shaped);
                for (int e = 4; e < 6; ++e) shaped = l.eq[e].tick(shaped, eq[e]);
                const float ironLow = l.transformer.low(shaped, foundationCoefficient);
                shaped += (soft(ironLow * 1.5f) / 1.5f - ironLow) * distortion * 0.20f;
                // Finite output-stage rail voltage also applies to the clean
                // channel. At ordinary levels this is transparent; extreme
                // stacked EQ boosts saturate the modeled power stage instead
                // of relying on the outer emergency nonfinite/level guard.
                shaped = 3.0f * soft(shaped / 3.0f);
                shaped -= l.powerDC.low(shaped, dcCoefficient);
                shaped *= ma * 2.0f;
                values[c] = before + am * (shaped - before);
            }
            const Stereo decimated = oversampler.down({values[0], values[1]}, sub == 0);
            if (sub == 0) processed = decimated;
        }
        const float pm = processMix.next();
        Stereo signal{dry.l + pm * (processed.l - dry.l), dry.r + pm * (processed.r - dry.r)};
        Stereo cab = convolver.tick(signal, fft);
        const float cm = cabMix.next(), cl = cabLow.next(), ch = cabHigh.next(), mi = mic.next(), ro = room.next();
        const float micCoefficient = poleCoefficient(2000.0f, rate);
        float values[2] = {cab.l, cab.r};
        for (int c = 0; c < 2; ++c) {
            auto& l = lane[c]; float x = values[c];
            x -= l.cabinetHigh.low(x, cl);
            x = l.cabinetLow2.low(l.cabinetLow1.low(x, ch), ch);
            const float low = l.micLow.low(x, micCoefficient);
            // 0 = bright/near, 100 = dark/off-axis. The body remains audible.
            x = low + (x - low) * (1.35f - mi * 1.05f);
            roomDelay[c][roomIndex] = x; values[c] = x;
        }
        const int mask = static_cast<int>(roomDelay[0].size()) - 1;
        const float roomL = roomDelay[0][(roomIndex - roomTap1) & mask] * 0.36f
            + roomDelay[1][(roomIndex - roomTap2) & mask] * 0.26f
            - roomDelay[0][(roomIndex - roomTap3) & mask] * 0.15f;
        const float roomR = roomDelay[1][(roomIndex - roomTap2) & mask] * 0.36f
            + roomDelay[0][(roomIndex - roomTap1) & mask] * 0.26f
            - roomDelay[1][(roomIndex - roomTap3 - 19) & mask] * 0.15f;
        roomIndex = (roomIndex + 1) & mask;
        cab = {values[0] + ro * roomL, values[1] + ro * roomR};
        return {sane(signal.l + cm * (cab.l - signal.l)), sane(signal.r + cm * (cab.r - signal.r))};
    }
};

AmpCore::AmpCore() : impl(std::make_unique<Impl>()) {}
AmpCore::~AmpCore() = default;
void AmpCore::prepare(double sampleRate) {
    auto& p = *impl; p.rate = std::max(8000.0, std::min(384000.0, sampleRate)); p.highRate = p.rate * osFactor;
    p.forEachSmooth([](Smooth& smooth, double sr) { smooth.time(sr); }, p.rate);
    p.eqSlew = static_cast<float>(1.0 - std::exp(-1.0 / (p.highRate * 0.025)));
    p.dcCoefficient = poleCoefficient(8, p.highRate);
    p.odHpCoefficient = poleCoefficient(90, p.highRate);
    p.dirtSplitCoefficient = poleCoefficient(180, p.highRate);
    p.dirtRejectCoefficient = poleCoefficient(110, p.highRate);
    p.bodyCoefficient = poleCoefficient(180, p.highRate);
    p.foundationCoefficient = poleCoefficient(125, p.highRate);
    const auto timeCoefficient = [&](double seconds) { return static_cast<float>(1.0 - std::exp(-1.0 / (p.highRate * seconds))); };
    p.gridAttack = timeCoefficient(0.003); p.gridRelease = timeCoefficient(0.045);
    p.sagAttack = timeCoefficient(0.008); p.sagRelease = timeCoefficient(0.140);
    p.roomTap1 = static_cast<int>(p.rate * 0.0113);
    p.roomTap2 = static_cast<int>(p.rate * 0.0171);
    p.roomTap3 = static_cast<int>(p.rate * 0.0297);
    p.convolver.morph = static_cast<float>(1.0 - std::exp(-block / (p.rate * 0.035)));
    p.oversampler.prepare();
    std::array<float, maxIRSamples> impulse{};
    const int length = std::min(maxIRSamples, std::max(512, static_cast<int>(p.rate * 0.038)));
    for (int rig = 0; rig < 2; ++rig) for (int cab = 0; cab < 7; ++cab) {
        makeCabinet(impulse.data(), length, p.rate, rig, cab);
        p.factories[rig * 7 + cab].make(impulse.data(), length, p.fft);
    }
    // A custom impulse is rate-specific; clear it when the host changes rates.
    impulse.fill(0); impulse[0] = 1.0f; p.user.make(impulse.data(), 1, p.fft); p.hasUser = false;
    p.prepared = true; p.initialized = false; p.set(p.settings); p.clear();
}
void AmpCore::reset() { if (impl->prepared) impl->clear(); }
void AmpCore::setSettings(const Settings& settings) { impl->set(settings); }
Stereo AmpCore::process(Stereo input) { return impl->prepared ? impl->tick(input) : Stereo{}; }
void AmpCore::setUserImpulse(const float* mono, int length) {
    auto& p = *impl;
    if (!p.prepared) return;
    std::array<float, maxIRSamples> clean{};
    length = std::max(0, std::min(length, maxIRSamples));
    if (mono == nullptr || length == 0) {
        clean[0] = 1.0f; p.user.make(clean.data(), 1, p.fft); p.hasUser = false;
    } else {
        float energy = 0;
        for (int n = 0; n < length; ++n) { clean[n] = sane(mono[n]); energy += clean[n] * clean[n]; }
        if (energy > 16.0f) {
            const float scale = 4.0f / std::sqrt(energy);
            for (int n = 0; n < length; ++n) clean[n] *= scale;
        }
        p.user.make(clean.data(), length, p.fft); p.hasUser = energy > 1.0e-12f;
    }
    p.convolver.target = p.selected();
}

} // namespace ironvale
