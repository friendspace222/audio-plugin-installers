#include "Pedals.h"
#include "EchoEngine.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <vector>

namespace ironvale
{
namespace
{
constexpr double pi = 3.14159265358979323846;
float bounded(float v, float lo, float hi, float fallback = 0.0f)
{
    return std::isfinite(v) ? std::max(lo, std::min(hi, v)) : fallback;
}
float clean(float v)
{
    return std::isfinite(v) && std::abs(v) > 1.0e-25f ? std::max(-32.0f, std::min(32.0f, v)) : 0.0f;
}
float move(float value, float target, float coefficient)
{
    return value + (target - value) * coefficient;
}
float gain(float db) { return std::pow(10.0f, db * 0.05f); }
float coeff(double seconds, double sr) { return static_cast<float>(1.0 - std::exp(-1.0 / (seconds * sr))); }

struct Ring
{
    std::vector<float> samples;
    int write = 0, valid = 0;
    void prepare(int length) { samples.assign(static_cast<std::size_t>(length), 0.0f); reset(); }
    void reset() { write = valid = 0; }
    void push(float value)
    {
        samples[static_cast<std::size_t>(write)] = clean(value);
        if (++write == static_cast<int>(samples.size())) write = 0;
        valid = std::min(valid+1, static_cast<int>(samples.size()));
    }
    float age(int offset) const
    {
        if (offset < 0 || offset >= valid) return 0.0f;
        int p = write - 1 - offset;
        if (p < 0) p += static_cast<int>(samples.size());
        return samples[static_cast<std::size_t>(p)];
    }
    float read(double delay) const
    {
        const double offset = std::max(1.0, std::min(static_cast<double>(samples.size()-4), delay))-1.0;
        const int n = static_cast<int>(offset);
        const float f = static_cast<float>(offset-n);
        const float a = age(n-1), b = age(n), c = age(n+1), d = age(n+2);
        return ((0.5f*(-a+3*b-3*c+d)*f + a-2.5f*b+2*c-0.5f*d)*f + 0.5f*(c-a))*f + b;
    }
};

// First-order allpass: H(z)=(a+z^-1)/(1+a*z^-1). With six stages,
// a dry/wet sum produces three moving cancellation notches per channel.
struct Allpass
{
    float z = 0.0f;
    float process(float input, float a)
    {
        const float output = a*input + z;
        z = clean(input - a*output);
        return clean(output);
    }
};

struct Values
{
    float gateOn=0, gateThreshold=-65, gateRelease=100;
    float compOn=0, compThreshold=-22, compRatio=4, compAttack=15, compRelease=150, compMakeup=0, compMix=100;
    float chorusOn=0, chorusRate=0.65f, chorusDepth=35, chorusMix=25;
    float phaserOn=0, phaserRate=0.35f, phaserDepth=60, phaserFeedback=25, phaserMix=50;
};
}

struct Pedals::Impl
{
    double sr = 48000.0;
    Values target, current;
    tideglass::Engine echo;
    std::array<Ring,2> chorus;
    std::array<std::array<Allpass,6>,2> allpass;
    std::array<float,2> phaserReturn {{0,0}}, chorusTone {{0,0}};
    std::array<std::array<float,6>,2> apCoefficient {};
    double chorusPhase=0.0, chorusPhase2=0.37, phaserPhase=0.0;
    float smooth=0, switches=0, gateAttack=0, gateRelease=0, detectorAttack=0, detectorRelease=0;
    float compAttack=0, compRelease=0, gateOpenLevel=0, gateCloseLevel=0, compMakeup=1, chorusLP=0;
    float envelope=0, gateEnvelope=0, reduction=0, gateValue=0, relocation=1;
    int hold=0, tick=0, location=0, requestedLocation=0;
    bool gateOpen=false, ready=false, primed=false;

    void prepare(double sampleRate)
    {
        sr = std::isfinite(sampleRate) ? std::max(8000.0, std::min(384000.0, sampleRate)) : 48000.0;
        for (auto& r : chorus) r.prepare(static_cast<int>(sr*0.065)+16);
        echo.prepare(sr);
        smooth=coeff(0.020,sr); switches=coeff(0.004,sr);
        gateAttack=coeff(0.001,sr); detectorAttack=coeff(0.00035,sr); detectorRelease=coeff(0.025,sr);
        chorusLP=static_cast<float>(1-std::exp(-2*pi*std::min(11500.0,0.4*sr)/sr));
        ready=true; reset();
    }
    void reset()
    {
        for (auto& r : chorus) r.reset();
        for (auto& channel : allpass) for (auto& ap : channel) ap.z=0;
        phaserReturn.fill(0); chorusTone.fill(0);
        echo.reset();
        chorusPhase=phaserPhase=0; chorusPhase2=0.37;
        envelope=gateEnvelope=reduction=gateValue=0; relocation=1;
        hold=tick=0; gateOpen=primed=false;
    }
    void settings(const Settings& s)
    {
        auto read=[&s](Param p,float lo,float hi,float fallback) { return bounded(s.get(p),lo,hi,fallback); };
        target.gateOn=s.on(Param::gateEnabled)?1.0f:0.0f;
        target.gateThreshold=read(Param::gateThreshold,-90,-20,-65);
        target.gateRelease=read(Param::gateRelease,10,400,100);
        target.compOn=s.on(Param::compEnabled)?1.0f:0.0f;
        target.compThreshold=read(Param::compThreshold,-50,0,-22);
        target.compRatio=read(Param::compRatio,1,12,4);
        target.compAttack=read(Param::compAttack,1,100,15);
        target.compRelease=read(Param::compRelease,20,500,150);
        target.compMakeup=read(Param::compMakeup,0,18,0);
        target.compMix=read(Param::compMix,0,100,100);
        target.chorusOn=s.on(Param::chorusEnabled)?1.0f:0.0f;
        target.chorusRate=read(Param::chorusRate,0.05f,5,0.65f);
        target.chorusDepth=read(Param::chorusDepth,0,100,35);
        target.chorusMix=read(Param::chorusMix,0,100,25);
        target.phaserOn=s.on(Param::phaserEnabled)?1.0f:0.0f;
        target.phaserRate=read(Param::phaserRate,0.05f,5,0.35f);
        target.phaserDepth=read(Param::phaserDepth,0,100,60);
        target.phaserFeedback=read(Param::phaserFeedback,0,90,25);
        target.phaserMix=read(Param::phaserMix,0,100,50);
        requestedLocation=std::max(0,std::min(1,s.choice(Param::modPosition)));
        tideglass::Parameters e;
        e.delayEnabled=s.on(Param::delayEnabled); e.reverbEnabled=false;
        e.sync=s.on(Param::sync); e.spillover=s.on(Param::spillover);
        constexpr int modeMap[3]={0,1,3};
        const int mode=std::max(0,std::min(2,s.choice(Param::delayMode)));
        e.delayMode=modeMap[mode];
        e.noteL=s.choice(Param::noteL); e.noteR=s.choice(Param::noteR);
        e.rhythmL=s.choice(Param::rhythmL); e.rhythmR=s.choice(Param::rhythmR);
        e.timeMsL=read(Param::timeMsL,1,8000,375); e.timeMsR=read(Param::timeMsR,1,8000,500);
        e.bpm=read(Param::bpm,20,300,120); e.feedback=read(Param::feedback,0,95,35)*0.01f;
        e.delayMix=read(Param::delayMix,0,100,20)*0.01f;
        e.delayLowCut=read(Param::delayLowCut,20,2000,120); e.delayHighCut=read(Param::delayHighCut,500,18000,6500);
        e.delayDuck=read(Param::delayDuck,0,100,15)*0.01f;
        e.modDepth=mode==1?0.25f:0.0f; e.modRate=0.37f; e.driveDb=0;
        e.hold=e.freeze=false; e.reverbMix=0; e.masterMix=1; e.width=1; e.outputDb=0;
        echo.setParameters(e);
    }
    void coefficients()
    {
        gateRelease=coeff(current.gateRelease*0.001,sr);
        gateOpenLevel=gain(current.gateThreshold); gateCloseLevel=gateOpenLevel*0.5623413f;
        compAttack=coeff(current.compAttack*0.001,sr); compRelease=coeff(current.compRelease*0.001,sr);
        compMakeup=gain(current.compMakeup);
    }
    void advance()
    {
        if (!primed)
        {
            current=target; location=requestedLocation; coefficients(); primed=true;
        }
        auto s=[this](float& x,float y) { x=move(x,y,smooth); };
        auto b=[this](float& x,float y) { x=move(x,y,switches); if(std::abs(x-y)<1.0e-7f)x=y; };
        b(current.gateOn,target.gateOn); s(current.gateThreshold,target.gateThreshold); s(current.gateRelease,target.gateRelease);
        b(current.compOn,target.compOn); s(current.compThreshold,target.compThreshold); s(current.compRatio,target.compRatio);
        s(current.compAttack,target.compAttack); s(current.compRelease,target.compRelease); s(current.compMakeup,target.compMakeup); s(current.compMix,target.compMix);
        b(current.chorusOn,target.chorusOn); s(current.chorusRate,target.chorusRate); s(current.chorusDepth,target.chorusDepth); s(current.chorusMix,target.chorusMix);
        b(current.phaserOn,target.phaserOn); s(current.phaserRate,target.phaserRate); s(current.phaserDepth,target.phaserDepth); s(current.phaserFeedback,target.phaserFeedback); s(current.phaserMix,target.phaserMix);
        relocation=move(relocation,location==requestedLocation?1.0f:0.0f,switches);
        if (location!=requestedLocation && relocation<0.0001f) location=requestedLocation;
        if ((tick++&31)==0) coefficients();
    }
    Stereo dynamics(Stereo input)
    {
        const float peak=std::max(std::abs(input.l),std::abs(input.r));
        gateEnvelope=clean(move(gateEnvelope,peak,peak>gateEnvelope?detectorAttack:detectorRelease));
        if (peak>=gateOpenLevel) { gateOpen=true; hold=static_cast<int>(0.010*sr); }
        else if(hold>0) --hold;
        else if(gateEnvelope<gateCloseLevel) gateOpen=false;
        gateValue=clean(move(gateValue,gateOpen?1.0f:0.0f,gateOpen?gateAttack:gateRelease));
        const float gateAmplitude=1.0f-current.gateOn*(1.0f-gateValue);
        input.l*=gateAmplitude; input.r*=gateAmplitude;
        const float level=std::max(std::abs(input.l),std::abs(input.r));
        envelope=clean(move(envelope,level,level>envelope?detectorAttack:detectorRelease));
        const float db=20.0f*std::log10(std::max(envelope,1.0e-10f));
        const float over=db-current.compThreshold;
        constexpr float knee=6.0f;
        float desired=0;
        const float slope=1.0f-1.0f/current.compRatio;
        if(over>knee*0.5f) desired=over*slope;
        else if(over>-knee*0.5f) desired=(over+knee*0.5f)*(over+knee*0.5f)*slope/(2*knee);
        reduction=move(reduction,desired,desired>reduction?compAttack:compRelease);
        const float compressedGain=gain(-reduction)*compMakeup;
        const float amount=current.compOn*current.compMix*0.01f;
        const float amplitude=1.0f+(compressedGain-1.0f)*amount;
        return {clean(input.l*amplitude),clean(input.r*amplitude)};
    }
    Stereo modulation(Stereo input)
    {
        float ch[2]={input.l,input.r};
        const float chorusAmount=0.01f*current.chorusMix*current.chorusOn*relocation;
        const double depth=0.0065*sr*current.chorusDepth*0.01;
        for (std::size_t c=0;c<2;++c)
        {
            const double phaseOffset=c==0?0.0:pi*0.5;
            const double d1=0.017*sr+depth*std::sin(chorusPhase+phaseOffset);
            const double d2=0.024*sr+depth*0.65*std::sin(chorusPhase2+phaseOffset+1.13);
            const float wet=0.62f*chorus[c].read(d1)+0.38f*chorus[c].read(d2);
            chorusTone[c]=clean(move(chorusTone[c],wet,chorusLP));
            chorus[c].push(ch[c]);
            ch[c]+=chorusAmount*(chorusTone[c]-ch[c]);
        }
        chorusPhase+=2*pi*current.chorusRate/sr;
        chorusPhase2+=2*pi*current.chorusRate*1.173/sr;
        if(chorusPhase>=2*pi)chorusPhase-=2*pi;
        if(chorusPhase2>=2*pi)chorusPhase2-=2*pi;

        // Coefficients are sampled every eight samples, far above the LFO
        // bandwidth, to reduce transcendental CPU work.
        if ((tick&7)==1)
        {
            constexpr double spread[6]={0.72,0.85,1.0,1.17,1.38,1.62};
            for(std::size_t c=0;c<2;++c)
            {
                const double sweep=std::sin(phaserPhase+(c==0?0:0.7));
                const double centre=640.0*std::pow(2.0,sweep*2.7*current.phaserDepth*0.01);
                for(std::size_t stage=0;stage<6;++stage)
                {
                    const double f=std::max(25.0,std::min(sr*0.40,centre*spread[stage]));
                    const double t=std::tan(pi*f/sr);
                    apCoefficient[c][stage]=static_cast<float>((t-1)/(t+1));
                }
            }
        }
        const float phaserAmount=current.phaserOn*0.01f*current.phaserMix*relocation;
        const float feedback=0.01f*current.phaserFeedback;
        for(std::size_t c=0;c<2;++c)
        {
            // Normalised feedforward energy and bounded nonlinear feedback
            // keep the resonant setting stable at every allowed sample rate.
            float wet=ch[c]*(1.0f-feedback*0.55f)+phaserReturn[c]*feedback;
            for(std::size_t stage=0;stage<6;++stage) wet=allpass[c][stage].process(wet,apCoefficient[c][stage]);
            phaserReturn[c]=std::abs(wet)>2.0f?std::copysign(2.0f+std::tanh(std::abs(wet)-2.0f),wet):wet;
            ch[c]+=phaserAmount*(wet-ch[c]);
        }
        phaserPhase+=2*pi*current.phaserRate/sr;
        if(phaserPhase>=2*pi)phaserPhase-=2*pi;
        return {clean(ch[0]),clean(ch[1])};
    }
    Stereo pre(Stereo input)
    {
        if(!ready)return input;
        input={clean(input.l),clean(input.r)};
        advance();
        input=dynamics(input);
        return location==0?modulation(input):input;
    }
    Stereo post(Stereo input)
    {
        if(!ready)return input;
        if(location==1)input=modulation(input);
        echo.process(&input.l,&input.r,1);
        return input;
    }
};

Pedals::Pedals():impl(new Impl) {}
Pedals::~Pedals()=default;
Pedals::Pedals(Pedals&&) noexcept=default;
Pedals& Pedals::operator=(Pedals&&) noexcept=default;
void Pedals::prepare(double sr) { impl->prepare(sr); }
void Pedals::reset() { impl->reset(); }
void Pedals::setSettings(const Settings& s) { impl->settings(s); }
Stereo Pedals::processPre(Stereo s) { return impl->pre(s); }
Stereo Pedals::processPost(Stereo s) { return impl->post(s); }
float Pedals::compressorReductionDb() const { return impl->reduction*impl->current.compOn; }
float Pedals::gateGain() const { return 1.0f-impl->current.gateOn*(1.0f-impl->gateValue); }
double Pedals::noteMilliseconds(int note,int rhythm,double bpm) { return tideglass::Engine::noteMilliseconds(note,rhythm,bpm); }
}
