#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>

namespace ironvale
{
enum class Kind { Number, Boolean, Choice };

// A single parameter catalog is shared by the processor, DSP and native editor.
// Settings always contain displayed units: percent is 0..100, gain is dB.
#define IRONVALE_PARAMETERS(X) \
 X(rig,"Instrument",Choice,0,1,1,0,1,"","Guitar|Bass") \
 X(channel,"Amp channel",Choice,0,3,1,0,1,"","Clean|Edge|Crunch|Lead") \
 X(cabinet,"Cabinet",Choice,0,7,1,4,1,"","1x12 Open|1x12 Sealed|2x12 Open|2x12 Sealed|4x12 Vintage|4x12 Modern|8x12 Stack|User IR") \
 X(ampEnabled,"Amplifier on",Boolean,0,1,1,1,1,"","") \
 X(cabEnabled,"Cabinet on",Boolean,0,1,1,1,1,"","") \
 X(bypass,"Global bypass",Boolean,0,1,1,0,1,"","") \
 X(inputDb,"Input trim",Number,-24,24,.1,0,1,"dB","") \
 X(outputDb,"Output trim",Number,-30,12,.1,-6,1,"dB","") \
 X(gateEnabled,"Gate on",Boolean,0,1,1,1,1,"","") \
 X(gateThreshold,"Gate threshold",Number,-90,-20,.1,-65,1,"dB","") \
 X(gateRelease,"Gate release",Number,10,400,1,90,.5,"ms","") \
 X(ampGain,"Preamp gain",Number,0,10,.01,3.5,1,"","") \
 X(ampMaster,"Power amp master",Number,0,10,.01,5,1,"","") \
 X(bassDb,"Bass",Number,-15,15,.1,0,1,"dB","") \
 X(lowMidDb,"Low mid",Number,-15,15,.1,0,1,"dB","") \
 X(midFreq,"Low mid frequency",Number,150,2500,1,750,.4,"Hz","") \
 X(highMidDb,"High mid",Number,-15,15,.1,0,1,"dB","") \
 X(trebleDb,"Treble",Number,-15,15,.1,0,1,"dB","") \
 X(presence,"Presence",Number,0,100,.1,45,1,"%","") \
 X(resonance,"Resonance",Number,0,100,.1,35,1,"%","") \
 X(sag,"Power supply sag",Number,0,100,.1,25,1,"%","") \
 X(tight,"Low end tightness",Number,0,100,.1,40,1,"%","") \
 X(cabLowCut,"Cab low cut",Number,20,250,1,40,.5,"Hz","") \
 X(cabHighCut,"Cab high cut",Number,2000,18000,1,8000,.5,"Hz","") \
 X(cabMic,"Mic edge",Number,0,100,.1,35,1,"%","") \
 X(cabRoom,"Cab room",Number,0,100,.1,10,1,"%","") \
 X(compEnabled,"Compressor on",Boolean,0,1,1,0,1,"","") \
 X(compThreshold,"Compressor threshold",Number,-50,0,.1,-20,1,"dB","") \
 X(compRatio,"Compressor ratio",Number,1,12,.1,4,1,":1","") \
 X(compAttack,"Compressor attack",Number,1,100,.1,15,.5,"ms","") \
 X(compRelease,"Compressor release",Number,20,500,1,120,.5,"ms","") \
 X(compMakeup,"Compressor makeup",Number,0,18,.1,3,1,"dB","") \
 X(compMix,"Compressor mix",Number,0,100,.1,100,1,"%","") \
 X(odEnabled,"Overdrive on",Boolean,0,1,1,0,1,"","") \
 X(odDrive,"Overdrive drive",Number,0,100,.1,30,1,"%","") \
 X(odTone,"Overdrive tone",Number,0,100,.1,50,1,"%","") \
 X(odLevelDb,"Overdrive level",Number,-12,18,.1,0,1,"dB","") \
 X(dirtEnabled,"Bass dirt on",Boolean,0,1,1,0,1,"","") \
 X(dirtAmount,"Bass dirt amount",Number,0,100,.1,40,1,"%","") \
 X(dirtBlend,"Bass dirt blend",Number,0,100,.1,55,1,"%","") \
 X(dirtTone,"Bass dirt tone",Number,0,100,.1,50,1,"%","") \
 X(chorusEnabled,"Chorus on",Boolean,0,1,1,0,1,"","") \
 X(chorusRate,"Chorus rate",Number,.05,5,.01,.7,.5,"Hz","") \
 X(chorusDepth,"Chorus depth",Number,0,100,.1,35,1,"%","") \
 X(chorusMix,"Chorus mix",Number,0,100,.1,25,1,"%","") \
 X(phaserEnabled,"Phaser on",Boolean,0,1,1,0,1,"","") \
 X(phaserRate,"Phaser rate",Number,.05,5,.01,.4,.5,"Hz","") \
 X(phaserDepth,"Phaser depth",Number,0,100,.1,65,1,"%","") \
 X(phaserFeedback,"Phaser feedback",Number,0,90,.1,30,1,"%","") \
 X(phaserMix,"Phaser mix",Number,0,100,.1,40,1,"%","") \
 X(modPosition,"Modulation position",Choice,0,1,1,1,1,"","Before Amp|FX Loop") \
 X(delayEnabled,"Stereo delay on",Boolean,0,1,1,0,1,"","") \
 X(sync,"Delay tempo sync",Boolean,0,1,1,1,1,"","") \
 X(delayMode,"Delay character",Choice,0,2,1,2,1,"","Digital|Tape|Ping Pong") \
 X(noteL,"Left note",Choice,0,7,1,3,1,"","1/64|1/32|1/16|1/8|1/4|1/2|1/1|2/1") \
 X(noteR,"Right note",Choice,0,7,1,4,1,"","1/64|1/32|1/16|1/8|1/4|1/2|1/1|2/1") \
 X(rhythmL,"Left rhythm",Choice,0,2,1,1,1,"","Straight|Dotted|Triplet") \
 X(rhythmR,"Right rhythm",Choice,0,2,1,0,1,"","Straight|Dotted|Triplet") \
 X(timeMsL,"Left delay time",Number,1,8000,.1,375,.4,"ms","") \
 X(timeMsR,"Right delay time",Number,1,8000,.1,500,.4,"ms","") \
 X(feedback,"Delay feedback",Number,0,95,.1,35,1,"%","") \
 X(delayMix,"Delay mix",Number,0,100,.1,22,1,"%","") \
 X(delayLowCut,"Delay low cut",Number,20,2000,1,180,.4,"Hz","") \
 X(delayHighCut,"Delay high cut",Number,500,18000,1,6000,.4,"Hz","") \
 X(delayDuck,"Delay ducking",Number,0,100,.1,25,1,"%","") \
 X(spillover,"Delay tails",Boolean,0,1,1,1,1,"","") \
 X(bpm,"Internal tempo",Number,20,300,.1,120,1,"BPM","")

enum class Param {
#define X(id,name,kind,lo,hi,step,def,skew,unit,choices) id,
 IRONVALE_PARAMETERS(X)
#undef X
 Count
};
inline constexpr std::size_t parameterCount=static_cast<std::size_t>(Param::Count);
struct ParameterSpec { const char* id; const char* name; Kind kind; float minimum,maximum,step,defaultValue,skew; const char* unit; const char* choices; };
inline constexpr std::array<ParameterSpec,parameterCount> parameterSpecs {{
#define X(id,name,kind,lo,hi,step,def,skew,unit,choices) {#id,name,Kind::kind,float(lo),float(hi),float(step),float(def),float(skew),unit,choices},
 IRONVALE_PARAMETERS(X)
#undef X
}};
#undef IRONVALE_PARAMETERS
struct Settings
{
    std::array<float,parameterCount> values {};
    Settings() noexcept { for(std::size_t i=0;i<parameterCount;++i) values[i]=parameterSpecs[i].defaultValue; }
    float get(Param p) const noexcept { return values[static_cast<std::size_t>(p)]; }
    bool on(Param p) const noexcept { return get(p)>0.5f; }
    int choice(Param p) const noexcept { return static_cast<int>(std::round(get(p))); }
    void set(Param p,float v) noexcept
    {
        const auto i=static_cast<std::size_t>(p); const auto& spec=parameterSpecs[i];
        values[i]=std::isfinite(v) ? std::clamp(v,spec.minimum,spec.maximum) : spec.defaultValue;
    }
};
struct Stereo { float l=0, r=0; };
} // namespace ironvale
