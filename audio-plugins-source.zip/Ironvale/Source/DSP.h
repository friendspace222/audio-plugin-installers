#pragma once
#include "Parameters.h"
#include "AmpCore.h"
#include "Pedals.h"
#include <array>

namespace ironvale
{
class Engine
{
public:
    void prepare(double sampleRate);
    void reset();
    void setSettings(const Settings&);
    void setUserImpulse(const float* samples,int count) { amp.setUserImpulse(samples,count); }
    void process(float* left,float* right,int count,bool hostBypassed=false);
    float compressorReductionDb() const { return pedals.compressorReductionDb(); }
    static constexpr int latencySamples=AmpCore::latencySamples;
private:
    AmpCore amp;
    Pedals pedals;
    Settings settings;
    std::array<Stereo,latencySamples> dryHistory{};
    int dryPosition=0;
    float inputGain=1,outputGain=0.5011872f,bypassAmount=0,smoothCoefficient=0.001f;
    bool primed=false;
};
}
