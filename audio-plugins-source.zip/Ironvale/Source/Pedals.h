#pragma once

#include "Parameters.h"
#include <memory>

namespace ironvale
{
// One stereo sample must pass through processPre, the amplifier, and then
// processPost, in that order. prepare is the only allocating operation.
class Pedals
{
public:
    Pedals();
    ~Pedals();
    Pedals(Pedals&&) noexcept;
    Pedals& operator=(Pedals&&) noexcept;
    Pedals(const Pedals&) = delete;
    Pedals& operator=(const Pedals&) = delete;
    void prepare(double sampleRate);
    void reset();
    void setSettings(const Settings& settings);
    Stereo processPre(Stereo input);
    Stereo processPost(Stereo input);
    float compressorReductionDb() const;
    float gateGain() const;
    static double noteMilliseconds(int note, int rhythm, double bpm);
private:
    struct Impl;
    std::unique_ptr<Impl> impl;
};
}
