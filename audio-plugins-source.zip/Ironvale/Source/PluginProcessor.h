#pragma once
#include <JuceHeader.h>
#include "DSP.h"
#include <array>
#include <atomic>
#include <vector>

class IronvaleAudioProcessor final : public juce::AudioProcessor
{
public:
    IronvaleAudioProcessor();
    ~IronvaleAudioProcessor() override = default;
    void prepareToPlay(double,int) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
    void processBlockBypassed(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Ironvale"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override;
    juce::AudioProcessorParameter* getBypassParameter() const override;
    int getNumPrograms() override;
    int getCurrentProgram() override { return selectedPreset.load(); }
    void setCurrentProgram(int n) override { loadFactoryPreset(n); }
    const juce::String getProgramName(int) override;
    void changeProgramName(int,const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*,int) override;
    juce::StringArray getFactoryPresetNames() const;
    void loadFactoryPreset(int);
    void tapTempo();
    void requestPanic() noexcept { panicRequested.store(true); }
    bool savePresetToFile(const juce::File&);
    bool loadPresetFromFile(const juce::File&);
    void loadCabinetIR(const juce::File&);
    juce::String getCabinetIRName() const;

    juce::AudioProcessorValueTreeState parameters;
    std::atomic<float> inputPeak{0},outputPeak{0},compressionDb{0};
    std::atomic<double> currentBpm{120};
    std::atomic<bool> hostTempoActive{false};

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    ironvale::Settings readSettings() const;
    void process(juce::AudioBuffer<float>&,juce::MidiBuffer&,bool);
    juce::ValueTree snapshotState();
    bool restoreState(const juce::ValueTree&);
    void queueImpulse();
    std::vector<float> resampleImpulse(const std::vector<float>&,double,double) const;
    ironvale::Engine engine;
    std::array<std::atomic<float>*,ironvale::parameterCount> raw{};
    juce::AudioBuffer<float> monoScratch;
    std::atomic<int> selectedPreset{0};
    std::atomic<bool> panicRequested{false};
    std::atomic<double> processingRate{48000};
    std::atomic_flag irMailbox=ATOMIC_FLAG_INIT;
    std::atomic<bool> irPending{false};
    std::array<float,ironvale::AmpCore::maxIRSamples> queuedIR{};
    int queuedIRLength=0;
    mutable juce::CriticalSection irStateLock;
    std::vector<float> storedIR;
    double storedIRRate=48000;
    juce::String irName="No user IR loaded - factory fallback";
    double lastTap=0;
    std::array<double,4> tapIntervals{};
    int tapCount=0;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(IronvaleAudioProcessor)
};
