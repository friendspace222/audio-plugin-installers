#include "DSP.h"
#include <algorithm>
#include <cmath>

namespace ironvale
{
void Engine::prepare(double sampleRate)
{
    sampleRate=std::isfinite(sampleRate)?std::clamp(sampleRate,8000.0,192000.0):48000.0;
    amp.prepare(sampleRate);pedals.prepare(sampleRate);
    smoothCoefficient=static_cast<float>(1.0-std::exp(-1.0/(sampleRate*.012)));
    reset();
}
void Engine::reset()
{
    amp.reset();pedals.reset();dryHistory.fill({});dryPosition=0;primed=false;
}
void Engine::setSettings(const Settings& incoming)
{
    for(std::size_t i=0;i<parameterCount;++i) settings.set(static_cast<Param>(i),incoming.values[i]);
    amp.setSettings(settings);pedals.setSettings(settings);
}
void Engine::process(float* left,float* right,int count,bool hostBypassed)
{
    if(left==nullptr || count<=0)return;
    const float targetInput=std::pow(10.0f,settings.get(Param::inputDb)*.05f);
    const float targetOutput=std::pow(10.0f,settings.get(Param::outputDb)*.05f);
    const float targetBypass=settings.on(Param::bypass)?1.0f:0.0f;
    if(!primed){inputGain=targetInput;outputGain=targetOutput;bypassAmount=targetBypass;primed=true;}
    auto safe=[](float value){return std::isfinite(value)?std::clamp(value,-16.0f,16.0f):0.0f;};
    for(int i=0;i<count;++i)
    {
        const Stereo raw{safe(left[i]),safe(right?right[i]:left[i])};
        const Stereo delayed=dryHistory[static_cast<std::size_t>(dryPosition)];
        dryHistory[static_cast<std::size_t>(dryPosition)]=raw;
        dryPosition=(dryPosition+1)%latencySamples;
        inputGain+=smoothCoefficient*(targetInput-inputGain);
        outputGain+=smoothCoefficient*(targetOutput-outputGain);
        bypassAmount+=smoothCoefficient*(targetBypass-bypassAmount);
        if(std::abs(targetBypass-bypassAmount)<1e-5f)bypassAmount=targetBypass;
        Stereo result=pedals.processPost(amp.process(pedals.processPre({raw.l*inputGain,raw.r*inputGain})));
        result.l=safe(result.l*outputGain);result.r=safe(result.r*outputGain);
        const float bypass=hostBypassed?1.0f:bypassAmount;
        left[i]=bypass>=1?delayed.l:result.l+(delayed.l-result.l)*bypass;
        if(right)right[i]=bypass>=1?delayed.r:result.r+(delayed.r-result.r)*bypass;
    }
}
}
