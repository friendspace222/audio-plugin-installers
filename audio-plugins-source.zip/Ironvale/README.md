# Ironvale 0.3.0

An original guitar and bass amplifier with four channels, seven factory cabinet
voicings, a user IR slot, and six stompbox effects. The native interface provides
69 automatable controls across Amp & Cab, Pedalboard, and Stereo Echo pages.

The primary target is an Intel Audio Unit for Logic Pro / GarageBand on macOS Catalina 10.15.7. VST3 and a standalone app are also built. Transfer **Ironvale-0.3.0-Mac-Installer.zip** through Google Drive, unzip it on the Mac, quit your DAW, and double-click the `.pkg`. No compilation or developer tools are needed. The DMG contains the same installer.

Version 0.3 adds five independently voiced guitar amp families, four designed speaker families, and an optional CC0 measured Vintage 30/SM57 4x12 response. Try the new presets **21–30**. The amp selector offers **American Glass**, **British Stack**, **Citrus Drive**, **California Heavy**, and **British Chime**, alongside **Original**. Speaker choice and cabinet size are independent except for the fixed measured 4x12 and imported User IR.

This updates the same installed plugin. Existing 0.1/0.2 sessions select **Original** for both new controls and retain their saved values. Original amp/speaker mode preserves the 0.2 processing; the original twenty factory presets remain at the same indices. Bass continues using its own existing amp and cabinet processing.

## Sound and controls

- Guitar and Bass rigs, each with Clean, Edge, Crunch, and Lead channels.
- Original 4x oversampled saturation, power-stage behavior, sag, tightness,
  presence, resonance, gain/master, and four-band EQ with adjustable low-mid center.
- 1x12 open/sealed, 2x12 open/sealed, 4x12 vintage/modern, and 8x12 stack voicings;
  rig-specific cabinet responses, mic color, early room reflections, and cuts.
- Portable user cabinet IRs stored within sessions and `.ironvale` presets.
- Compressor, overdrive, bass dirt, stereo chorus, phaser, and stereo delay,
  with six persistent footswitches and selectable modulation placement.
- Digital, tape, and ping-pong echoes; independent left/right times or tempo
  divisions; straight, dotted, and triplet rhythms; feedback, mix, cuts, ducking,
  tap tempo, and spillover. Thirty starting presets, including ten new amp/speaker pairings.

## Status

This is an original development plugin. The amplifiers and four designed speaker families are original approximations, not captures of branded products. The optional measured speaker choice is Jester Dyne’s Vintage 30/SM57 capture of a modified Behringer 4x12, redistributed under CC0; it is not a Mesa or Orange cabinet capture. See `docs/AMP-VOICES-0.3.txt` and `docs/IRs/README.txt` for sources and limitations. See the installer's `BUILD-VALIDATION.txt` for the exact native checks. Catalina/Logic/GarageBand runtime and real-instrument listening remain distinct acceptance steps. No claim of matching a particular commercial amp or outperforming commercial plugins is made.

The free installer is unsigned and unnotarized. Catalina may require System Preferences → Security & Privacy → General → Open Anyway for this trusted package. Rebuilding from source is optional.

Read `docs/USER-GUIDE.md`, `docs/VALIDATION.md`, and `docs/BUILD.md`. The original
code is MIT; the default combined JUCE/VST3 binary uses GPLv3. The packaging script
provides complete corresponding source beside the installer. See
`THIRD_PARTY_NOTICES.md`.
