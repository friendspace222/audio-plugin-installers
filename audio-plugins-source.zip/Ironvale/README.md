# Ironvale 0.1.0

An original guitar and bass amplifier with four channels, seven factory cabinet
voicings, a user IR slot, and six stompbox effects. The native interface provides
67 automatable controls across Amp & Cab, Pedalboard, and Stereo Echo pages.

The primary target is an Intel Audio Unit for Logic Pro / GarageBand on macOS
Catalina 10.15.7. VST3 and a standalone app are also built. The complete Mac Build
Kit includes pinned JUCE 7.0.12 and CMake 3.31.8. Transfer the ZIP through Google
Drive and follow `START-HERE-MAC.txt` to create the installer on your Mac.

## Sound and controls

- Guitar and Bass rigs, each with Clean, Edge, Crunch, and Lead channels.
- Original 4x oversampled saturation, power-stage behavior, sag, tightness,
  presence, resonance, gain/master, and four-band EQ with adjustable low-mid center.
- 1x12 open/sealed, 2x12 open/sealed, 4x12 vintage/modern, and 8x12 stack voicings;
  rig-specific cabinet responses, mic color, early room reflections, and cuts.
- Portable user cabinet IRs stored within sessions and `.ironvale` presets.
- Compressor, overdrive, bass dirt, stereo chorus, phaser, and stereo delay,
  with six persistent footswitches and selectable modulation placement.
- Digital, tape, and ping-pong echoes; independent left/right times or tempo
  divisions; straight, dotted, and triplet rhythms; feedback, mix, cuts, ducking,
  tap tempo, and spillover. Twenty starting presets.

## Status

This is a working development preview with Windows test evidence, source code,
synthetic listening demonstrations, and Mac build/installer scripts. The actual
Catalina AU, installer, and target-DAW tests require a Mac. Factory amplifiers and
cabinet responses are original mathematical designs; no commercial models or
captured cabinet IRs are included. Sound quality needs real instrument recordings
and listening comparisons before any claim of market-leading performance.

Read `docs/USER-GUIDE.md`, `docs/VALIDATION.md`, and `docs/BUILD.md`. The original
code is MIT; the default combined JUCE/VST3 binary uses GPLv3. The packaging script
provides complete corresponding source beside the installer. See
`THIRD_PARTY_NOTICES.md`.
