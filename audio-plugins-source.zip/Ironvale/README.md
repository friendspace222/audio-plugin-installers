# Ironvale 0.2.0

An original guitar and bass amplifier with four channels, seven factory cabinet
voicings, a user IR slot, and six stompbox effects. The native interface provides
67 automatable controls across Amp & Cab, Pedalboard, and Stereo Echo pages.

The primary target is an Intel Audio Unit for Logic Pro / GarageBand on macOS Catalina 10.15.7. VST3 and a standalone app are also built. Transfer **Ironvale-0.2.0-Mac-Installer.zip** through Google Drive, unzip it on the Mac, quit your DAW, and double-click the `.pkg`. No compilation or developer tools are needed. The DMG contains the same installer.

Try **Copper Crunch** for thick British-inspired drive, **Modern Steel** or **Low Tuned Atlas** for metal, and **Bass / 4x12 Punch** or **Bass / 8x12 Monument** for bass. Load a revised factory preset once when updating: saved sessions retain their old controls, while the changed engine affects their sound.

## Sound and controls

- Guitar and Bass rigs, each with Clean, Edge, Crunch, and Lead channels.
- Original 4x oversampled saturation, power-stage behavior, sag, tightness,
  presence, resonance, gain/master, and four-band EQ with adjustable low-mid center.
- 1x12 open/sealed, 2x12 open/sealed, 4x12 vintage/modern, and 8x12 stack voicings;
  rig-specific cabinet responses, mic color, early room reflections, and cuts.
- Portable user cabinet IRs stored within sessions and `.ironvale` presets.
- Compressor, overdrive, bass dirt, stereo chorus, phaser, and stereo delay,
  with six persistent footswitches and selectable modulation placement.
- Digital, tape, and ping-pong echoes; independent left/right times or tempo
  divisions; straight, dotted, and triplet rhythms; feedback, mix, cuts, ducking,
  tap tempo, and spillover. Twenty starting presets.

## Status

This is an original development plugin. Factory amplifiers and cabinets are mathematical designs, not measured commercial captures. See the installer's `BUILD-VALIDATION.txt` for the exact native checks. Catalina/Logic/GarageBand runtime and real-instrument listening remain distinct acceptance steps. No claim of matching a particular commercial amp or outperforming commercial plugins is made.

The free installer is unsigned and unnotarized. Catalina may require System Preferences → Security & Privacy → General → Open Anyway for this trusted package. Rebuilding from source is optional.

Read `docs/USER-GUIDE.md`, `docs/VALIDATION.md`, and `docs/BUILD.md`. The original
code is MIT; the default combined JUCE/VST3 binary uses GPLv3. The packaging script
provides complete corresponding source beside the installer. See
`THIRD_PARTY_NOTICES.md`.
