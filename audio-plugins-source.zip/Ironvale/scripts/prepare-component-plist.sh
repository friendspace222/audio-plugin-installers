#!/bin/bash
# pkgbuild --analyze can produce an empty array, or omit relocation flags.
# Print the number of top-level components after disabling relocation on each.
set -euo pipefail
plist="${1:?Usage: prepare-component-plist.sh COMPONENT_PLIST [PLISTBUDDY]}"
buddy="${2:-/usr/libexec/PlistBuddy}"
fail() { echo "ERROR: $*" >&2; exit 1; }
[[ -f "$plist" ]] || fail "Component property list is missing: $plist"
description="$("$buddy" -c Print "$plist")" || fail "Cannot read component property list: $plist"
case "$description" in
    'Array {'*) ;;
    *) fail "Expected an array in component property list: $plist" ;;
esac

fix_entries() {
    local prefix="$1" index=0 entry
    while "$buddy" -c "Print $prefix:$index" "$plist" >/dev/null 2>&1; do
        entry="$prefix:$index"
        "$buddy" -c "Print $entry:RootRelativeBundlePath" "$plist" >/dev/null 2>&1 ||
            fail "Missing RootRelativeBundlePath in component $entry"
        if "$buddy" -c "Print $entry:BundleIsRelocatable" "$plist" >/dev/null 2>&1; then
            "$buddy" -c "Set $entry:BundleIsRelocatable false" "$plist"
        else
            "$buddy" -c "Add $entry:BundleIsRelocatable bool false" "$plist"
        fi
        if "$buddy" -c "Print $entry:ChildBundles" "$plist" >/dev/null 2>&1; then
            fix_entries "$entry:ChildBundles"
        fi
        index=$((index + 1))
    done
    if [[ -z "$prefix" ]]; then printf '%s\n' "$index"; fi
}
fix_entries ''
