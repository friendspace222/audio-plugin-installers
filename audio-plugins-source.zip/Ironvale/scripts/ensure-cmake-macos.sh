#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
[[ "$(uname -s)" == Darwin ]] || { echo "CMake bootstrap requires macOS." >&2; exit 1; }
export PATH="/Applications/CMake.app/Contents/bin:$PATH"
if command -v cmake >/dev/null 2>&1; then
    if installed="$(cmake --version 2>/dev/null | head -1 | awk '{print $3}')" &&
       [[ "$installed" =~ ^[0-9]+\.[0-9]+ ]] && awk -v version="$installed" 'BEGIN {split(version,a,".");exit !(a[1]>3 || (a[1]==3 && a[2]>=22))}'; then
        dirname "$(command -v cmake)"
        exit 0
    fi
fi
version=3.31.8
filename="cmake-$version-macos-universal.tar.gz"
expected=d1449f969c54d5c00886d5b643340d493dfb3c81cb39ee29b35453395c11ebf7
local_tools="$project_dir/.tools"
bin_dir="$local_tools/cmake-$version-macos-universal/CMake.app/Contents/bin"
if [[ ! -x "$bin_dir/cmake" ]]; then
    mkdir -p "$local_tools"
    archive="$project_dir/tools/$filename"
    if [[ ! -f "$archive" ]]; then
        archive="$local_tools/$filename"
        echo "Downloading official CMake $version into this project (no system installation)..." >&2
        curl --fail --location --proto '=https' --tlsv1.2 --retry 3 \
            "https://github.com/Kitware/CMake/releases/download/v$version/$filename" -o "$archive.part"
        actual="$(shasum -a 256 "$archive.part" | awk '{print $1}')"
        [[ "$actual" == "$expected" ]] || { echo "CMake checksum mismatch; stopped." >&2; exit 1; }
        mv "$archive.part" "$archive"
    fi
    actual="$(shasum -a 256 "$archive" | awk '{print $1}')"
    [[ "$actual" == "$expected" ]] || { echo "Bundled CMake checksum mismatch; stopped." >&2; exit 1; }
    echo "Preparing bundled CMake $version..." >&2
    tar -xzf "$archive" -C "$local_tools"
fi
"$bin_dir/cmake" --version >/dev/null
echo "$bin_dir"
