#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
build_dir="${1:?Usage: package-source.sh BUILD_DIR OUTPUT_DIRECTORY}"
destination="${2:?Supply output directory}"
version="$(sed -n 's/^version=//p' "$build_dir/ironvale-build-info.txt")"
[[ "$version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "Invalid build metadata" >&2; exit 1; }
juce_path="$(sed -n 's/^IRONVALE_JUCE_PATH:PATH=//p' "$build_dir/CMakeCache.txt")"
if [[ -z "$juce_path" ]]; then juce_path="$build_dir/_deps/juce-src"; fi
[[ -f "$juce_path/LICENSE.md" ]] || { echo "Full JUCE source required for corresponding-source archive: $juce_path" >&2; exit 1; }
mkdir -p "$destination"
destination="$(cd "$destination" && pwd)"
scratch="$(mktemp -d "$destination/.ironvale-source.XXXXXX")"
cleanup() { case "$scratch" in "$destination"/.ironvale-source.*) rm -rf -- "$scratch" ;; esac; }
trap cleanup EXIT
source_root="$scratch/Ironvale-$version-Source"
mkdir -p "$source_root/vendor/JUCE"
for entry in CMakeLists.txt Build-and-Package.command Make-Installer.command START-HERE-MAC.txt Source tests scripts docs .github LICENSE THIRD_PARTY_NOTICES.md README.md; do
    if [[ -e "$project_dir/$entry" ]]; then cp -R "$project_dir/$entry" "$source_root/"; fi
done
cp "$build_dir/ironvale-build-info.txt" "$source_root/"
(cd "$juce_path" && tar --exclude=.git -cf - .) | (cd "$source_root/vendor/JUCE" && tar -xf -)
cat > "$source_root/BUILD-OFFLINE.txt" <<'EOF'
This archive includes Ironvale and the exact JUCE source tree used in this build.
Configure with -DIRONVALE_JUCE_PATH=/absolute/path/to/vendor/JUCE to avoid downloads.
See docs/BUILD.md for platforms, build commands, licensing and validation limits.
The default combined plug-in distribution uses GPLv3; see docs/licenses/GPL-3.0.txt.
EOF
tar -C "$scratch" -czf "$destination/Ironvale-$version-Corresponding-Source.tar.gz" "Ironvale-$version-Source"
