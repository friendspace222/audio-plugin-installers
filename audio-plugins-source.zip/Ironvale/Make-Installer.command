#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")" && pwd)"
if /bin/bash "$project_dir/scripts/package-existing-macos.sh"; then
    echo "Installer created. Future installs use the .pkg or .dmg in the dist folder."
else
    status=$?
    echo "Installer creation stopped (exit $status). Keep this window's error text."
    if [[ -t 0 ]]; then read -r -p "Press Return to close..." unused; fi
    exit "$status"
fi
if [[ -t 0 ]]; then read -r -p "Press Return to close..." unused; fi
