IRONVALE MEASURED CABINET CAPTURE

The "Measured V30 4x12" speaker choice embeds an adaptation of Cookie Monster,
entry 1 in Jester Dyne Productions' Brutal Pack 1.0. The original unchanged WAV
is included here as Jester-1-Cookie-Monster-original.wav.

Creator: Jester Dyne / Bastian Karschewski, Jester Dyne Productions.
Published source: https://www.jester-dyne-productions.com/brutal-ir-pack/
Original download:
https://www.jester-dyne-productions.com/content/files/2023/04/JestersBrutalPack_1.0.zip

The author's handbook identifies this capture as a Celestion Vintage 30 speaker
with a Shure SM57 in a modified, oversized Behringer BG412S enclosure. It was
recorded in a semi-live room. It is NOT a capture of a Mesa or Orange cabinet.
The manufacturer names identify the original recorded hardware; no affiliation,
approval, or endorsement is implied.

LICENSE AND PROVENANCE

The original download's "Jesters Brutal IR Pack Handbook.pdf", page 2, explicitly
dedicates this pack under CC0. This is the source of redistribution permission,
not merely the website's statement that commercial musical use is free.
The CC0 1.0 text is included as CC0-1.0.txt and is also available at:
https://creativecommons.org/publicdomain/zero/1.0/legalcode.txt

Original ZIP SHA-256:
299dc053f01ebd1e980459adc48f9c6b8a8c7af91917b4f946512eefdbb311ea
Original handbook SHA-256:
265e887fc747a154916bf56408e9c4a371c9d9036aaf1b22997ad4d161cd079e
Original 48 kHz WAV SHA-256:
48b4e8dc8bde8595f8b8153128e99debd981c30b2b7a427e8bf8f3db0a84f49f
Path within original ZIP:
Jesters_Brutal_Pack_1.0/Impulses/48kHz/1_Cookie_Monster.wav
Format: 48,000 Hz, mono, signed 24-bit PCM, 57,420 samples.
License and original assets checked 2026-10-24. No payment was required.

IRONVALE ADAPTATION

scripts/prepare_cabinet_capture.py verifies the original WAV hash and generates
Source/MeasuredCabinetData.h from its first 4,096 exact PCM samples. This is
reproducible using Python's standard library; no network or build-time fetch is
required. 4,096 samples retain 99.9079% of the full WAV's squared-sample energy.
Neither the recorded phase nor its starting offset is replaced. The peak of
the original occurs at sample 7; the source already begins at sample 0.

During prepare(), Ironvale resamples with a windowed-sinc kernel as needed,
truncates to 2,048 samples, and tapers the final quarter
to zero. A single scalar calibrates level using 250/500/1000/2000 Hz. There is
no added speaker EQ, cabinet reflection, or minimum-phase reconstruction in
this builder. At 48 kHz, all samples before the taper equal the original times
one scalar. The ordinary user-controlled cabinet filters, mic colour, and room
controls follow the capture in the plugin and can still colour its sound.

The original long room tail is intentionally not reproduced by the short
cabinet convolver. At 48 kHz, the 2,048-sample / 42.67 ms output retains 99.7856%
of source energy before the taper and approximately 99.7284% after it. At
96 kHz, 2,048 samples span 21.33 ms; approximately 99.5735% precedes the cutoff.
At 192 kHz, 2,048 samples span 10.67 ms; approximately 98.9932% precedes it.
At 384 kHz, 2,048 samples span 5.33 ms; approximately 97.7588% precedes it.
At 44.1 kHz, the 2,048-sample output spans 46.44 ms and approximately 99.8053%
of source energy precedes the cutoff. At unusual host rates below 24 kHz, the
embedded capture's 85.33 ms duration can be shorter than 2,048 output samples;
the available capture is tapered and the rest is zero-padded.
Energy percentages describe the source window, not a guarantee of inaudibility.

The fixed captured enclosure bypasses the synthetic box-size selection. For
other real captures, the existing User IR import remains available. The four
American Ceramic/British Green/British Vintage/Alnico Chime factory families
are original mathematical approximations and must not be described as measured
captures of their branded reference speakers.
