# Build and package Ironvale 0.2.0

The primary target is an **Intel Audio Unit for Logic Pro / GarageBand on macOS
Catalina 10.15.7**. Catalina is macOS, not iOS. The default build also creates VST3
and a standalone app. Windows builds create VST3 and a standalone executable.

Setting a deployment target and inspecting load commands are necessary checks,
but do not prove operation in a particular Catalina DAW. A release still needs
installation, AU validation, audio, automation, preset recall, and listening tests
on the target Mac. No macOS installer is fabricated by the source project.

## Quick Mac build

1. Install Apple Xcode 10.1 or later / its corresponding Command Line Tools.
   JUCE 7.0.12 specifies Xcode 10.1 as its minimum. For a modern build host, use a
   compatible current Xcode with an SDK that still supports a 10.15 deployment
   target. You can build on a newer Intel Mac and copy the installer to Catalina.
2. The **Mac Build Kit ZIP includes CMake 3.31.8 and JUCE 7.0.12**. The launcher
   extracts the checksum-verified CMake tool locally under `.tools/` if no suitable
   CMake is installed. It also recognizes CMake in `/Applications/CMake.app`.
   No separate CMake installation or JUCE download is needed with the complete ZIP.
   A source-only checkout downloads missing CMake/JUCE from their official GitHub repositories.
3. Extract the entire project, then double-click `Build-and-Package.command`.
   If ZIP extraction did not preserve executable permissions, open Terminal in
   the project folder and run `bash Build-and-Package.command`.
4. The script configures and builds, runs DSP and plug-in smoke tests, checks the three Mach-O
   binaries for `x86_64` and minimum OS <= 10.15, then runs Apple's `pkgbuild` and
   `productbuild` to create an actual installer under `dist/`.

For the Google Drive transfer, upload/download the complete ZIP and extract it on
the Mac. `START-HERE-MAC.txt` gives the short path. Catalina can run
[Xcode 12.4](https://developer.apple.com/documentation/Xcode-Release-Notes/xcode-12_4-release-notes);
if `xcode-select --install` does not offer tools for the old OS, obtain that version
or its matching Command Line Tools from Apple's developer downloads. A modern
Xcode version may require a newer macOS even though it can target Catalina.

The script does not install the plug-in or change DAW preferences. The generated
installer requires administrator authorization when you choose to run it. It
offers these destinations:

| Selection | Destination |
| --- | --- |
| Audio Unit (selected) | `/Library/Audio/Plug-Ins/Components/Ironvale.component` |
| VST3 (selected) | `/Library/Audio/Plug-Ins/VST3/Ironvale.vst3` |
| Standalone (optional, unselected) | `/Applications/Ironvale.app` |
| Documentation / licenses | `/Library/Application Support/Ironvale/` |

Close your DAW before installing. Relaunch it afterward; in Logic, use Plug-in
Manager to validate Ironvale, then insert **Audio Units > Ironvale Audio >
Ironvale**. GarageBand discovers Audio Units on launch; enable Audio Units in
its audio preferences if necessary. After installing, an independent AU check is:

```sh
auval -v aufx Irvl IrvA
```

If a build directory was configured with a different generator/toolchain, use a
fresh directory. Existing named installers are not overwritten by the script;
move a previous installer aside before rebuilding. No build script deletes or
overwrites an installed plug-in.

## Manual configuration

Run these from the project root:

```sh
cmake -S . -B build/macos-x86_64 -G "Unix Makefiles" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_OSX_ARCHITECTURES=x86_64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.15
cmake --build build/macos-x86_64 --config Release --parallel 4
ctest --test-dir build/macos-x86_64 -C Release --output-on-failure
bash scripts/verify-macos.sh build/macos-x86_64 x86_64 10.15
bash scripts/package-macos.sh build/macos-x86_64 x86_64 10.15
```

`IRONVALE_JOBS=2 bash Build-and-Package.command` reduces compile parallelism
for a low-memory Mac. All generated binaries live under
`build/macos-x86_64/Ironvale_artefacts/Release/`.

An additional modern universal build is supported with a minimum of macOS 11:

```sh
IRONVALE_ARCHITECTURES='x86_64;arm64' IRONVALE_MIN_MACOS=11.0 \
  bash Build-and-Package.command
```

This deliberately produces a separate package. Keep the **Intel / 10.15 build**
for Catalina. Building or running Intel tests on an Apple Silicon host may require
Apple's Rosetta; prefer an Intel host for the Catalina package.

## Offline DSP checks and local JUCE

DSP tests use only the C++17 standard library and do not download JUCE:

```sh
cmake -S . -B build/dsp -DIRONVALE_BUILD_PLUGIN=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build/dsp --config Release --parallel 4
ctest --test-dir build/dsp -C Release --output-on-failure
```

For a full offline build, the Mac Build Kit automatically detects `vendor/JUCE`.
For another local JUCE 7.0.12 checkout, configure with
`-DIRONVALE_JUCE_PATH=/absolute/path/to/JUCE`. The corresponding-source
archive created during packaging contains this at `vendor/JUCE`. By default,
FetchContent retrieves commit `4f43011b96eb0636104cb3e433894cda98243626`; it never
tracks a moving JUCE branch. Browser, curl, and VST2 replacement are disabled.

## Signing and notarization

Without developer identities, the package is named
`Ironvale-0.2.0-macOS-Intel-Unsigned.pkg`. Its plug-in bundles are ad-hoc signed;
the installer is not signed or notarized, and downloaded copies may be blocked
by Gatekeeper. Do not present this artifact as a notarized release.

For a properly signed distribution, provision your own Developer ID certificates
in the Mac's Keychain and set these environment variables before packaging:

```sh
export DEVELOPER_ID_APPLICATION='Developer ID Application: YOUR NAME (TEAMID)'
export DEVELOPER_ID_INSTALLER='Developer ID Installer: YOUR NAME (TEAMID)'
export NOTARY_KEYCHAIN_PROFILE='your-existing-notarytool-profile'
bash scripts/package-macos.sh build/macos-x86_64 x86_64 10.15
```

The first two variables enable hardened runtime code signing and installer
signing. The optional third submits the package to Apple's notarization service,
waits for success, and staples/validates the ticket before labeling the result
`Notarized`. Store credentials with `xcrun notarytool store-credentials` yourself;
never put certificates, passwords, or Apple API keys in this source tree. The
provided CI workflow intentionally creates unsigned artifacts without secrets.

## Windows

Use Visual Studio 2022 with Desktop Development with C++, CMake 3.22+, and Git:

```powershell
cmake -S . -B build/windows -G "Visual Studio 17 2022" -A x64
cmake --build build/windows --config Release --parallel 4
ctest --test-dir build/windows -C Release --output-on-failure
```

MSVC uses its static runtime. An LLVM-MinGW toolchain can instead use Ninja and
`-DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++`; put the toolchain and Ninja
on PATH first. MinGW builds request static runtime linking. This alternate
toolchain should be independently checked in the target Windows DAW.

Copy the entire `Ironvale.vst3` bundle from `build/windows/Ironvale_artefacts/Release/VST3/`
to `%CommonProgramFiles%\VST3` to install in compatible Windows hosts. Windows
artifacts cannot be installed on macOS and do not establish Audio Unit compatibility.

## CI and release verification

`.github/workflows/build.yml` is manually triggered with `workflow_dispatch`.
On an Intel macOS 15 runner it builds, runs DSP and plug-in smoke tests, inspects deployment metadata,
packages, and validates AU using a temporary per-user installation that refuses
to overwrite any existing bundle. It uploads real `.pkg`, checksums, and complete
corresponding source only after the steps succeed. A separate Windows 2022 job
builds with MSVC and runs the same tests. The workflow has not been dispatched by
providing these files. The project must first be in a repository you control.

Before releasing, verify the package on a clean Catalina 10.15.7 Intel Mac with
the user's actual Logic/GarageBand version, including 44.1/48/96 kHz, mono/stereo,
tempo changes, transport changes, bypass/tails, automation and project reopening.
Check the unsigned/signed/notarized status with `pkgutil --check-signature` and
test installation and removal of your own test copy. A newer CI runner's `auval`
success cannot replace testing on Catalina.

The default open-source binary is governed by JUCE's GPLv3 option, with its
bundled VST3 SDK under GPLv3. Distribute the generated complete corresponding-source
archive and notices alongside binaries. See `THIRD_PARTY_NOTICES.md` for details;
the MIT license on original Ironvale code does not make the combined binary MIT.

References: [JUCE 7.0.12 build requirements](https://github.com/juce-framework/JUCE/blob/7.0.12/README.md),
[JUCE CMake API](https://github.com/juce-framework/JUCE/blob/7.0.12/docs/CMake%20API.md),
[GitHub-hosted runner labels](https://docs.github.com/en/actions/reference/runners/github-hosted-runners),
[Apple notarization](https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution).
