# Playing through Ironvale

Insert Ironvale on an audio track receiving your guitar or bass. Use your audio
interface's instrument input, keep its input meter below clipping, and monitor
through the DAW. Try a 64- or 128-frame audio buffer if the Mac/interface can run
it reliably. Ironvale reports 32 samples of internal processing latency (about
0.67 ms at 48 kHz); interface and host buffering add their own latency.

Start with **Glasshouse Clean** for guitar or **Bass / Clear Foundation** for bass.
Factory presets are starting points; pickups, playing level, tuning, and interface
gain materially change distortion. Reduce Output if the output meter shows CLIP.
There is emergency finite-value bounding, but no transparent output limiter.

## Amp & Cab

Guitar/Bass selects the circuit voicing. Clean, Edge, Crunch, and Lead move from
low distortion through progressively heavier saturation. They share the visible
settings; selecting another channel does not recall a separate bank of knobs.
Save a preset for each complete rig you want to recall.

Gain drives the preamp; Master changes power-stage drive and level. Bass, Low Mid,
High Mid, and Treble provide up to 15 dB boost/cut. Mid Frequency moves the low-mid
center. Presence shapes upper-frequency bite; Resonance emphasizes low-end body;
Tight reduces low-frequency congestion before distortion; Sag adds level-dependent
power-stage compression. The amp, cabinet, and gate each have their own on/off control.

Cabinets are 1x12 Open, 1x12 Sealed, 2x12 Open, 2x12 Sealed, 4x12 Vintage,
4x12 Modern, and 8x12 Stack. Guitar and Bass use different responses for each.
These are original synthetic cabinet voicings, not measured commercial cabinets.
The requested 8x12 is included. Cabinet size alone does not guarantee more bass;
Resonance, EQ, cabinet cuts, and the instrument all affect the result.

Mic changes brightness/color; Room adds short stereo early reflections. Neither
is a literal movable microphone model or a full reverb. Cabinet Low/High Cut shape
the final cabinet output, including user IRs. Amp bypass retains pedals/cabinet;
Cab bypass retains the amp/pedals. Global bypass preserves the original input with
the same 32-sample delay, so host delay compensation remains correct.

The gate has threshold and release controls. Raise its threshold to suppress
high-gain idle noise; lower it if gentle notes disappear. It does not repair a
clipped input or electrical noise recorded with the note.

## Pedalboard

The six colored stomp switches stay visible on all three pages. Click one to
enable/disable that pedal. A disabled pedal's controls remain available for setup.

| Pedal | Controls and purpose |
| --- | --- |
| Compressor | Threshold, ratio, attack, release, makeup, and parallel mix; linked stereo detector and gain-reduction meter. |
| Overdrive | Drive, tone, and level; from a light push to heavy saturation, useful before a driven amp. |
| Bass Dirt | Amount, blend, and tone; preserves the low band while distorting higher frequencies. Operates in Bass mode. |
| Chorus | Rate, depth, and wet mix; stereo modulation. |
| Phaser | Rate, depth, feedback, and mix; six all-pass stages per channel. |
| Stereo Echo | Digital, tape, or ping-pong delay, with the controls below. |

Routing is Input → Gate → Compressor → optional preamp Chorus/Phaser → Overdrive
→ Bass Dirt → Amp → Cabinet → optional loop Chorus/Phaser → Echo → Output.
The modulation position selector moves both Chorus and Phaser before the amp or
after the cabinet. A short fade accompanies this switch. Pedals have a fixed order;
dragging to reorder them and external sidechains are not implemented.

## Stereo Echo

Sync follows the host tempo when provided. Otherwise the manual BPM or Tap sets
tempo. If the host supplies BPM, Tap changes only the stored fallback tempo.
Choose independent left/right note values from 1/64 through two whole notes, then
Straight, Dotted, or Triplet for each side. At 120 BPM an eighth is 250 ms, a dotted
eighth is 375 ms, and an eighth-note triplet is approximately 166.7 ms.

With Sync off, each side uses its millisecond knob. The engine's physical maximum
is 8 seconds per side; longer synced durations are capped. Feedback ranges from
0–95%; Mix blends delay with dry signal. Low/High Cut filter the echoes and Ducking
turns them down while you play. Digital is clear, Tape adds coloration/modulation,
and Ping Pong crosses feedback between sides. A stereo output makes the spread
audible; a mono insert folds both channels together.

With Spillover on, disabling Echo stops new input to it while its existing tail
decays. With Spillover off the wet output fades away. Clear resets effect history
and can produce a deliberate discontinuity; use it to stop an unwanted tail.

## User cabinet IRs and presets

Load IR accepts mono or stereo audio supported by JUCE (WAV/AIFF are recommended).
Stereo is averaged to mono. The loader rejects silence and nonfinite samples,
trims leading near-silence, resamples for the host, retains at most 2,048 samples
per channel, and tapers the last 64 samples. The maximum retained duration is
about 42.7 ms at 48 kHz. This slot is for cabinet impulses, not long room reverbs.
Responses with a sum of absolute weights above 2 are attenuated to that limit,
so imported IRs may be quieter than in a loader with different normalization.

The original loaded samples (up to 131,072 source samples) and source rate are
embedded in the host state and saved `.ironvale` file. Reopening a project on
another computer does not need the original IR file. The prepared response is
rebuilt when sample rate changes. Factory presets retain the loaded user IR but
choose their specified factory cabinet. User IR with nothing loaded falls back
to the current rig's 8x12 Stack. A failed import retains the previously loaded sound
and reports the failure in the interface.

The preset menu has 20 original rigs. Save/Load stores all controls and any loaded
IR. Host automation covers all 67 audio controls; save/load/IR file picking and
Clear are interface actions. Double-click a knob to return it to its default,
or type into its value box. The editor is resizable from 80% to 140%.

## Design references and limits

The feature brief considered the channel/cabinet/pedal workflow described by
[Neural DSP](https://neuraldsp.com/plugins/archetype-misha-mansoor) and
[IK Multimedia](https://ikmultimedia.com/products/amplitube5), and the reasons for
oversampling nonlinear audio described by
[FabFilter](https://www.fabfilter.com/help/saturn/using/inputoutput).
These are feature references, not copied algorithms or claims of equivalent sound.

This version has no commercial amp captures, neural models, tuner, MIDI learn,
drag-and-drop pedal reordering, external sidechain, or multi-microphone IR mixer.
Tideglass is the separate companion reverb/delay plugin and can be inserted after
Ironvale if you want its full reverb section. Native Catalina/Logic/GarageBand
runtime validation and listening with recorded instruments remain necessary.
