# Ironvale 0.1.0 — validation record

Validated on Windows on 2026-10-24. This record distinguishes completed checks
from the Mac work still required. The deliverable is a Mac source/build kit;
the Windows binary used for testing is not included as a Mac plugin.

## Completed

Release build: Clang 23.1.4 / LLVM-MinGW, CMake 4.4.4, pinned JUCE 7.0.12.
VST3, standalone, DSP tests, and plugin integration executable compiled and linked.
Final application sources compile without warnings under the selected warning
flags. JUCE 7's bundled code emits known MinGW DirectWrite/VST3 SDK warnings;
upstream source was not modified to hide them.

All four CTest suites passed, with zero failures:

| Suite | Evidence |
| --- | --- |
| Amplifier/cabinets | 1,433 assertions: 32-sample latency at 44.1/48/96/192 kHz; all rig/channel/cab combinations; distinct cabinet responses; dense and offset FFT convolution compared with a direct reference; extreme-gain stability; invalid input; stereo isolation; allocation-free processing/settings/reset. |
| Pedals | 131 assertions: rhythmic timing, stereo echoes, compression and gate behavior, chorus stereo spread, phaser notches, routing invariance, smooth routing changes, block invariance, 8–192 kHz stress, and no audio-thread allocation. |
| Integrated DSP | 16,393 assertions, mostly samplewise comparisons: exact 32-sample dry bypass, complete-chain block-size invariance, input sanitation and reset. |
| JUCE processor/editor | 295 assertions: 67 parameters, 20 presets, host/fallback tempo, aligned bypass, session recall, malformed state rejection, embedded IR portability after source deletion, host-rate changes and mailbox regression, oversized mono buffers, mono-to-stereo, and native editor creation. |

A separate render run passed 305 integration assertions and exported all three
editor pages plus Bass/8x12. The actual JUCE components generated the PNGs in
`previews/`; they are not design mockups. Visual review found no clipped or
overlapping controls. This covers static rendering, not every keyboard/assistive
technology interaction on every operating system.

The final Windows VST3 passed **pluginval 1.0.4, strictness level 5**, exit 0.
Coverage included 44.1/48/96 kHz, 64–1,024-frame buffers, audio processing,
automation, state, programs, editor opening while processing, and bus layouts.
Its log is `pluginval-windows.txt`. The external Steinberg validator was not
supplied and was skipped. These are VST3 checks, not AU validation.

SHA-256 of the tested Windows VST3 executable inside its bundle:
`1156f4532571746d66d310872bd792e98c2ecf9c652e495c7a2bf4799741cc2f`.

## DSP measurements

At 48 kHz, a 1 kHz sine of 0.1 peak (-20 dBFS) fed the amp with cabinet and drive
pedals off, Master 5/10, flat EQ, Presence/Resonance 50%, and Sag/Tightness zero.
After 250 ms settling, the next 100 ms was analyzed. THD is the root-sum-square
amplitude of harmonics 2–12 divided by the fundamental:

- Clean, Gain 2/10: **0.0894% THD**.
- Lead, Gain 8/10: **39.44% THD**.

This verifies a wide saturation range, not a quality ranking. With Bass Dirt
Amount/Blend 100%, Tone 50%, and the amp/cab/OD bypassed, an 800 Hz sine at 0.2 peak
gave 35.44% THD; a separate 40 Hz test retained a strong fundamental. Dirt's low
band is preserved in the design, but these settings do not imply unity gain.

At intentionally extreme stacked gain/EQ settings the amp-core stress test saw
4.87 peak before plugin output trim. Floating-point headroom is supported;
reduce Output to avoid clipping at your audio device or downstream processor.

Offline full-chain benchmarks on this Windows Intel Core i7-1355U host at
48 kHz / 128 frames achieved approximately 7.5–9.3 times realtime for the five
demo settings. These are median wall-clock throughput results, not CPU meter
readings or dropout guarantees. See `demos/README.txt` for detailed conditions,
settings, and playback level matching. All six demos use synthesized inputs.

## Mac packaging checks and remaining work

Mac shell scripts pass Bash syntax checking and use LF endings. The build-kit
ZIP gives `.command` and `.sh` files executable Unix permissions. CMake 3.31.8's
bundled Intel executable was inspected: its minimum macOS load command is 10.13,
below Catalina. The official archive is SHA-256 verified before extraction.

The default configuration targets Intel x86_64 / macOS 10.15, creates AU, VST3,
and standalone targets, and has actual `pkgbuild`/`productbuild` installer scripts.
The Mac build script runs tests and inspects each produced binary's architecture,
minimum OS, and linked dependencies before packaging. Source archives and notices
are generated alongside the installer. The CI workflow is supplied but was not run.

**Not yet performed:** Mac compilation; actual Catalina 10.15.7 installation;
`auval`; Logic Pro/GarageBand runtime tests; live instrument latency/dropout and
listening tests; Apple Developer ID signing or notarization. These require the
Mac and, for signing, your own Apple credentials. Declaring a deployment target
does not establish runtime compatibility. The kit contains no prebuilt `.pkg`.

The next acceptance step is to build on the Mac, install, run
`auval -v aufx Irvl IrvA`, then verify mono/stereo tracking, all channels/cabinets,
tempo sync, automation, bypass, IR recall and saved-project reopening in the
actual Logic/GarageBand version. Real guitar/bass recordings and controlled
listening comparisons are still needed before any “best in the world” claim.
