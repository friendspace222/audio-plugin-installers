# Ironvale 0.2.0 validation

## Sonic changes

The four-times-oversampled preamp has distinct channel drive/voicing, asymmetric cascaded stages with bounded charge memory and AC coupling, output-driven supply sag, and revised low-frequency drive management. The cabinet responses and bass foundation are revised for body without relying solely on higher output. These are original reduced mathematical models, not measured Marshall, Mesa Boogie, or Orange models.

The amp tests cover 32-sample latency, oversampling/channel/cabinet combinations, convolution against a direct reference, drive range, invalid input, extreme controls, stereo isolation, real-time allocations, and targeted dynamics/body. Separate pedal and integrated suites cover effects, timing, routing, bypass and block invariance. Processor tests cover 67 stable controls, 20 presets, preserved state/filter values, embedded IR portability/resampling, mono/stereo layouts and editor construction. Windows pluginval and native results must refer to this version's binary.

High output levels remain possible with large input/EQ/drive boosts. The emergency finite-value bound is not a transparent output limiter; reduce Output before downstream clipping. Measured sine distortion or synthesized palm-mute spectra are useful regressions, not evidence of matching a commercial amplifier.

## Installer and compatibility checks

The Windows 0.2.0 Release build passed all four CTest suites (amp, pedals, integrated DSP, processor/editor). The amp suite passed 1,467 checks. All 20 factory presets were also probed through the complete engine with a synthesized instrument signal; high-gain output trims were reduced to preserve headroom. See [sonic measurements](SONIC-VALIDATION-0.2.txt) for stimulus details, dynamics/body results and limitations.

The final Windows VST3 also passed pluginval 1.0.4 at strictness level 5, exit 0, seed 6702. The validator identified version 0.2.0 and exercised audio, automation, state, programs, buses and GUI. These are VST3 host checks, separate from the Mac AU validation.

The public build workflow uses a standard Intel Mac runner, Xcode 16.4, pinned JUCE 7.0.12, x86_64 architecture, and a macOS 10.15 deployment target. It runs CTest, verifies architecture/deployment metadata, creates native PKG/DMG files, checks all four package payloads use Catalina-compatible legacy gzip, installs AU/VST3/docs with default choices, reinstalls with the optional standalone app, checks destinations/receipts/signatures/versions, validates the system-installed AU with auval, and verifies the DMG and checksums. The accompanying BUILD-VALIDATION.txt records the exact successful run and source commit. The source archive includes the exact plugin and JUCE source and license notices.

The earlier 0.1.0 build completed these native install/AU checks on macOS 15.7.9 in [run 40103969853](https://github.com/friendspace222/audio-plugin-installers/actions/runs/40103969853). This is historical evidence, not the test record for 0.2.0. The newer build must pass its own checks before delivery.

Package, AU, and VST3 identities are unchanged so normal updates replace the same installed plugin. Tests cover clean/default installation and optional-app reinstall; a 0.1-to-0.2 upgrade on Catalina has not been executed here. The binaries are ad-hoc signed; installers are unsigned and unnotarized.

**Not established:** Catalina 10.15.7 runtime, the user's exact Logic/GarageBand version, low-buffer operation on an older Mac, or superiority to commercial products. No real guitar/bass DI was supplied for controlled listening. Numerical tests and synthesized probes do not establish realism or subjective quality.

Load a revised factory preset when evaluating 0.2.0. Saved projects preserve their knob values, while the changed engine can change their sound. Keep rendered stems and the previous installer for important older sessions.
