# Ironvale 0.3.0 validation

## Amp and speaker changes

Five new original amp-family models add different gain staging, bright response, tone-stack interaction, power feedback, compression and recovery. Four designed speaker families can be combined with seven guitar cabinet geometries. A fifth speaker option uses a licensed CC0 Vintage 30/SM57 capture of a modified Behringer BG412S oversized 4x12; its captured cabinet size is fixed. This is not a measured Mesa or Orange cabinet. The capture is shortened, tapered, resampled and level calibrated. Cabinet mic, room and filter controls still affect it. See AMP-VOICES-0.3.txt, SONIC-VALIDATION-0.3.txt, SPEAKER-VALIDATION-0.3.txt and IRs/README.txt for provenance, measurements and limitations.

These are original reduced amp models and designed speaker approximations, except for the explicitly identified measured cabinet response. Numerical distinction between models does not establish accuracy against commercial hardware. No real guitar/bass DI or matched reference-amp recordings were supplied for controlled listening.

## Local checks

The Windows 0.3.0 Release build passed all six CTest suites: amp, speakers, cabinet routing, pedals, integrated DSP and processor/editor. The amp suite passed 1,609 checks and the speaker suite 942. Coverage includes finite output, extreme controls, allocation-free audio processing, 32-sample latency, convolution reference agreement, stereo isolation, automation, cabinet precedence, state/embedded-IR portability and mono/stereo layouts.

The first 67 controls retain their IDs, order and AU version hints. Two new selectors are appended with version hint 2. The original 20 factory presets remain at the same indices; ten new presets are appended. Missing selectors in older state explicitly restore Original. The Original amp/bass path produced byte-identical output to 0.2 over 393,216 stereo frames spanning channels, rates, effects and automation. This is a regression check, not a guarantee for every possible host session.

The Windows VST3 passed pluginval 1.0.4 at strictness level 5, exit 0, seed 6703; the validator identified version 0.3.0 and exercised audio, automation, state, programs, buses and GUI. Native editor snapshots were also generated for the pages, amp families, User IR, Bass and minimum size. These checks are separate from Mac AU validation.

All 30 factory presets were probed through the complete engine at 48 kHz using a deterministic four-second synthesized pluck/power-chord signal peaking at -12.04 dBFS. The ten new presets peaked between -6.048 and -5.969 dBFS after output calibration. See FULL-PLUGIN-VALIDATION-0.3.txt for settings and results. This is headroom for that stimulus, not a limiter, perceived-loudness match, real DI audition, or proof that hotter input cannot clip downstream.

## Installer and compatibility checks

The public build workflow uses a standard Intel Mac runner, Xcode 16.4, pinned JUCE 7.0.12, x86_64 architecture and a macOS 10.15 deployment target. It runs CTest, verifies architecture/deployment metadata, creates native PKG/DMG files, checks Catalina-compatible legacy gzip payloads, installs AU/VST3/docs with default choices, reinstalls with the optional standalone app, checks destinations/receipts/signatures/versions, validates the system-installed AU with auval, and verifies the DMG and checksums. BUILD-VALIDATION.txt in each finished installer ZIP records that artifact's successful native run and source commit; this source document alone does not attest that a later build passed.

Package, AU and VST3 identities and installation paths remain unchanged so the update replaces the existing plugin. Native checks cover default installation and optional-app reinstall. A 0.2-to-0.3 upgrade inside Catalina has not been executed here. Binaries are ad-hoc signed; installers are unsigned and unnotarized. Corresponding source includes JUCE source/licenses and the original licensed cabinet WAV with its conversion script.

**Not established:** Catalina 10.15.7 runtime, the user's exact Logic/GarageBand version, low-buffer operation on an older Mac, exact commercial amp/speaker matching, or superiority to commercial products. Windows CPU measurements in SONIC-VALIDATION-0.3.txt do not establish older-Mac performance.

Load presets 21-30 or select an AMP VOICE and SPEAKER to evaluate the new sound. Old sessions and presets deliberately retain Original. Keep rendered stems and the previous installer for important sessions.
