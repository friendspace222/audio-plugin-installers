#include "AmpCore.h"
#include <cmath>
#include <iostream>
#include <iomanip>
#include <vector>
#include <ctime>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
double cpuSeconds(){FILETIME created,exited,kernel,user;GetThreadTimes(GetCurrentThread(),&created,&exited,&kernel,&user);ULARGE_INTEGER k{},u{};k.LowPart=kernel.dwLowDateTime;k.HighPart=kernel.dwHighDateTime;u.LowPart=user.dwLowDateTime;u.HighPart=user.dwHighDateTime;return (k.QuadPart+u.QuadPart)*1e-7;}
#else
double cpuSeconds(){return double(std::clock())/CLOCKS_PER_SEC;}
#endif
int main(){using namespace ironvale;std::cout<<std::setprecision(5);double checksum=0;for(int sr:{48000,96000})for(int channel:{0,3}){Settings s;s.set(Param::channel,channel);s.set(Param::cabinet,5);s.set(Param::ampGain,6);AmpCore amp;amp.setSettings(s);amp.prepare(sr);std::vector<float> input(sr*5);for(int n=0;n<(int)input.size();++n)input[n]=.15f*std::sin(n*.035f)+.04f*std::cos(n*.071f);for(int n=0;n<sr/2;++n)amp.process({input[n],input[n]*.9f});double start=cpuSeconds();for(float x:input){auto y=amp.process({x,x*.9f});checksum+=y.l+y.r;}double elapsed=cpuSeconds()-start;std::cout<<sr<<"Hz channel"<<channel<<" CPU seconds="<<elapsed<<" percent_one_core="<<100*elapsed/5<<'\n';}std::cout<<"checksum="<<checksum<<'\n';}
