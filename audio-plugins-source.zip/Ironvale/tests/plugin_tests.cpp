#include "PluginProcessor.h"
#include <cmath>
#include <iostream>
#include <stdexcept>

namespace {
int checks=0;
void check(bool ok,const char* why){++checks;if(!ok)throw std::runtime_error(why);}
void set(IronvaleAudioProcessor& p,const char* id,float value)
{auto* a=p.parameters.getParameter(id);check(a!=nullptr,"Missing parameter");a->setValueNotifyingHost(a->convertTo0to1(value));}
float get(IronvaleAudioProcessor& p,const char* id){return p.parameters.getRawParameterValue(id)->load();}
bool finite(const juce::AudioBuffer<float>& a)
{for(int c=0;c<a.getNumChannels();++c)for(int i=0;i<a.getNumSamples();++i)if(!std::isfinite(a.getSample(c,i)))return false;return true;}
class PlayHead final:public juce::AudioPlayHead
{public:juce::Optional<PositionInfo> getPosition()const override{PositionInfo p;p.setBpm(137);p.setIsPlaying(true);return p;}};
juce::Button* findButton(juce::Component& parent,const juce::String& text)
{for(auto* child:parent.getChildren()){if(auto* b=dynamic_cast<juce::Button*>(child))if(b->getButtonText()==text)return b;if(auto* b=findButton(*child,text))return b;}return nullptr;}
void snapshot(juce::Component& editor,const juce::File& f)
{f.deleteFile();auto out=f.createOutputStream();check(out!=nullptr,"Cannot create PNG");juce::PNGImageFormat png;check(png.writeImageToStream(editor.createComponentSnapshot(editor.getLocalBounds(),true,1),*out),"PNG failed");}
void bareCab(IronvaleAudioProcessor& p)
{set(p,"ampEnabled",0);set(p,"gateEnabled",0);set(p,"cabinet",7);set(p,"cabRoom",0);set(p,"cabMic",0);set(p,"inputDb",0);set(p,"outputDb",0);}
}
int main(int argc,char** argv)
{
    try {
        juce::ScopedJuceInitialiser_GUI initialise;
        IronvaleAudioProcessor p;check(p.getParameters().size()==67,"Expected all 67 controls");check(p.getLatencySamples()==32,"Latency incorrect");
        p.prepareToPlay(48000,256);juce::AudioBuffer<float> a(2,256);juce::MidiBuffer midi;
        PlayHead head;p.setPlayHead(&head);a.clear();p.processBlock(a,midi);
        check(std::abs(p.currentBpm.load()-137)<1e-9&&p.hostTempoActive.load(),"Host tempo not followed");p.setPlayHead(nullptr);set(p,"bpm",93);a.clear();p.processBlock(a,midi);
        check(std::abs(p.currentBpm.load()-93)<1e-9&&!p.hostTempoActive.load(),"Fallback tempo not followed");
        p.releaseResources();p.prepareToPlay(48000,256);a.clear();a.setSample(0,0,.25f);a.setSample(1,0,-.125f);p.processBlockBypassed(a,midi);
        check(std::abs(a.getSample(0,32)-.25f)<1e-8f&&std::abs(a.getSample(1,32)+.125f)<1e-8f&&std::abs(a.getSample(0,0))<1e-8f,"Host bypass not latency aligned");
        set(p,"rig",1);set(p,"dirtAmount",79);set(p,"rhythmR",2);set(p,"cabLowCut",70);juce::MemoryBlock state;p.getStateInformation(state);
        set(p,"rig",0);set(p,"dirtAmount",1);set(p,"cabLowCut",40);p.setStateInformation(state.getData(),(int)state.getSize());
        check(std::abs(get(p,"rig")-1)<1e-7f&&std::abs(get(p,"dirtAmount")-79)<.01f&&std::abs(get(p,"rhythmR")-2)<1e-7f,"Session state recall failed");
        check(std::abs(get(p,"cabLowCut")-70)<.01f,"Older session cabinet filter was replaced by new default");
        const char invalid[]="invalid";p.setStateInformation(invalid,sizeof invalid);check(std::abs(get(p,"dirtAmount")-79)<1e-7f,"Malformed state damaged controls");
        for(int preset=0;preset<p.getNumPrograms();++preset)
        {
            p.loadFactoryPreset(preset);p.requestPanic();double energy=0;
            for(int block=0;block<12;++block){for(int i=0;i<256;++i)for(int c=0;c<2;++c)a.setSample(c,i,.15f*std::sin(static_cast<float>(block*256+i)*.07f));p.processBlock(a,midi);check(finite(a),"Preset produced invalid audio");energy+=a.getRMSLevel(0,0,256);}
            check(energy>.001,"Preset unexpectedly silent");
        }
        // Embedded IR must survive source deletion and host-rate changes before its queued load is consumed.
        const auto temp=juce::File::getSpecialLocation(juce::File::tempDirectory).getNonexistentChildFile("ironvale-test","",false);
        check(temp.createDirectory().wasOk(),"Cannot make test directory");const auto ir=temp.getChildFile("test.wav");
        {auto out=ir.createOutputStream();juce::WavAudioFormat wav;std::unique_ptr<juce::AudioFormatWriter> writer(wav.createWriterFor(out.release(),48000,1,24,{},0));check(writer!=nullptr,"IR writer failed");juce::AudioBuffer<float> impulse(1,256);impulse.clear();impulse.setSample(0,0,.5f);impulse.setSample(0,60,.25f);check(writer->writeFromAudioSampleBuffer(impulse,0,256),"IR write failed");}
        IronvaleAudioProcessor before;before.loadCabinetIR(ir);bareCab(before);before.getStateInformation(state);
        check(before.getCabinetIRName()=="test.wav","IR load failed");check(ir.deleteFile(),"Cannot delete test IR");
        IronvaleAudioProcessor restored;restored.setStateInformation(state.getData(),(int)state.getSize());
        before.prepareToPlay(96000,256);restored.prepareToPlay(96000,256);
        a.clear();a.setSample(0,0,.5f);a.setSample(1,0,.5f);juce::AudioBuffer<float> b(a);before.processBlock(a,midi);restored.processBlock(b,midi);
        float error=0;for(int c=0;c<2;++c)for(int i=0;i<256;++i)error=std::max(error,std::abs(a.getSample(c,i)-b.getSample(c,i)));
        check(error<1e-7f&&a.getMagnitude(0,0,256)>.01f,"Embedded IR recall/rate change failed");check(restored.getCabinetIRName()=="test.wav","Embedded IR name lost");
        // Compare an IR loaded at the destination rate to one loaded before prepareToPlay.
        const auto presetFile=temp.getChildFile("embedded.ironvale");check(before.savePresetToFile(presetFile),"Preset save failed");
        IronvaleAudioProcessor atRate;atRate.prepareToPlay(96000,256);check(atRate.loadPresetFromFile(presetFile),"Preset load failed");
        before.prepareToPlay(96000,256);
        // A live IR load intentionally morphs, whereas a freshly prepared instance starts directly.
        // Consume the mailbox and reset both to their now-current coefficients before comparison.
        a.clear();b.clear();before.processBlock(a,midi);atRate.processBlock(b,midi);
        before.requestPanic();atRate.requestPanic();
        a.clear();a.setSample(0,0,.5f);a.setSample(1,0,.5f);b.makeCopyOf(a);before.processBlock(a,midi);atRate.processBlock(b,midi);
        error=0;for(int c=0;c<2;++c)for(int i=0;i<256;++i)error=std::max(error,std::abs(a.getSample(c,i)-b.getSample(c,i)));
        check(error<1e-6f,"Stale-rate IR mailbox regression");
        temp.deleteRecursively();
        auto layout=p.getBusesLayout();layout.inputBuses.set(0,juce::AudioChannelSet::mono());layout.outputBuses.set(0,juce::AudioChannelSet::mono());
        check(p.setBusesLayout(layout),"Mono layout rejected");p.prepareToPlay(44100,64);juce::AudioBuffer<float> mono(1,777);mono.clear();mono.setSample(0,0,.25f);p.processBlock(mono,midi);check(finite(mono),"Oversized mono block failed");
        layout.outputBuses.set(0,juce::AudioChannelSet::stereo());check(p.setBusesLayout(layout),"Mono-to-stereo rejected");p.prepareToPlay(48000,256);a.clear();a.setSample(0,0,.2f);p.processBlockBypassed(a,midi);check(std::abs(a.getSample(0,32)-a.getSample(1,32))<1e-8f&&std::abs(a.getSample(0,32)-.2f)<1e-8f,"Mono input not duplicated");
        p.loadFactoryPreset(0);std::unique_ptr<juce::AudioProcessorEditor> editor(p.createEditor());check(editor&&editor->getWidth()>=1000,"Native editor failed");
        if(argc>1){const juce::File dir(juce::String::fromUTF8(argv[1]));dir.createDirectory();snapshot(*editor,dir.getChildFile("Ironvale-Amp.png"));auto* pedal=findButton(*editor,"02   PEDALBOARD");check(pedal!=nullptr,"Pedal tab missing");if(pedal->onClick)pedal->onClick();snapshot(*editor,dir.getChildFile("Ironvale-Pedals.png"));auto* echo=findButton(*editor,"03   STEREO ECHO");check(echo!=nullptr,"Echo tab missing");if(echo->onClick)echo->onClick();snapshot(*editor,dir.getChildFile("Ironvale-Echo.png"));}
        editor.reset();p.loadFactoryPreset(17);editor.reset(p.createEditor());if(argc>1)snapshot(*editor,juce::File(juce::String::fromUTF8(argv[1])).getChildFile("Ironvale-Bass.png"));editor.reset();p.releaseResources();std::cout<<"PASS: "<<checks<<" plugin integration checks; 67 controls, 20 presets, state/IR portability, host tempo, latency, mono/stereo and native editor.\n";
    }catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}
}
