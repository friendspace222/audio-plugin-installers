#include "AmpCore.h"
#include <cmath>
#include <complex>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
using namespace ironvale;
constexpr double pi=3.14159265358979323846, sr=48000;
void word(std::ofstream& f,uint32_t x,int n){for(int i=0;i<n;i++)f.put((char)(x>>(8*i)));}
void wav(const std::string& path,const std::vector<float>& signal){std::ofstream f(path,std::ios::binary);f.write("RIFF",4);word(f,36+signal.size()*2,4);f.write("WAVEfmt ",8);word(f,16,4);word(f,1,2);word(f,1,2);word(f,48000,4);word(f,96000,4);word(f,2,2);word(f,16,2);f.write("data",4);word(f,signal.size()*2,4);double energy=0;for(float x:signal)energy+=x*x;double gain=.13/std::sqrt(energy/signal.size());for(float x:signal){const int v=(int)std::round(std::clamp(x*gain,-.99,.99)*32767);word(f,(uint16_t)(int16_t)v,2);}}
double mag(const std::vector<float>& v,double hz){double re=0,im=0;for(size_t n=0;n<v.size();++n){re+=v[n]*std::cos(2*pi*hz*n/sr);im-=v[n]*std::sin(2*pi*hz*n/sr);}return 2*std::hypot(re,im)/v.size();}
double spectralRatio(const std::vector<float>& x,double low,double high){size_t n=1;while(n<x.size())n*=2;std::vector<std::complex<double>> bins(n);for(size_t k=0;k<x.size();++k)bins[k]=x[k];for(size_t i=1,j=0;i<n;++i){size_t bit=n>>1;for(;j&bit;bit>>=1)j^=bit;j^=bit;if(i<j)std::swap(bins[i],bins[j]);}for(size_t len=2;len<=n;len*=2){std::complex<double> step(std::cos(-2*pi/len),std::sin(-2*pi/len));for(size_t base=0;base<n;base+=len){std::complex<double> w(1);for(size_t j=0;j<len/2;++j){auto a=bins[base+j],b=bins[base+j+len/2]*w;bins[base+j]=a+b;bins[base+j+len/2]=a-b;w*=step;}}}double body=0,mid=0;for(size_t k=1;k<n/2;++k){double hz=k*sr/n;if(hz>=low&&hz<=high)body+=std::norm(bins[k]);if(hz>=700&&hz<=3500)mid+=std::norm(bins[k]);}return 10*std::log10(body/mid);}
Settings base(int rig,int channel,int cab){Settings s;s.set(Param::rig,rig);s.set(Param::channel,channel);s.set(Param::cabinet,cab);s.set(Param::ampGain,channel==3?7:6);s.set(Param::ampMaster,5);s.set(Param::presence,50);s.set(Param::resonance,50);s.set(Param::sag,35);s.set(Param::tight,channel==3?80:50);s.set(Param::cabLowCut,rig?25:40);s.set(Param::cabHighCut,8000);s.set(Param::cabMic,35);s.set(Param::cabRoom,0);if(rig){s.set(Param::ampGain,3);s.set(Param::tight,15);s.set(Param::resonance,65);}return s;}
int main(int argc,char** argv){std::string prefix=argc>1?argv[1]:"ironvale-probe";std::cout<<std::setprecision(8);for(int v=0;v<4;++v){const bool bass=v>=2;auto s=base(bass,v==0?2:v==1?3:0,v==0?4:v==1?5:v==2?5:6);std::string name=v==0?"crunch-4x12":v==1?"lead-4x12":v==2?"bass-4x12":"bass-8x12";AmpCore amp;amp.setSettings(s);amp.prepare(sr);std::vector<float> output(192000);uint32_t noise=1234567;double total=0;float peak=0;for(int n=0;n<(int)output.size();++n){double t=(n%19200)/sr;double f=bass?41.203:82.407;noise=noise*1664525u+1013904223u;double click=((noise>>8)/8388608.0-1)*std::exp(-t/.002);double input=.18*(1-std::exp(-t/.0006))*std::exp(-t/(bass?.12:.065))*(std::sin(2*pi*f*t)+.42*std::sin(4*pi*f*t)+.19*std::sin(6*pi*f*t)+.08*std::sin(10*pi*f*t))+.015*click;if(t>.18)input=0;float y=amp.process({(float)input,(float)input}).l;output[n]=y;total+=y*y;peak=std::max(peak,std::abs(y));}std::cout<<name<<" FFT_body_mid_dB="<<spectralRatio(output,bass?25:55,bass?120:200)<<" rms="<<std::sqrt(total/output.size())<<" peak="<<peak<<'\n';wav(prefix+"-"+name+"-rms-matched.wav",output);}
for(int rig=0;rig<2;++rig){auto s=base(rig,0,rig?6:5);s.set(Param::ampEnabled,0);AmpCore amp;amp.setSettings(s);amp.prepare(sr);std::vector<float> ir(8192);for(int n=0;n<(int)ir.size();++n)ir[n]=amp.process({n==0?1.f:0.f,0}).l;double ref=mag(ir,rig?250:700);std::cout<<(rig?"bass8-cab":"guitar4-cab");for(int f:{31,41,60,82,110,140,250,700,2000,6000})std::cout<<" "<<f<<"Hz="<<20*std::log10(mag(ir,f)/ref);std::cout<<'\n';}
}
