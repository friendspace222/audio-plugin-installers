#include "CabinetVoices.h"
#include <cstdio>
#include <vector>

namespace {
int checks = 0, failures = 0;
void check(bool passed, const char* description) {
    ++checks;
    if (!passed) { ++failures; std::fprintf(stderr, "FAIL: %s\n", description); }
}
int lengthFor(double) { return 2048; }
std::vector<float> render(double rate, int cabinet, int voice) {
    std::vector<float> h(static_cast<size_t>(lengthFor(rate)));
    ironvale::cabinetvoices::make(h.data(), static_cast<int>(h.size()), rate, cabinet, voice);
    return h;
}
double db(const std::vector<float>& h, double rate, double hz) {
    std::complex<double> sum{};
    for (size_t n = 0; n < h.size(); ++n) {
        const double angle = -2 * ironvale::cabinetvoices::detail::pi * hz * n / rate;
        sum += static_cast<double>(h[n]) * std::complex<double>(std::cos(angle), std::sin(angle));
    }
    return 20 * std::log10(std::max(1.0e-12, std::abs(sum)));
}
}
int main() {
    for (double rate : {8000.0, 22050.0, 44100.0, 48000.0, 96000.0, 192000.0, 384000.0}) {
        for (int voice = 1; voice <= 5; ++voice) for (int cabinet = 0; cabinet < 7; ++cabinet) {
            auto h = render(rate, cabinet, voice);
            bool finite = true; double energy = 0;
            for (float value : h) { finite &= std::isfinite(value); energy += value * value; }
            check(finite && energy > 1e-5 && energy < 8, "IR finite and bounded at all supported rates/boxes");
            check(h.back() == 0, "truncated IR ends at zero");
            double bandEnergy = 0;
            for (double hz : {250.0, 500.0, 1000.0, 2000.0}) bandEnergy += std::pow(10.0, db(h,rate,hz)/10.0);
            check(std::abs(std::sqrt(bandEnergy / 4) - 0.80) < 1e-5, "speaker level calibration stays common");
            if (rate >= 44100) check(db(h,rate,10000) < db(h,rate,2000) - 10, "guitar speaker rolls off ultrasonic/fizz region");
        }
    }
    std::array<std::vector<float>, 5> families;
    for (int voice = 1; voice <= 5; ++voice) {
        auto& h = families[static_cast<size_t>(voice - 1)]; h = render(48000,4,voice);
        std::printf("Voice %d, dB @100/250/700/1500/3000/5000/10000 Hz:", voice);
        for (double hz : {100.,250.,700.,1500.,3000.,5000.,10000.}) std::printf(" %.2f",db(h,48000,hz));
        std::puts("");
        for (double rate : {44100.0, 96000.0, 192000.0}) {
            auto other = render(rate,4,voice); double deviation = 0;
            for (double hz : {100.0,200.0,700.0,1500.0,3000.0,5000.0})
                deviation = std::max(deviation,std::abs(db(h,48000,hz) - db(other,rate,hz)));
            std::printf("Voice %d @%.0f max curve delta: %.3f dB\n",voice,rate,deviation);
            check(deviation < 3.0, "speaker response stays consistent across musical sample rates");
        }
    }
    for (int a = 0; a < 5; ++a) for (int b = a+1; b < 5; ++b) {
        double differences = 0;
        for (double hz : {100.,250.,700.,1500.,2300.,3000.,4000.,5000.}) {
            const double difference = db(families[a],48000,hz)-db(families[b],48000,hz);
            differences += difference * difference;
        }
        const double rms = std::sqrt(differences/8);
        std::printf("Voices %d vs %d spectral RMS difference %.3f dB\n",a+1,b+1,rms);
        check(rms > 1.4,"independent speaker families measurably differ at equal level");
    }
    for (int voice=1; voice<=4; ++voice) {
        const auto small=render(48000,0,voice), large=render(48000,5,voice);
        check(db(large,48000,90)-db(small,48000,90)>2.0,"closed large enclosure retains more low body than open 1x12");
    }
    check(render(48000,0,5)==render(48000,6,5), "measured capture ignores synthetic enclosure selector");
    auto measured = render(48000,4,5);
    // The body of the measured capture must remain the original samples times
    // ONE scalar. This catches accidental synthetic EQ/reflections or rephasing.
    const double ratio = measured[7] / (ironvale::cabinetvoices::detail::measuredPcm[7] / 8388608.0);
    double error = 0;
    for (int n=0;n<static_cast<int>(measured.size())*3/4;++n)
        error=std::max(error,std::abs(measured[n] - ratio*ironvale::cabinetvoices::detail::measuredPcm[n]/8388608.0));
    check(error<1e-7,"48 kHz measured capture preserves original phase and frequency contour before tail taper");
    float guards[3] = {7,7,7};
    ironvale::cabinetvoices::make(guards+1,0,48000,4,5);
    check(guards[0]==7&&guards[1]==7&&guards[2]==7,"empty IR request does not write");
    std::printf("Speaker validation: %d checks, %d failures\n",checks,failures);
    return failures ? 1 : 0;
}
