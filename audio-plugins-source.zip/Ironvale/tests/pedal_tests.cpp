#include "../Source/Pedals.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <new>
#include <string>
#include <vector>

using namespace ironvale;
namespace allocationAudit { bool enabled=false; std::size_t count=0; }
void* operator new(std::size_t n)
{
    if(allocationAudit::enabled)++allocationAudit::count;
    if(void* p=std::malloc(n==0?1:n))return p;
    throw std::bad_alloc();
}
void* operator new[](std::size_t n) { return ::operator new(n); }
void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete(void* p,std::size_t) noexcept { std::free(p); }
void operator delete[](void* p,std::size_t) noexcept { std::free(p); }
namespace
{
constexpr double pi=3.14159265358979323846;
int passed=0, failed=0;
void check(bool ok,const std::string& name)
{
    if(ok)++passed; else { ++failed; std::cerr<<"FAIL: "<<name<<"\n"; }
}
Settings drySettings()
{
    Settings s;
    for(auto p:{Param::gateEnabled,Param::compEnabled,Param::chorusEnabled,Param::phaserEnabled,Param::delayEnabled})s.set(p,0);
    s.set(Param::compMakeup,0);
    return s;
}
Stereo process(Pedals& p,Stereo x) { return p.processPost(p.processPre(x)); }
void settle(Pedals& p,int count,Stereo x={}) { for(int i=0;i<count;++i)process(p,x); }
std::vector<Stereo> impulse(Settings s,int count,double sampleRate=48000)
{
    Pedals p;p.prepare(sampleRate);p.setSettings(s);
    std::vector<Stereo> output(static_cast<std::size_t>(count));
    for(int i=0;i<count;++i)output[static_cast<std::size_t>(i)]=process(p,i==0?Stereo{1,1}:Stereo{});
    return output;
}
double energy(const std::vector<Stereo>& v,int start,int end)
{
    double sum=0;for(int i=start;i<end;++i)sum+=v[static_cast<std::size_t>(i)].l*v[static_cast<std::size_t>(i)].l+v[static_cast<std::size_t>(i)].r*v[static_cast<std::size_t>(i)].r;
    return sum;
}
void timings()
{
    const double beats[8]={.0625,.125,.25,.5,1,2,4,8};
    const double factors[3]={1,1.5,2.0/3};
    for(int note=0;note<8;++note)for(int rhythm=0;rhythm<3;++rhythm)for(double tempo:{20.0,120.0,300.0})
        check(std::abs(Pedals::noteMilliseconds(note,rhythm,tempo)-60000/tempo*beats[note]*factors[rhythm])<1e-9,"musical timing "+std::to_string(note)+"/"+std::to_string(rhythm)+"/"+std::to_string(tempo));
    check(Pedals::noteMilliseconds(4,0,std::numeric_limits<double>::quiet_NaN())==500,"nonfinite tempo uses 120 BPM");
    check(Pedals::noteMilliseconds(-2,0,120)==31.25,"low note index clamp");
    check(Pedals::noteMilliseconds(100,0,120)==4000,"high note index clamp");
}
void identity()
{
    for(double rate:{22050.0,44100.0,48000.0,96000.0,192000.0})
    {
        Pedals p;p.prepare(rate);p.setSettings(drySettings());
        bool exact=true;
        for(int i=0;i<6000;++i)
        {
            const Stereo x{static_cast<float>(.6*std::sin(i*.172)),static_cast<float>(.4*std::cos(i*.337))};
            const auto y=process(p,x);exact=exact&&x.l==y.l&&x.r==y.r;
        }
        check(exact,"disabled pedal identity at "+std::to_string(rate));
    }
}
void compressor()
{
    auto s=drySettings();s.set(Param::compEnabled,1);s.set(Param::compThreshold,-24);s.set(Param::compRatio,4);s.set(Param::compAttack,20);s.set(Param::compRelease,100);
    Pedals p;p.prepare(48000);p.setSettings(s);
    settle(p,48,{.5f,.25f});const float early=p.compressorReductionDb();
    settle(p,9600,{.5f,.25f});const float later=p.compressorReductionDb();
    settle(p,48000,{.5f,.25f});const auto full=process(p,{.5f,.25f});
    const double expectedReduction=(20*std::log10(.5)+24)*.75;
    check(early<later*.2,"compressor preserves initial attack");
    check(std::abs(p.compressorReductionDb()-expectedReduction)<.02,"compressor reaches specified static ratio");
    check(std::abs(full.l-.5*std::pow(10,-expectedReduction/20))<.001,"compressor attenuates as expected");
    check(std::abs(full.r/full.l-.5)<1e-6,"compressor stereo linking preserves image");
    settle(p,4800,{});const float halfway=p.compressorReductionDb();
    settle(p,48000,{});
    check(halfway>1&&halfway<later,"compressor releases gradually");
    check(p.compressorReductionDb()<.01,"compressor releases after silence");
    s.set(Param::compMix,50);Pedals parallel;parallel.prepare(48000);parallel.setSettings(s);settle(parallel,48000,{.5f,.25f});
    check(std::abs(process(parallel,{.5f,.25f}).l-(.5+full.l)*.5)<.001,"parallel compressor mix");
    s.set(Param::compRatio,1);Pedals unity;unity.prepare(48000);unity.setSettings(s);settle(unity,48000,{.5f,.25f});
    check(std::abs(process(unity,{.5f,.25f}).l-.5f)<1e-6,"ratio one is unity");
}
void gate()
{
    auto s=drySettings();s.set(Param::gateEnabled,1);s.set(Param::gateThreshold,-50);s.set(Param::gateRelease,50);
    Pedals p;p.prepare(48000);p.setSettings(s);
    settle(p,24000,{1e-5f,1e-5f});check(p.gateGain()<.0001,"gate attenuates subthreshold noise");
    settle(p,480,{.1f,.05f});check(p.gateGain()>.999,"gate opens promptly for instrument");
    settle(p,24000,{.0025f,.00125f});check(p.gateGain()>.999,"gate hysteresis retains signal between thresholds");
    settle(p,48000,{1e-5f,1e-5f});check(p.gateGain()<.0001,"gate closes after hold and release");
    s.set(Param::gateEnabled,0);p.setSettings(s);settle(p,4800,{1e-5f,1e-5f});
    check(std::abs(process(p,{1e-5f,1e-5f}).l-1e-5f)<1e-10,"gate bypass restores original signal");
}
void modulation()
{
    auto s=drySettings();s.set(Param::chorusEnabled,1);s.set(Param::chorusDepth,85);s.set(Param::chorusMix,55);s.set(Param::chorusRate,1.1f);
    Pedals p;p.prepare(48000);p.setSettings(s);double stereo=0,difference=0;
    for(int i=0;i<96000;++i)
    {
        const float x=static_cast<float>(.2*std::sin(2*pi*440*i/48000));const auto y=process(p,{x,x});
        if(i>4800){stereo+=(y.l-y.r)*(y.l-y.r);difference+=(y.l-x)*(y.l-x);}
    }
    check(stereo>40,"chorus creates stereo modulation from mono");check(difference>40,"chorus changes signal through delayed voices");
    s.set(Param::chorusEnabled,0);s.set(Param::phaserEnabled,1);s.set(Param::phaserDepth,0);s.set(Param::phaserFeedback,0);s.set(Param::phaserMix,50);
    const auto response=impulse(s,8192);
    double minimum=1,maximum=0;int regions=0;bool below=false;
    for(int k=0;k<420;++k)
    {
        const double frequency=60*std::pow(100.0,k/419.0);double re=0,im=0;
        for(std::size_t i=0;i<response.size();++i){const double phase=2*pi*frequency*static_cast<double>(i)/48000;re+=response[i].l*std::cos(phase);im-=response[i].l*std::sin(phase);}
        const double amplitude=std::sqrt(re*re+im*im);minimum=std::min(minimum,amplitude);maximum=std::max(maximum,amplitude);
        if(amplitude<.18&&!below)++regions;below=amplitude<.18;
    }
    check(minimum<.025,"phaser creates deep cancellation notches");check(maximum>.9,"phaser retains passbands");check(regions==3,"six-stage phaser creates three distinct notches");
    s.set(Param::phaserDepth,100);s.set(Param::phaserFeedback,90);s.set(Param::phaserMix,100);s.set(Param::phaserRate,5);
    Pedals moving;moving.prepare(48000);moving.setSettings(s);bool finite=true;
    for(int i=0;i<96000;++i){const auto y=process(moving,{static_cast<float>(.7*std::sin(i*.137)),static_cast<float>(.7*std::sin(i*.177))});finite=finite&&std::isfinite(y.l)&&std::isfinite(y.r)&&std::abs(y.l)<8&&std::abs(y.r)<8;}
    check(finite,"phaser maximum feedback remains bounded");
}
void delay()
{
    auto s=drySettings();s.set(Param::delayEnabled,1);s.set(Param::delayMode,0);s.set(Param::delayMix,100);s.set(Param::feedback,0);s.set(Param::delayDuck,0);s.set(Param::delayLowCut,20);s.set(Param::delayHighCut,18000);s.set(Param::noteL,3);s.set(Param::noteR,3);
    for(int rhythm=0;rhythm<3;++rhythm)
    {
        s.set(Param::rhythmL,static_cast<float>(rhythm));s.set(Param::rhythmR,static_cast<float>(rhythm));
        const int sample=static_cast<int>(std::round(Pedals::noteMilliseconds(3,rhythm,120)*48));
        const auto out=impulse(s,sample+300);
        check(energy(out,0,sample)==0,"synced delay has no early output "+std::to_string(rhythm));
        check(std::abs(out[static_cast<std::size_t>(sample)].l)>.5,"synced delay exact first arrival "+std::to_string(rhythm));
    }
    s.set(Param::sync,0);s.set(Param::timeMsL,100);s.set(Param::timeMsR,150);s.set(Param::feedback,50);
    auto out=impulse(s,20000);check(std::abs(out[4800].l)>.5&&out[4800].r==0,"independent left delay time");check(std::abs(out[7200].r)>.5,"independent right delay time");
    check(std::abs(out[9600].l)>.15,"feedback produces another repeat");
    s.set(Param::delayMode,2);out=impulse(s,20000);
    check(std::abs(out[4800].l)>.5&&out[4800].r==0,"ping pong first tap is left");check(std::abs(out[12000].r)>.15,"ping pong feedback crosses to right");
    double tail[2]={};
    for(int tails=0;tails<2;++tails)
    {
        s.set(Param::delayMode,0);s.set(Param::timeMsL,500);s.set(Param::timeMsR,500);s.set(Param::spillover,static_cast<float>(tails));s.set(Param::delayEnabled,1);
        Pedals p;p.prepare(48000);p.setSettings(s);
        for(int i=0;i<26000;++i)
        {
            if(i==4800){s.set(Param::delayEnabled,0);p.setSettings(s);}
            const auto y=process(p,i==0?Stereo{1,1}:Stereo{});if(i>23000)tail[tails]+=y.l*y.l+y.r*y.r;
        }
    }
    check(tail[0]<1e-10,"hard bypass clears delay history");check(tail[1]>.1,"spillover retains previously captured delay");
}
void routingAndBlocks()
{
    auto s=drySettings();s.set(Param::chorusEnabled,1);s.set(Param::phaserEnabled,1);s.set(Param::delayEnabled,1);s.set(Param::delayMode,1);
    s.set(Param::delayMix,20);s.set(Param::chorusMix,35);s.set(Param::phaserMix,35);
    constexpr int n=24000;std::vector<Stereo> reference(n);
    for(int block:{1,31,64,257,1024})
    {
        Pedals p;p.prepare(48000);p.setSettings(s);double error=0;
        for(int start=0;start<n;start+=block)
        {
            p.setSettings(s);
            for(int i=start;i<std::min(n,start+block);++i)
            {
                const Stereo x{static_cast<float>(.3*std::sin(i*.11)),static_cast<float>(.2*std::cos(i*.173))};
                const auto y=process(p,x);if(block==1)reference[static_cast<std::size_t>(i)]=y;
                else error=std::max(error,static_cast<double>(std::max(std::abs(y.l-reference[static_cast<std::size_t>(i)].l),std::abs(y.r-reference[static_cast<std::size_t>(i)].r))));
            }
        }
        check(error<1e-7,"block size invariance "+std::to_string(block));
    }
    // An identity amplifier must produce the same modulation at either
    // position. This also catches accidental double phase advancement.
    std::vector<Stereo> before(n);double routeError=0;
    for(int location=0;location<2;++location)
    {
        s.set(Param::modPosition,static_cast<float>(location));Pedals p;p.prepare(48000);p.setSettings(s);
        for(int i=0;i<n;++i)
        {
            const auto y=process(p,{static_cast<float>(.3*std::sin(i*.11)),static_cast<float>(.2*std::cos(i*.173))});
            if(location==0)before[static_cast<std::size_t>(i)]=y;else routeError=std::max(routeError,static_cast<double>(std::max(std::abs(y.l-before[static_cast<std::size_t>(i)].l),std::abs(y.r-before[static_cast<std::size_t>(i)].r))));
        }
    }
    check(routeError<1e-7,"modulation advances once for either routing position");
}
void stability()
{
    uint32_t random=0x1fa87;
    auto noise=[&random](){random=1664525u*random+1013904223u;return static_cast<float>(static_cast<int32_t>(random))/2147483648.0f;};
    for(double rate:{8000.0,22050.0,48000.0,96000.0,192000.0})
    {
        auto s=drySettings();Pedals p;p.prepare(rate);bool finite=true;
        for(int i=0;i<40000;++i)
        {
            if(i%509==0)
            {
                for(auto k:{Param::gateEnabled,Param::compEnabled,Param::chorusEnabled,Param::phaserEnabled,Param::delayEnabled,Param::modPosition,Param::spillover})s.set(k,noise()>0?1.0f:0.0f);
                s.set(Param::compMakeup,18);s.set(Param::compRatio,12);s.set(Param::phaserFeedback,90);s.set(Param::phaserDepth,100);s.set(Param::chorusDepth,100);s.set(Param::feedback,95);s.set(Param::delayMix,100);s.set(Param::sync,0);s.set(Param::timeMsL,1+std::abs(noise())*400);s.set(Param::timeMsR,1+std::abs(noise())*400);s.set(Param::delayMode,static_cast<float>((i/509)%3));p.setSettings(s);
            }
            const auto y=process(p,{noise(),noise()});finite=finite&&std::isfinite(y.l)&&std::isfinite(y.r)&&std::abs(y.l)<=32&&std::abs(y.r)<=32;
        }
        check(finite,"automated maximum settings stability "+std::to_string(rate));
        p.reset();const auto y=process(p,{});check(y.l==0&&y.r==0,"reset removes all tails "+std::to_string(rate));
    }
    Pedals p;p.prepare(48000);p.setSettings(drySettings());
    const auto y=process(p,{std::numeric_limits<float>::infinity(),std::numeric_limits<float>::quiet_NaN()});
    check(y.l==0&&y.r==0,"nonfinite host samples are contained");
}
void realtime()
{
    auto s=drySettings();
    for(auto k:{Param::compEnabled,Param::chorusEnabled,Param::phaserEnabled,Param::delayEnabled})s.set(k,1);
    Pedals p;p.prepare(48000);p.setSettings(s);
    allocationAudit::count=0;allocationAudit::enabled=true;
    for(int i=0;i<12000;++i)
    {
        if(i%257==0){s.set(Param::modPosition,static_cast<float>((i/257)%2));p.setSettings(s);}
        process(p,{static_cast<float>(.1*std::sin(i*.1)),static_cast<float>(.1*std::sin(i*.13))});
        if(i%4096==0)p.reset();
    }
    allocationAudit::enabled=false;
    check(allocationAudit::count==0,"processing, settings, routing and reset allocate no memory");
    s=drySettings();s.set(Param::chorusEnabled,1);s.set(Param::phaserEnabled,1);s.set(Param::chorusMix,65);s.set(Param::phaserMix,65);
    Pedals switching;switching.prepare(48000);switching.setSettings(s);Stereo previous{};float maxStep=0;
    for(int i=0;i<48000;++i)
    {
        if(i==12000||i==30000){s.set(Param::modPosition,i==12000?0.0f:1.0f);switching.setSettings(s);}
        const float x=static_cast<float>(.2*std::sin(2*pi*180*i/48000));
        const auto y=process(switching,{x,x});
        if(i>4800)maxStep=std::max(maxStep,std::max(std::abs(y.l-previous.l),std::abs(y.r-previous.r)));
        previous=y;
    }
    check(maxStep<.03,"modulation routing switches without abrupt output discontinuities");
}
}
int main()
{
    timings();identity();compressor();gate();modulation();delay();routingAndBlocks();stability();realtime();
    std::cout<<"Pedalboard checks: "<<passed<<" passed, "<<failed<<" failed.\n";
    return failed==0?0:1;
}
