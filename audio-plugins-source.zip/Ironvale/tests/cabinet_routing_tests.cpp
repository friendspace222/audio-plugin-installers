#include "AmpCore.h"
#include <array>
#include <cmath>
#include <iostream>
#include <stdexcept>

using namespace ironvale;
namespace {
int checks=0;
void check(bool condition,const char* message) { ++checks; if(!condition) throw std::runtime_error(message); }
using Response=std::array<float,4096>;
Response render(int rig,int cabinet,int speaker,bool user=false,bool enabled=true) {
    Settings s;s.set(Param::rig,float(rig));s.set(Param::cabinet,float(cabinet));
    s.set(Param::speakerModel,float(speaker));s.set(Param::ampEnabled,0);
    s.set(Param::cabEnabled,enabled?1.0f:0.0f);s.set(Param::cabRoom,0);
    AmpCore core;core.setSettings(s);core.prepare(48000);
    if(user) { const float ir[]={0.7f,0.0f,-0.12f,0.06f};core.setUserImpulse(ir,4);core.reset(); }
    Response out{};
    for(size_t n=0;n<out.size();++n)out[n]=core.process({n==0?0.25f:0.0f,0.0f}).l;
    return out;
}
double difference(const Response& a,const Response& b) {
    double result=0;for(size_t n=0;n<a.size();++n)result=std::max(result,std::abs(double(a[n])-b[n]));return result;
}
}
int main() {
    try {
        const auto original=render(0,4,0);
        const auto bass=render(1,4,0);
        const auto user=render(0,7,0,true);
        const auto fallback=render(0,7,0);
        const auto bypass=render(0,4,0,false,false);
        for(int speaker=1;speaker<=5;++speaker) {
            check(difference(original,render(0,4,speaker))>1e-4,"Speaker selection did not reach convolution");
            check(difference(bass,render(1,4,speaker))==0,"Guitar speaker selection changed Bass");
            check(difference(user,render(0,7,speaker,true))==0,"Speaker family colored custom IR");
            check(difference(fallback,render(0,7,speaker))==0,"Empty custom IR fallback changed");
            check(difference(bypass,render(0,4,speaker,false,false))==0,"Speaker selection changed cabinet bypass");
        }
        const auto measured=render(0,0,5);
        for(int cabinet=1;cabinet<7;++cabinet)
            check(difference(measured,render(0,cabinet,5))==0,"Measured fixed 4x12 changed with synthetic enclosure");
        for(int speaker=1;speaker<=4;++speaker)
            check(difference(render(0,0,speaker),render(0,5,speaker))>1e-4,"Designed speaker lost enclosure selection");
        AmpCore core;Settings s;s.set(Param::channel,3);s.set(Param::ampGain,7);core.setSettings(s);core.prepare(96000);
        double energy=0,peak=0;
        for(int n=0;n<48000;++n) {
            if(n%192==0) {s.set(Param::ampModel,float((n/192)%6));s.set(Param::speakerModel,float((n/384)%6));s.set(Param::cabinet,float((n/576)%8));core.setSettings(s);}
            auto y=core.process({0.08f*std::sin(n*0.037f),0.05f*std::cos(n*0.071f)});
            if(!std::isfinite(y.l)||!std::isfinite(y.r))throw std::runtime_error("Voice/cabinet automation produced nonfinite output");
            peak=std::max(peak,std::max(std::abs(double(y.l)),std::abs(double(y.r))));energy+=y.l*y.l+y.r*y.r;
        }
        check(energy>0.001 && peak<8.0,"Voice/cabinet automation unstable or silent");
        std::cout<<"PASS: "<<checks<<" cabinet routing checks; Bass, custom IR, fixed measured geometry, bypass and rapid automation. Peak="<<peak<<'\n';
        return 0;
    }catch(const std::exception& e) {std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}
}
