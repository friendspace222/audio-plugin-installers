#include "DSP.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>

namespace {
int checks=0;
void check(bool ok,const char* why){++checks;if(!ok)throw std::runtime_error(why);}
using namespace ironvale;
void run(Engine& e,std::vector<float>& l,std::vector<float>& r,int block,bool bypass=false)
{for(int p=0;p<(int)l.size();p+=block)e.process(l.data()+p,r.data()+p,std::min(block,(int)l.size()-p),bypass);}
}
int main()
{
    try {
        for(double rate:{44100.0,48000.0,96000.0,192000.0})
        {
            Settings s;s.set(Param::inputDb,18);s.set(Param::outputDb,-20);s.set(Param::delayEnabled,1);
            Engine e;e.prepare(rate);e.setSettings(s);
            std::vector<float> l(4096),r(4096),original(4096);
            for(int i=0;i<4096;++i)original[i]=l[i]=.3f*std::sin(i*.037f);r=l;
            run(e,l,r,113,true);bool exact=true;
            for(int i=0;i<4096;++i)exact=exact&&std::abs(l[i]-(i<32?0:original[i-32]))<1e-6f&&l[i]==r[i];
            check(exact,"Host bypass must preserve exact original signal with 32 samples latency");
            e.reset();s.set(Param::bypass,1);e.setSettings(s);l=original;r=original;run(e,l,r,257);
            for(int i=0;i<4096;++i)check(std::abs(l[i]-(i<32?0:original[i-32]))<1e-6f,"Parameter bypass mismatch");
        }
        Settings s;s.set(Param::rig,1);s.set(Param::channel,2);s.set(Param::cabinet,6);
        for(auto p:{Param::compEnabled,Param::odEnabled,Param::dirtEnabled,Param::chorusEnabled,Param::phaserEnabled,Param::delayEnabled})s.set(p,1);
        s.set(Param::gateEnabled,0);s.set(Param::sync,0);s.set(Param::timeMsL,19);s.set(Param::timeMsR,27);
        const int length=24000;std::vector<float> a(length),b(length),c(length),d(length);
        for(int i=0;i<length;++i){a[i]=c[i]=.2f*std::sin(i*.09f);b[i]=d[i]=.15f*std::cos(i*.055f);}
        Engine x,y;x.prepare(48000);y.prepare(48000);x.setSettings(s);y.setSettings(s);
        run(x,a,b,1);run(y,c,d,511);float error=0,peak=0;
        for(int i=0;i<length;++i){error=std::max(error,std::abs(a[i]-c[i]));error=std::max(error,std::abs(b[i]-d[i]));peak=std::max(peak,std::abs(a[i]));}
        check(error<1e-6f,"Full chain must be independent of host block size");check(peak>.001f&&peak<4,"Full chain unexpectedly silent or unstable");
        s.set(Param::inputDb,std::numeric_limits<float>::quiet_NaN());check(std::isfinite(s.get(Param::inputDb)),"Nonfinite parameter not sanitized");
        x.setSettings(s);a.assign(512,std::numeric_limits<float>::infinity());b=a;run(x,a,b,64);
        check(std::all_of(a.begin(),a.end(),[](float v){return std::isfinite(v);}),"Invalid host samples poisoned engine");
        x.reset();a.assign(512,0);b=a;run(x,a,b,64);
        check(*std::max_element(a.begin(),a.end())==0,"Reset left audible state");
        std::cout<<"PASS: "<<checks<<" integrated DSP checks; bypass, fixed latency, complete-chain block invariance and invalid-input recovery.\n";
    }catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}
}
