#include "../Source/AmpCore.h"
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <new>
#include <string>
#include <vector>

static std::atomic<bool> countAllocations{false};
static std::atomic<int> allocations{0};
void* operator new(std::size_t size) {
    if (countAllocations.load()) ++allocations;
    if (auto* p = std::malloc(size ? size : 1)) return p;
    throw std::bad_alloc();
}
void* operator new[](std::size_t size) { return ::operator new(size); }
void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
void operator delete[](void* p, std::size_t) noexcept { std::free(p); }

using namespace ironvale;
namespace {
constexpr double pi = 3.14159265358979323846;
int checks = 0, failures = 0;
void check(bool condition, const std::string& label) {
    ++checks;
    if (!condition) { ++failures; std::cerr << "FAIL: " << label << '\n'; }
}
Settings transparent() {
    Settings s;
    for (auto p : {Param::ampEnabled, Param::cabEnabled, Param::odEnabled, Param::dirtEnabled}) s.set(p, 0);
    s.set(Param::cabRoom, 0); s.set(Param::presence, 50); s.set(Param::resonance, 50);
    s.set(Param::sag, 0); s.set(Param::tight, 0);
    return s;
}
std::vector<float> impulse(AmpCore& amp, int n = 4096) {
    std::vector<float> result(n);
    for (int i = 0; i < n; ++i) result[i] = amp.process({i == 0 ? 1.0f : 0.0f, 0}).l;
    return result;
}
double energy(const std::vector<float>& x) { double e = 0; for (auto v : x) e += v * v; return e; }
double magnitude(const std::vector<float>& x, double frequency, double rate) {
    double re = 0, im = 0;
    for (std::size_t n = 0; n < x.size(); ++n) {
        const double phase = 2 * pi * frequency * n / rate;
        re += x[n] * std::cos(phase); im -= x[n] * std::sin(phase);
    }
    return 2 * std::hypot(re, im) / x.size();
}
std::vector<float> tone(AmpCore& amp, float frequency, float amplitude, int samples = 4800, int settle = 12000, double rate = 48000) {
    std::vector<float> result(samples);
    for (int n = 0; n < settle + samples; ++n) {
        const float x = amplitude * static_cast<float>(std::sin(2 * pi * frequency * n / rate));
        const auto y = amp.process({x, x});
        if (n >= settle) result[n - settle] = y.l;
    }
    return result;
}
double thd(const std::vector<float>& signal, double frequency, double rate = 48000) {
    const double fundamental = magnitude(signal, frequency, rate);
    double harmonics = 0;
    for (int n = 2; n <= 12 && frequency * n < rate * 0.45; ++n) {
        const double h = magnitude(signal, frequency * n, rate); harmonics += h * h;
    }
    return std::sqrt(harmonics) / std::max(1.0e-12, fundamental);
}

void latencyAndBypass() {
    for (double rate : {44100.0,48000.0,96000.0,192000.0}) {
        AmpCore amp; auto s = transparent(); amp.setSettings(s); amp.prepare(rate);
        for (int n = 0; n < 128; ++n) {
            auto y = amp.process({n == 0 ? 0.75f : 0, n == 1 ? -0.25f : 0});
            check(std::abs(y.l - (n == AmpCore::latencySamples ? 0.75f : 0)) < 1.0e-7f, "aligned dry left at " + std::to_string(rate));
            check(std::abs(y.r - (n == AmpCore::latencySamples + 1 ? -0.25f : 0)) < 1.0e-7f, "aligned dry right at " + std::to_string(rate));
        }
        s.set(Param::rig, 1); s.set(Param::dirtEnabled, 1); s.set(Param::dirtBlend, 0);
        amp.setSettings(s); amp.reset(); const auto ir = impulse(amp, 256);
        const auto peak = std::max_element(ir.begin(), ir.end());
        check(std::distance(ir.begin(), peak) == AmpCore::latencySamples, "4x FIR measured latency at " + std::to_string(rate));
        double sum = 0, symmetry = 0;
        for (float v : ir) sum += v;
        for (int n = 0; n <= 64; ++n) symmetry += std::abs(ir[n] - ir[64 - n]);
        check(std::abs(sum - 1.0) < 0.001, "4x FIR unity DC at " + std::to_string(rate));
        check(symmetry < 0.0001, "4x FIR linear phase at " + std::to_string(rate));
    }
}

void convolutionCorrectness() {
    AmpCore amp; auto s = transparent(); s.set(Param::cabEnabled, 1); s.set(Param::cabinet, 7);
    amp.setSettings(s); amp.prepare(48000);
    std::array<float, AmpCore::maxIRSamples> ir{}; ir[0] = 1;
    amp.setUserImpulse(ir.data(), 1); amp.reset(); const auto reference = impulse(amp, 6144);
    for (int offset : {1, 63, 64, 65, 127, 128, 255, 511, 1023, 2047}) {
        ir.fill(0); ir[offset] = 0.75f;
        amp.setUserImpulse(ir.data(), offset + 1); amp.reset(); const auto shifted = impulse(amp, 6144);
        double error = 0;
        for (int n = 0; n < 6144; ++n) {
            const double expected = n >= offset ? reference[n - offset] * 0.75f : 0;
            error = std::max(error, std::abs(shifted[n] - expected));
        }
        check(error < 0.00001, "zero-latency partitioned IR convolution offset " + std::to_string(offset));
    }
    // A dense arbitrary IR exercises summed and overlapping partitions.
    ir.fill(0);
    for (int n = 0; n < 900; ++n) ir[n] = static_cast<float>(std::sin(n * 1.313) * std::exp(-n / 90.0) * 0.06);
    amp.setUserImpulse(ir.data(), 900); amp.reset(); const auto dense = impulse(amp, 6144);
    double error = 0;
    for (int n = 0; n < 6144; ++n) {
        double expected = 0;
        for (int k = 0; k < 900 && k <= n; ++k) expected += ir[k] * reference[n-k];
        error = std::max(error, std::abs(expected - dense[n]));
    }
    check(error < 0.000015, "dense FFT convolution matches direct reference");
    amp.reset(); const auto repeated = impulse(amp, 6144);
    check(dense == repeated, "reset produces sample-exact deterministic custom IR output");
    ir.fill(std::numeric_limits<float>::quiet_NaN());
    amp.setUserImpulse(ir.data(), AmpCore::maxIRSamples); amp.reset();
    const auto sanitized = impulse(amp);
    check(std::all_of(sanitized.begin(), sanitized.end(), [](float x) { return std::isfinite(x); }), "nonfinite custom IR safely sanitized");
    check(energy(sanitized) > 0.001, "empty/invalid custom IR falls back to factory");
}

void channelRangeAndBass() {
    AmpCore amp; amp.prepare(48000); auto s = transparent(); s.set(Param::ampEnabled, 1);
    s.set(Param::ampGain, 2); s.set(Param::ampMaster, 5); s.set(Param::channel, 0);
    amp.setSettings(s); amp.reset(); const auto clean = tone(amp, 1000, 0.10f);
    const double cleanThd = thd(clean, 1000);
    s.set(Param::ampGain, 8); s.set(Param::channel, 3); amp.setSettings(s); amp.reset();
    const auto lead = tone(amp, 1000, 0.10f); const double leadThd = thd(lead, 1000);
    std::cout << "Clean THD " << cleanThd * 100 << "%, Lead THD " << leadThd * 100 << "%\n";
    check(cleanThd < 0.005, "pristine clean THD below 0.5% at -20 dBFS input");
    check(leadThd > 0.12, "lead channel reaches substantial harmonic saturation");
    check(leadThd > cleanThd * 20, "clean-to-lead distortion range");
    std::array<double, 4> levels{};
    for (int c = 0; c < 4; ++c) {
        s.set(Param::channel, static_cast<float>(c)); s.set(Param::ampGain, 6); amp.setSettings(s); amp.reset();
        levels[c] = thd(tone(amp, 1000, 0.08f, 4800, 4800), 1000);
    }
    check(levels[0] < levels[1] && levels[1] < levels[2] && levels[2] < levels[3], "channels progressively increase saturation");
    s = transparent(); s.set(Param::rig, 1); s.set(Param::dirtEnabled, 1);
    s.set(Param::dirtAmount, 100); s.set(Param::dirtBlend, 100); amp.setSettings(s); amp.reset();
    const auto lowDirty = tone(amp, 40, 0.20f, 12000, 12000);
    const auto highDirty = tone(amp, 800, 0.20f, 4800, 12000);
    const double lowLevel = magnitude(lowDirty, 40, 48000), dirtThd = thd(highDirty, 800);
    std::cout << "Bass dirt 40 Hz level " << lowLevel << ", 800 Hz THD " << dirtThd * 100 << "%\n";
    check(lowLevel > 0.13, "bass dirt retains strong 40 Hz fundamental");
    check(dirtThd > 0.08, "bass dirt adds upper-band harmonics");
    s.set(Param::rig, 0); amp.setSettings(s); amp.reset(); const auto guitar = tone(amp, 800, 0.20f);
    check(thd(guitar, 800) < 0.0001, "bass-only dirt remains bypassed in guitar rig");
    s = transparent(); s.set(Param::odEnabled, 1); s.set(Param::odDrive, 0); amp.setSettings(s); amp.reset();
    const double mild = thd(tone(amp, 1000, 0.20f), 1000);
    s.set(Param::odDrive, 100); amp.setSettings(s); amp.reset(); const double heavy = thd(tone(amp, 1000, 0.20f), 1000);
    check(heavy > mild * 10 && heavy > 0.10, "overdrive spans mild to heavy");
}

void cabinetDifferences() {
    AmpCore amp; amp.prepare(48000); auto s = transparent(); s.set(Param::cabEnabled, 1);
    std::array<std::vector<float>, 14> responses;
    for (int rig = 0; rig < 2; ++rig) for (int cab = 0; cab < 7; ++cab) {
        s.set(Param::rig, static_cast<float>(rig)); s.set(Param::cabinet, static_cast<float>(cab));
        amp.setSettings(s); amp.reset(); responses[rig*7+cab] = impulse(amp, 4096);
        check(energy(responses[rig*7+cab]) > 0.001, "cabinet non-silent " + std::to_string(rig*7+cab));
    }
    for (int a = 0; a < 14; ++a) for (int b = a + 1; b < 14; ++b) {
        double difference = 0;
        for (int n = 0; n < 4096; ++n) difference += std::pow(responses[a][n]-responses[b][n], 2);
        check(difference > 0.00001, "cabinet responses distinct " + std::to_string(a) + "/" + std::to_string(b));
    }
    // Larger cabinets have deliberate low-end emphasis; verify it acoustically.
    const auto ratio = [](const std::vector<float>& x) { return magnitude(x, 70, 48000) / magnitude(x, 1000, 48000); };
    check(ratio(responses[6]) > ratio(responses[0]), "8x12 guitar cabinet extends low-end relative to 1x12");
    check(ratio(responses[13]) > ratio(responses[7]), "8x12 bass cabinet extends low-end relative to 1x12");
}

void bodyTouchAndDynamics() {
    std::array<std::array<double,6>,2> reference{};
    const std::array<double,6> frequencies{{31,41,60,82,110,140}};
    double worstRateDifference = 0;
    for (double rate : {48000.0,44100.0,96000.0,192000.0}) for (int rig=0;rig<2;++rig) {
        AmpCore amp; auto s=transparent(); s.set(Param::rig,static_cast<float>(rig));
        s.set(Param::cabEnabled,1);s.set(Param::cabinet,rig?6:5);s.set(Param::cabLowCut,rig?25:40);
        amp.setSettings(s);amp.prepare(rate);const auto ir=impulse(amp,8192);
        const double ref=magnitude(ir,rig?250:700,rate);
        std::array<double,6> body{};
        for(int n=0;n<6;++n)body[n]=20*std::log10(magnitude(ir,frequencies[n],rate)/ref);
        if(rate==48000)reference[rig]=body;
        else for(int n=0;n<6;++n)worstRateDifference=std::max(worstRateDifference,std::abs(body[n]-reference[rig][n]));
        check(body[rig?1:4]>(rig?2.0:6.0),"factory cabinet retains instrument body at "+std::to_string(rate));
        if(rig){
            check(body[0]>-2.0,"bass cabinet retains 31 Hz low-B range at "+std::to_string(rate));
            check(magnitude(ir,2000,rate)/ref>0.40,"bass cabinet retains upper-mid articulation at "+std::to_string(rate));
        }
        check(magnitude(ir,9000,rate)/ref<0.5,"cabinet attenuates high-frequency distortion at "+std::to_string(rate));
    }
    std::cout<<"Maximum 31-140 Hz cabinet response deviation from 48 kHz: "<<worstRateDifference<<" dB\n";
    check(worstRateDifference<3.0,"cabinet low-frequency voice remains comparable across sample rates");

    AmpCore amp;amp.prepare(48000);auto s=transparent();s.set(Param::ampEnabled,1);s.set(Param::channel,2);
    s.set(Param::ampGain,5);s.set(Param::ampMaster,5);amp.setSettings(s);amp.reset();
    const auto quiet=tone(amp,1000,0.008f);amp.reset();const auto loud=tone(amp,1000,0.15f);
    const double quietTHD=thd(quiet,1000),loudTHD=thd(loud,1000);
    const double effectiveGainRatio=magnitude(loud,1000,48000)/magnitude(quiet,1000,48000);
    const double secondHarmonic=magnitude(loud,2000,48000)/magnitude(loud,1000,48000);
    std::cout<<"Crunch pick-level THD quiet/loud: "<<quietTHD*100<<"% / "<<loudTHD*100
        <<"%; output fundamental ratio="<<effectiveGainRatio<<" for input ratio18.75; H2="<<secondHarmonic*100<<"%\n";
    check(loudTHD>quietTHD+0.05&&quietTHD<0.10,"crunch cleans up with lighter pick level");
    check(effectiveGainRatio>2&&effectiveGainRatio<12,"preamp compresses progressively without flattening pick dynamics");
    check(secondHarmonic>0.003,"asymmetric cascade produces measurable even harmonics");
    std::array<double,2> early{},late{};
    for(int setting=0;setting<2;++setting){
        s.set(Param::sag,setting?100:0);s.set(Param::ampMaster,8);amp.setSettings(s);amp.reset();
        const auto response=tone(amp,1000,0.15f,24000,0);
        for(int n=240;n<720;++n)early[setting]+=response[n]*response[n]/480.0;
        for(int n=12000;n<24000;++n)late[setting]+=response[n]*response[n]/12000.0;
    }
    const double sagDb=10*std::log10(late[1]/late[0]);
    const double sagBloom=10*std::log10((early[1]/late[1])/(early[0]/late[0]));
    std::cout<<"Sag100 versus Sag0 settled level="<<sagDb<<" dB; additional attack/sustain contrast="<<sagBloom<<" dB\n";
    check(sagDb<-1.0&&sagDb>-9.0,"output-driven sag creates controlled sustained compression");
    check(sagBloom>0.08,"sag responds dynamically after the initial attack");

    s=transparent();s.set(Param::ampEnabled,1);s.set(Param::channel,3);s.set(Param::ampGain,6);s.set(Param::ampMaster,5);
    std::array<double,2> tightGuitar{},tightBass{};
    for(int setting=0;setting<2;++setting){
        s.set(Param::rig,0);s.set(Param::channel,3);s.set(Param::tight,setting?100:0);amp.setSettings(s);amp.reset();
        tightGuitar[setting]=magnitude(tone(amp,80,0.005f,12000),80,48000);
        s.set(Param::rig,1);s.set(Param::channel,0);amp.setSettings(s);amp.reset();
        tightBass[setting]=magnitude(tone(amp,40,0.02f,12000),40,48000);
    }
    std::cout<<"Full Tight/zero Tight fundamental retention guitar80Hz="<<tightGuitar[1]/tightGuitar[0]
        <<", bass40Hz="<<tightBass[1]/tightBass[0]<<'\n';
    check(tightGuitar[1]/tightGuitar[0]>0.42,"maximum Tight retains guitar fundamental body");
    check(tightBass[1]/tightBass[0]>0.70,"maximum Tight preserves bass foundation");
    s=transparent();s.set(Param::rig,1);s.set(Param::dirtEnabled,1);s.set(Param::dirtAmount,100);s.set(Param::dirtBlend,100);
    amp.setSettings(s);amp.reset();const double dirtyFundamental=magnitude(tone(amp,40,0.20f,12000),40,48000);
    check(dirtyFundamental>0.15&&dirtyFundamental<0.26,"dirty bass foundation remains near the input fundamental level");
    s=transparent();s.set(Param::ampEnabled,1);s.set(Param::channel,3);s.set(Param::ampGain,8);amp.setSettings(s);amp.reset();
    const auto highTone=tone(amp,7000,0.2f);const double aliasDb=20*std::log10(std::max(1e-15,magnitude(highTone,13000,48000))/magnitude(highTone,7000,48000));
    std::cout<<"7 kHz high-gain stimulus: 13 kHz folded fifth-harmonic bin="<<aliasDb<<" dBc\n";
    check(aliasDb<-45,"4x processing suppresses selected folded harmonic below -45 dBc");
}

void familyVoicesAndTouch() {
    AmpCore amp; amp.prepare(48000); auto s=transparent();s.set(Param::ampEnabled,1);
    s.set(Param::ampGain,5);s.set(Param::ampMaster,5);s.set(Param::sag,45);s.set(Param::channel,2);
    std::array<std::vector<float>,6> voices;
    std::array<double,6> nonlinear{},quietTHD{},loudTHD{},attackContrast{};
    for(int model=0;model<6;++model) {
        s.set(Param::ampModel,static_cast<float>(model));s.set(Param::channel,2);s.set(Param::ampGain,5);
        s.set(Param::ampMaster,5);amp.setSettings(s);amp.reset();
        const auto quiet=tone(amp,1000,0.008f);amp.reset();const auto loud=tone(amp,1000,0.15f);
        quietTHD[model]=thd(quiet,1000);loudTHD[model]=thd(loud,1000);
        nonlinear[model]=magnitude(loud,1000,48000)/magnitude(quiet,1000,48000);
        check(loudTHD[model]>quietTHD[model]+0.025,"voice cleans up with light picking: "+std::to_string(model));
        check(nonlinear[model]>1.8&&nonlinear[model]<15,"voice retains progressive pick dynamics: "+std::to_string(model));
        amp.reset();voices[model].resize(12000);
        for(int n=0;n<24000;++n) {
            const float x=static_cast<float>(0.065*std::sin(2*pi*80*n/48000)+0.035*std::sin(2*pi*700*n/48000)
                +0.015*std::sin(2*pi*3100*n/48000));
            const auto y=amp.process({x,x});if(n>=12000)voices[model][n-12000]=y.l;
        }
        const float rms=static_cast<float>(std::sqrt(energy(voices[model])/voices[model].size()));
        for(auto& v:voices[model])v/=rms;
        s.set(Param::ampMaster,8);amp.setSettings(s);amp.reset();const auto burst=tone(amp,1000,0.15f,24000,0);
        double early=0,late=0;for(int n=240;n<720;++n)early+=burst[n]*burst[n]/480.0;
        for(int n=12000;n<24000;++n)late+=burst[n]*burst[n]/12000.0;
        attackContrast[model]=10*std::log10(early/late);
        std::cout<<"Voice "<<model<<" quiet/loud THD="<<quietTHD[model]*100<<"/"<<loudTHD[model]*100
            <<"% compressed amplitude ratio="<<nonlinear[model]<<" attack/sustain="<<attackContrast[model]<<" dB\n";
    }
    double minDifference=10;
    for(int a=0;a<6;++a)for(int b=a+1;b<6;++b) {
        double difference=0;for(std::size_t n=0;n<voices[a].size();++n)difference+=std::pow(voices[a][n]-voices[b][n],2);
        difference=std::sqrt(difference/voices[a].size());minDifference=std::min(minDifference,difference);
        check(difference>0.06,"family sound differs after RMS matching: "+std::to_string(a)+"/"+std::to_string(b));
    }
    std::cout<<"Minimum matched-RMS family waveform difference="<<minDifference<<'\n';
    check(*std::max_element(loudTHD.begin()+1,loudTHD.end())-*std::min_element(loudTHD.begin()+1,loudTHD.end())>0.06,
        "new families have different nonlinear responses at identical controls");
    check(*std::max_element(nonlinear.begin()+1,nonlinear.end())-*std::min_element(nonlinear.begin()+1,nonlinear.end())>0.75,
        "new families have different pick compression independent of output trim");
    check(*std::max_element(attackContrast.begin()+1,attackContrast.end())-*std::min_element(attackContrast.begin()+1,attackContrast.end())>0.25,
        "families have different attack and supply recovery behaviour");
    s.set(Param::ampModel,1);s.set(Param::channel,0);s.set(Param::ampGain,3);s.set(Param::ampMaster,5);
    amp.setSettings(s);amp.reset();const double glassTHD=thd(tone(amp,1000,0.1f),1000);
    std::cout<<"American Glass clean THD="<<glassTHD*100<<"%\n";
    check(glassTHD<0.005,"American Glass preserves clean headroom at ordinary DI level");
    std::array<double,2> brightRatios{};
    for(int n=0;n<2;++n) {
        s.set(Param::ampGain,n?9:1);amp.setSettings(s);amp.reset();
        const double low=magnitude(tone(amp,250,0.0005f),250,48000);amp.reset();
        const double high=magnitude(tone(amp,4000,0.0005f),4000,48000);brightRatios[n]=high/low;
    }
    const double brightDrop=20*std::log10(brightRatios[0]/brightRatios[1]);
    std::cout<<"American bright-path reduction at high gain="<<brightDrop<<" dB\n";
    check(brightDrop>2.0,"American bright bypass fades as preamp volume rises");
    for(int model:{0,4,5}) {
        s.set(Param::ampModel,static_cast<float>(model));s.set(Param::ampGain,2);s.set(Param::trebleDb,0);
        amp.setSettings(s);amp.reset();const double reference=magnitude(tone(amp,80,0.001f,12000),80,48000);
        s.set(Param::trebleDb,12);amp.setSettings(s);amp.reset();const double raised=magnitude(tone(amp,80,0.001f,12000),80,48000);
        const double lowChange=20*std::log10(raised/reference);
        std::cout<<"Voice "<<model<<" +12 dB treble changes 80 Hz by "<<lowChange<<" dB\n";
        check(model==0?std::abs(lowChange)<0.15:lowChange<-2.5,"family-specific treble/bass stack interaction: "+std::to_string(model));
    }
    for(int model=1;model<6;++model) {
        s=transparent();s.set(Param::ampEnabled,1);s.set(Param::ampModel,static_cast<float>(model));
        s.set(Param::ampMaster,5);s.set(Param::channel,0);s.set(Param::ampGain,2);amp.setSettings(s);amp.reset();
        const double clean=thd(tone(amp,1000,0.08f),1000);
        s.set(Param::channel,3);s.set(Param::ampGain,8);amp.setSettings(s);amp.reset();
        const double lead=thd(tone(amp,1000,0.08f),1000);
        check(clean<0.01&&lead>clean+0.12,"every family spans clean through high gain: "+std::to_string(model));
        amp.reset();const auto high=tone(amp,7000,0.2f);
        const double aliasDb=20*std::log10(std::max(1e-15,magnitude(high,13000,48000))/magnitude(high,7000,48000));
        std::cout<<"Voice "<<model<<" clean/lead THD="<<clean*100<<"/"<<lead*100<<"%; selected folded alias="<<aliasDb<<" dBc\n";
        check(aliasDb<-40,"family oversampling suppresses selected folded harmonic: "+std::to_string(model));
        s.set(Param::channel,0);s.set(Param::ampGain,3);std::array<double,2> presenceRatio{};
        for(int setting=0;setting<2;++setting) {
            s.set(Param::presence,setting?100:0);amp.setSettings(s);amp.reset();
            const double low=magnitude(tone(amp,300,0.001f),300,48000);amp.reset();
            const double highPresence=magnitude(tone(amp,6000,0.001f),6000,48000);presenceRatio[setting]=highPresence/low;
        }
        const double presenceRise=20*std::log10(presenceRatio[1]/presenceRatio[0]);
        std::cout<<"Voice "<<model<<" Presence0-to100 upper/low ratio change="<<presenceRise<<" dB\n";
        check(presenceRise>6.0,"Presence increases output-stage brilliance: "+std::to_string(model));
    }
}

void familySwitchingAndRates() {
    for(double rate:{44100.0,48000.0,96000.0,192000.0}) {
        AmpCore amp;auto s=transparent();s.set(Param::ampEnabled,1);s.set(Param::channel,3);s.set(Param::ampGain,10);
        s.set(Param::ampMaster,10);s.set(Param::sag,100);s.set(Param::tight,100);amp.setSettings(s);amp.prepare(rate);
        for(int model=1;model<6;++model) {
            s.set(Param::ampModel,static_cast<float>(model));s.set(Param::trebleDb,model&1?15:-15);
            s.set(Param::bassDb,model&1?-15:15);s.set(Param::lowMidDb,15);s.set(Param::highMidDb,15);
            amp.setSettings(s);amp.reset();bool finite=true;float peak=0;
            for(int n=0;n<static_cast<int>(rate*.10);++n) {
                const float input=static_cast<float>(0.8*std::sin(2*pi*83*n/rate)+0.35*std::sin(2*pi*2347*n/rate));
                const auto y=amp.process({input,-input});finite=finite&&std::isfinite(y.l)&&std::isfinite(y.r);
                peak=std::max(peak,std::max(std::abs(y.l),std::abs(y.r)));
            }
            check(finite&&peak<10&&peak>0.0001,"family stable at extreme settings: "+std::to_string(model)+"/"+std::to_string(rate));
            float tail=0;for(int n=0;n<static_cast<int>(rate);++n) {
                const auto y=amp.process({});if(n>rate*.85)tail=std::max(tail,std::max(std::abs(y.l),std::abs(y.r)));
            }
            check(tail<0.0002,"family energized state returns to silence: "+std::to_string(model)+"/"+std::to_string(rate));
            amp.reset();const auto first=impulse(amp,1024);amp.reset();
            check(first==impulse(amp,1024),"family reset is deterministic: "+std::to_string(model)+"/"+std::to_string(rate));
        }
        // Bass must not inherit a remembered guitar model, including its EQ.
        s=transparent();s.set(Param::rig,1);s.set(Param::ampEnabled,1);s.set(Param::channel,2);
        s.set(Param::ampModel,0);amp.setSettings(s);amp.reset();const auto bass=impulse(amp,2048);
        for(int model=1;model<6;++model) {
            s.set(Param::ampModel,static_cast<float>(model));amp.setSettings(s);amp.reset();
            check(bass==impulse(amp,2048),"guitar model leaves bass sample-exact: "+std::to_string(model)+"/"+std::to_string(rate));
        }
        s=transparent();s.set(Param::ampEnabled,1);s.set(Param::channel,2);amp.setSettings(s);amp.reset();
        bool finite=true;float largestJump=0,previous=0;
        allocations=0;countAllocations=true;
        for(int n=0;n<static_cast<int>(rate*.2);++n) {
            if(n%191==0){s.set(Param::ampModel,static_cast<float>((n/191)%6));amp.setSettings(s);}
            const float input=static_cast<float>(.03*std::sin(2*pi*180*n/rate));const auto y=amp.process({input,input});
            largestJump=std::max(largestJump,std::abs(y.l-previous));previous=y.l;finite=finite&&std::isfinite(y.l);
        }
        countAllocations=false;
        check(allocations==0,"model automation allocates no memory at "+std::to_string(rate));
        check(finite&&largestJump<.08f,"rapid model changes remain smoothed and bounded at "+std::to_string(rate));
        // An inactive fourth gain stage must not retain a coupling charge and
        // emit an old note when Citrus is selected again during silence.
        s=transparent();s.set(Param::ampEnabled,1);s.set(Param::channel,3);s.set(Param::ampGain,8);
        s.set(Param::ampMaster,8);s.set(Param::ampModel,3);amp.setSettings(s);amp.reset();
        for(int n=0;n<static_cast<int>(rate*.15);++n) {
            const float x=static_cast<float>(.2*std::sin(2*pi*83*n/rate));amp.process({x,x});
        }
        s.set(Param::ampModel,1);amp.setSettings(s);
        for(int n=0;n<static_cast<int>(rate);++n) {
            const float x=static_cast<float>(.2*std::sin(2*pi*83*n/rate));amp.process({x,x});
        }
        for(int n=0;n<static_cast<int>(rate);++n)amp.process({});
        s.set(Param::ampModel,3);amp.setSettings(s);float stalePeak=0;
        for(int n=0;n<static_cast<int>(rate*.25);++n){const auto y=amp.process({});stalePeak=std::max(stalePeak,std::abs(y.l));}
        std::cout<<"Returning to Citrus during silence peak="<<stalePeak<<" at "<<rate<<" Hz\n";
        check(stalePeak<1e-6f,"inactive gain stage cannot replay stale coupling state at "+std::to_string(rate));
    }
}

void stabilityAndRealtime() {
    float maximumPeak = 0;
    for (double rate : {44100.0,48000.0,96000.0,192000.0}) {
        AmpCore amp; amp.prepare(rate); Settings s;
        for (int rig = 0; rig < 2; ++rig) for (int channel = 0; channel < 4; ++channel) for (int cab = 0; cab < 8; ++cab) {
            s.set(Param::rig, static_cast<float>(rig)); s.set(Param::channel, static_cast<float>(channel)); s.set(Param::cabinet, static_cast<float>(cab));
            for (auto p : {Param::ampGain, Param::ampMaster}) s.set(p, 10);
            for (auto p : {Param::odEnabled, Param::dirtEnabled}) s.set(p, 1);
            for (auto p : {Param::odDrive,Param::dirtAmount,Param::dirtBlend,Param::presence,Param::resonance,Param::sag,Param::cabRoom}) s.set(p, 100);
            for (auto p : {Param::bassDb,Param::lowMidDb,Param::highMidDb,Param::trebleDb}) s.set(p, (cab & 1) ? 15 : -15);
            s.set(Param::midFreq, (cab & 2) ? 150 : 2500); s.set(Param::odLevelDb, 18);
            amp.setSettings(s);
            bool finite = true; float peak = 0;
            for (int n = 0; n < 2048; ++n) {
                const float x = static_cast<float>(std::sin(n * 0.071) * 1.5 + std::sin(n * 1.17) * 0.5);
                const auto y = amp.process({x, -x * 0.77f});
                finite = finite && std::isfinite(y.l) && std::isfinite(y.r);
                peak = std::max(peak, std::max(std::abs(y.l), std::abs(y.r)));
            }
            maximumPeak = std::max(maximumPeak, peak);
            check(finite && peak < 16.0f && peak > 0.000001f, "stable maximum settings at " + std::to_string(rate) + " rig/channel/cab " + std::to_string(rig)+"/"+std::to_string(channel)+"/"+std::to_string(cab));
        }
        // A safety limiter alone could hide unstable internal states. Verify
        // the energized filters really return to silence before resetting.
        float settledPeak = 0;
        for (int n = 0; n < static_cast<int>(rate * 1.5); ++n) {
            const auto y = amp.process({});
            if (n > rate) settledPeak = std::max(settledPeak, std::max(std::abs(y.l), std::abs(y.r)));
        }
        check(settledPeak < 0.0001f, "energized maximum-gain state decays to silence at " + std::to_string(rate));
        amp.reset();
        bool silent = true;
        for (int n = 0; n < 1024; ++n) { const auto y = amp.process({}); silent = silent && y.l == 0 && y.r == 0; }
        check(silent, "zero input produces exact silence after reset");
    }
    std::cout << "Maximum observed extreme-setting output peak " << maximumPeak << '\n';
    AmpCore amp; amp.prepare(48000); Settings s;
    std::array<float,AmpCore::maxIRSamples> ir{}; ir[0] = 1; ir[1023] = 0.1f;
    allocations = 0; countAllocations = true;
    amp.setUserImpulse(ir.data(), static_cast<int>(ir.size())); amp.reset();
    bool finite = true;
    for (int n = 0; n < 10000; ++n) {
        if (n % 100 == 0) { s.set(Param::cabinet, static_cast<float>((n / 100) % 8)); s.set(Param::channel, static_cast<float>((n / 100) % 4)); amp.setSettings(s); }
        const auto y = amp.process({0.1f, -0.2f}); finite = finite && std::isfinite(y.l) && std::isfinite(y.r);
    }
    countAllocations = false;
    check(allocations == 0, "process, setSettings, setUserImpulse and reset allocate no memory");
    check(finite, "rapid cabinet/channel automation stays finite");
    amp.reset(); auto bad = amp.process({std::numeric_limits<float>::infinity(), std::numeric_limits<float>::quiet_NaN()});
    check(std::isfinite(bad.l) && std::isfinite(bad.r), "nonfinite host input sanitized");
    s = transparent(); s.set(Param::ampEnabled, 1); s.set(Param::cabEnabled, 1); s.set(Param::cabRoom, 0);
    amp.setSettings(s); amp.reset(); bool isolated = true;
    for (int n = 0; n < 4096; ++n) { auto y = amp.process({n == 0 ? 0.5f : 0, 0}); isolated = isolated && y.r == 0; }
    check(isolated, "stereo paths remain isolated with room disabled");
}
} // namespace

int main() {
    const auto started = std::chrono::steady_clock::now();
    latencyAndBypass(); convolutionCorrectness(); channelRangeAndBass(); cabinetDifferences(); bodyTouchAndDynamics();
    familyVoicesAndTouch();familySwitchingAndRates();stabilityAndRealtime();
    const double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
    std::cout << "AmpCore: " << checks - failures << "/" << checks << " checks passed in " << elapsed << " seconds\n";
    return failures ? 1 : 0;
}
