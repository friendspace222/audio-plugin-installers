// Reproducible synthetic DI and single-core CPU probe. This is not a recorded
// guitar, a listening test, or a claim that a commercial amp has been matched.
// Build: clang++ -O2 -std=c++17 -I Source tests/amp_voice_probe.cpp Source/AmpCore.cpp
// Run with --cpu for five repeated 10-second, 48 kHz passes per amp family.
#include "AmpCore.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

using namespace ironvale;
namespace {
constexpr double pi=3.14159265358979323846;
constexpr int rate=48000;
double cpuSeconds() {
#ifdef _WIN32
    FILETIME created{},exited{},kernel{},user{};
    if(!GetThreadTimes(GetCurrentThread(),&created,&exited,&kernel,&user))return 0;
    ULARGE_INTEGER k{},u{};k.LowPart=kernel.dwLowDateTime;k.HighPart=kernel.dwHighDateTime;
    u.LowPart=user.dwLowDateTime;u.HighPart=user.dwHighDateTime;
    return (k.QuadPart+u.QuadPart)*1.0e-7;
#else
    return double(std::clock())/CLOCKS_PER_SEC;
#endif
}
float guitar(int n) {
    const double t=(n%19200)/double(rate);
    if(t>.30)return 0;
    const double envelope=(1-std::exp(-t/.0006))*std::exp(-t/.075);
    // Peak remains below 0.25, approximately -12 dBFS direct-interface input.
    return static_cast<float>(.145*envelope*(std::sin(2*pi*82.407*t)+.42*std::sin(2*pi*164.814*t)
        +.19*std::sin(2*pi*247.221*t)+.08*std::sin(2*pi*412.035*t)));
}
Settings settings(int model,int channel) {
    Settings s;s.set(Param::ampModel,static_cast<float>(model));s.set(Param::channel,static_cast<float>(channel));
    s.set(Param::ampGain,channel==0?3:channel==3?7:5);s.set(Param::ampMaster,5);s.set(Param::sag,45);
    s.set(Param::tight,50);s.set(Param::cabinet,5);s.set(Param::cabLowCut,40);s.set(Param::cabHighCut,8500);
    s.set(Param::cabMic,35);s.set(Param::cabRoom,0);s.set(Param::presence,50);s.set(Param::resonance,50);
    s.set(Param::odEnabled,0);s.set(Param::dirtEnabled,0);return s;
}
}
int main(int argc,char** argv) {
    const bool cpu=argc>1&&std::string(argv[1])=="--cpu";
    const int samples=cpu?480000:96000,repetitions=cpu?5:1;
    std::vector<float> input(samples);for(int n=0;n<samples;++n)input[n]=guitar(n);
    std::cout<<std::fixed<<std::setprecision(5);
    std::cout<<"model,channel,peak,rms,median_single_core_percent,passes,audio_seconds_per_pass\n";
    for(int model=0;model<6;++model)for(int channel=0;channel<4;++channel) {
        if(cpu&&channel!=2)continue;
        AmpCore amp;amp.setSettings(settings(model,channel));amp.prepare(rate);
        std::array<double,5> percentages{};double lastRms=0;float peak=0;
        for(int repeat=0;repeat<repetitions;++repeat) {
            amp.reset();for(int n=0;n<48000;++n)amp.process({input[n],input[n]});
            double total=0;peak=0;const double start=cpuSeconds();
            for(int n=0;n<samples;++n){const auto y=amp.process({input[n],input[n]});
                total+=y.l*y.l;peak=std::max(peak,std::abs(y.l));}
            const double seconds=cpuSeconds()-start;
            percentages[repeat]=100*seconds/(samples/double(rate));lastRms=std::sqrt(total/samples);
        }
        std::sort(percentages.begin(),percentages.begin()+repetitions);
        std::cout<<model<<','<<channel<<','<<peak<<','<<lastRms<<','<<percentages[repetitions/2]<<','
            <<repetitions<<','<<samples/double(rate)<<'\n';
    }
}
