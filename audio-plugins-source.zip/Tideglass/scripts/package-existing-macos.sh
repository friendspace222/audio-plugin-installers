#!/bin/bash
# Uses finished build output. Does not configure, compile, or install developer tools.
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
build_dir="${1:-$project_dir/build/macos-x86_64}"
fail() { echo "ERROR: $*" >&2; exit 1; }
[[ "$(uname -s)" == Darwin ]] || fail "Run this on the Mac where Tideglass was built."
metadata="$build_dir/tideglass-build-info.txt"
[[ -f "$metadata" ]] || fail "No completed build found in $build_dir. Keep the original Tideglass folder from the successful compilation."
arch="$(sed -n 's/^architecture=//p' "$metadata")"
minimum="$(sed -n 's/^deployment_target=//p' "$metadata")"
[[ -n "$arch" && -n "$minimum" ]] || fail "Build metadata lacks architecture or deployment target."
echo "Making the installer from your existing Tideglass build. No recompilation."
/bin/bash "$project_dir/scripts/package-macos.sh" "$build_dir" "$arch" "$minimum"
package="$(cat "$project_dir/dist/.latest-installer")"
[[ -f "$package" ]] || fail "Packaging did not produce an installer."
case "$package" in "$project_dir"/dist/*.pkg) ;; *) fail "Unexpected installer output path." ;; esac
echo "Opening Apple's Installer. Follow its onscreen steps to install Tideglass."
open -R "$package" || true
if ! open "$package"; then
    echo "Open this file in Finder to install: $package" >&2
fi
