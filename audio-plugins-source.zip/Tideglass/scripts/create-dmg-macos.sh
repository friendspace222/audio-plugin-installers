#!/bin/bash
set -euo pipefail
package="${1:?Usage: create-dmg-macos.sh INSTALLER_PKG CORRESPONDING_SOURCE}"
source_archive="${2:?Corresponding-source archive required}"
fail() { echo "ERROR: $*" >&2; exit 1; }
[[ "$(uname -s)" == Darwin ]] || fail "Creating a Mac disk image requires macOS."
[[ -f "$package" && -f "$source_archive" ]] || fail "Installer or source archive is missing."
destination="$(cd "$(dirname "$package")" && pwd)"
package="$destination/$(basename "$package")"
source_archive="$(cd "$(dirname "$source_archive")" && pwd)/$(basename "$source_archive")"
dmg="${package%.pkg}.dmg"
[[ ! -e "$dmg" ]] || fail "Disk image already exists: $dmg"
stage="$(mktemp -d "$destination/.tideglass-dmg.XXXXXX")"
cleanup() { case "$stage" in "$destination"/.tideglass-dmg.*) rm -rf -- "$stage" ;; esac; }
trap cleanup EXIT
mkdir -p "$stage/content"
ditto "$package" "$stage/content/Install Tideglass.pkg"
ditto "$source_archive" "$stage/content/$(basename "$source_archive")"
cat > "$stage/content/READ ME FIRST.txt" <<'EOF'
TIDEGLASS - INSTALLATION

1. Quit Logic Pro / GarageBand.
2. Double-click Install Tideglass.pkg in this disk image.
3. Follow Apple's Installer and enter your Mac administrator password when asked.
   Audio Unit is the format for Logic / GarageBand. VST3 and the optional
   standalone application are also offered.
4. Reopen your DAW. Find Audio Units > Tideglass Audio > Tideglass.

This contains compiled plugins. There is no compilation, Terminal command,
CMake, JUCE, or developer-tool setup required to install this package.

Unless the package name is Signed or Notarized, this is a locally built unsigned
installer. Catalina may require Open Anyway in System Preferences > Security &
Privacy > General after you try opening it. Only approve files you trust.

The accompanying source archive is included for the default GPLv3 distribution.
It is not needed for installation. Keep it with the installer if sharing copies.
EOF
hdiutil create -volname 'Tideglass Installer' -srcfolder "$stage/content" \
    -fs HFS+ -format UDZO "$stage/Tideglass.dmg"
hdiutil verify "$stage/Tideglass.dmg"
mv "$stage/Tideglass.dmg" "$dmg"
(cd "$destination" && shasum -a 256 "$(basename "$dmg")") > "$dmg.sha256"
echo "Created disk image: $dmg"
