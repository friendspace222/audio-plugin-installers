#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
build_dir="${1:?Usage: package-macos.sh BUILD_DIR [ARCHITECTURES] [MINIMUM_MACOS]}"
arch="${2:-x86_64}"
minimum="${3:-10.15}"
fail() { echo "ERROR: $*" >&2; exit 1; }
[[ "$(uname -s)" == Darwin ]] || fail "Apple pkgbuild/productbuild require macOS."
[[ "$minimum" =~ ^[0-9]+\.[0-9]+(\.[0-9]+)?$ ]] || fail "Invalid macOS version."
case "$arch" in
    x86_64) flavor="Intel" ;;
    arm64) flavor="AppleSilicon" ;;
    'x86_64;arm64'|'arm64;x86_64') flavor="Universal" ;;
    *) fail "Unsupported architecture setting." ;;
esac
installer_arch="$(echo "$arch" | tr ';' ',')"
build_dir="$(cd "$build_dir" && pwd)"
version="$(sed -n 's/^version=//p' "$build_dir/tideglass-build-info.txt")"
[[ "$version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || fail "Missing or invalid build version metadata."
/bin/bash "$project_dir/scripts/verify-macos.sh" "$build_dir" "$arch" "$minimum"
if [[ -n "${NOTARY_KEYCHAIN_PROFILE:-}" ]]; then
    [[ -n "${DEVELOPER_ID_APPLICATION:-}" && -n "${DEVELOPER_ID_INSTALLER:-}" ]] || \
        fail "Notarization requires both Developer ID identities, already installed in Keychain."
fi
dist="$project_dir/dist"
mkdir -p "$dist"
dist="$(cd "$dist" && pwd)"
stage="$(mktemp -d "$dist/.tideglass-package.XXXXXX")"
cleanup() {
    case "$stage" in "$dist"/.tideglass-package.*) rm -rf -- "$stage" ;; esac
}
trap cleanup EXIT
artifacts="$build_dir/Tideglass_artefacts/Release"
mkdir -p "$stage/au/Library/Audio/Plug-Ins/Components" \
         "$stage/vst3/Library/Audio/Plug-Ins/VST3" \
         "$stage/app/Applications" "$stage/packages" \
         "$stage/docs/Library/Application Support/Tideglass"
ditto "$artifacts/AU/Tideglass.component" "$stage/au/Library/Audio/Plug-Ins/Components/Tideglass.component"
ditto "$artifacts/VST3/Tideglass.vst3" "$stage/vst3/Library/Audio/Plug-Ins/VST3/Tideglass.vst3"
ditto "$artifacts/Standalone/Tideglass.app" "$stage/app/Applications/Tideglass.app"

for bundle in \
    "$stage/au/Library/Audio/Plug-Ins/Components/Tideglass.component" \
    "$stage/vst3/Library/Audio/Plug-Ins/VST3/Tideglass.vst3" \
    "$stage/app/Applications/Tideglass.app"; do
    if [[ -n "${DEVELOPER_ID_APPLICATION:-}" ]]; then
        if [[ "$bundle" == *.app ]]; then
            codesign --force --sign "$DEVELOPER_ID_APPLICATION" --options runtime --timestamp \
                --entitlements "$project_dir/scripts/standalone.entitlements" "$bundle"
        else
            codesign --force --sign "$DEVELOPER_ID_APPLICATION" --options runtime --timestamp "$bundle"
        fi
    else
        codesign --force --sign - "$bundle"
    fi
    codesign --verify --strict --verbose=2 "$bundle"
done

support="$stage/docs/Library/Application Support/Tideglass"
ditto "$project_dir/docs" "$support/docs"
cp "$project_dir/LICENSE" "$project_dir/THIRD_PARTY_NOTICES.md" "$support/"
cp "$build_dir/tideglass-build-info.txt" "$support/"

for kind in au vst3 app docs; do
    options=()
    if [[ "$kind" != docs ]]; then
        pkgbuild --analyze --root "$stage/$kind" "$stage/$kind.plist"
        components="$(/bin/bash "$project_dir/scripts/prepare-component-plist.sh" "$stage/$kind.plist")"
        if [[ "$components" -gt 0 ]]; then
            options=(--component-plist "$stage/$kind.plist")
        else
            # Some Catalina pkgbuild versions do not classify .component/.vst3
            # as relocatable bundles. Their files still install at our exact root paths.
            echo "No relocatable bundle metadata for $kind; packaging the complete file payload."
        fi
    fi
    pkgbuild --root "$stage/$kind" --install-location / --ownership recommended \
        --identifier "audio.tideglass.plugin.$kind" --version "$version" \
        ${options[@]+"${options[@]}"} "$stage/packages/$kind.pkg"
done

cat > "$stage/Distribution.xml" <<EOF
<?xml version="1.0" encoding="utf-8"?>
<installer-gui-script minSpecVersion="2">
  <title>Tideglass $version</title>
  <options customize="always" require-scripts="false" hostArchitectures="$installer_arch"/>
  <domains enable_localSystem="true" enable_currentUserHome="false" enable_anywhere="false"/>
  <volume-check><allowed-os-versions><os-version min="$minimum"/></allowed-os-versions></volume-check>
  <choices-outline>
    <line choice="au"/><line choice="vst3"/><line choice="app"/><line choice="docs"/>
  </choices-outline>
  <choice id="au" title="Audio Unit — Logic Pro / GarageBand" description="Installs Tideglass in the system Audio Units folder." start_selected="true"><pkg-ref id="audio.tideglass.plugin.au"/></choice>
  <choice id="vst3" title="VST3 — compatible DAWs" description="Installs Tideglass in the system VST3 folder." start_selected="true"><pkg-ref id="audio.tideglass.plugin.vst3"/></choice>
  <choice id="app" title="Standalone application (optional)" description="Installs the standalone audio effects app in Applications." start_selected="false"><pkg-ref id="audio.tideglass.plugin.app"/></choice>
  <choice id="docs" title="Documentation and licenses" description="Installs documentation and license notices." visible="false" start_selected="true" enabled="false"><pkg-ref id="audio.tideglass.plugin.docs"/></choice>
  <pkg-ref id="audio.tideglass.plugin.au" version="$version">au.pkg</pkg-ref>
  <pkg-ref id="audio.tideglass.plugin.vst3" version="$version">vst3.pkg</pkg-ref>
  <pkg-ref id="audio.tideglass.plugin.app" version="$version">app.pkg</pkg-ref>
  <pkg-ref id="audio.tideglass.plugin.docs" version="$version">docs.pkg</pkg-ref>
</installer-gui-script>
EOF

status=Unsigned
sign_options=()
if [[ -n "${DEVELOPER_ID_APPLICATION:-}" && -n "${DEVELOPER_ID_INSTALLER:-}" ]]; then
    status=Signed
    sign_options=(--sign "$DEVELOPER_ID_INSTALLER" --timestamp)
fi
package="$dist/Tideglass-$version-macOS-$flavor-$status.pkg"
source_archive="$dist/Tideglass-$version-macOS-$flavor-Corresponding-Source.tar.gz"
[[ ! -e "$package" ]] || fail "Output already exists: $package. Move it aside before rebuilding."
[[ ! -e "$source_archive" ]] || fail "Output already exists: $source_archive. Move it aside before rebuilding."
productbuild --distribution "$stage/Distribution.xml" --package-path "$stage/packages" \
    ${sign_options[@]+"${sign_options[@]}"} "$stage/Tideglass.pkg"
if [[ -n "${NOTARY_KEYCHAIN_PROFILE:-}" ]]; then
    xcrun notarytool submit "$stage/Tideglass.pkg" --keychain-profile "$NOTARY_KEYCHAIN_PROFILE" --wait
    xcrun stapler staple "$stage/Tideglass.pkg"
    xcrun stapler validate "$stage/Tideglass.pkg"
    package="$dist/Tideglass-$version-macOS-$flavor-Notarized.pkg"
    [[ ! -e "$package" ]] || fail "Output already exists: $package"
fi
/bin/bash "$project_dir/scripts/package-source.sh" "$build_dir" "$stage"
mv "$stage/Tideglass.pkg" "$package"
mv "$stage/Tideglass-$version-Corresponding-Source.tar.gz" "$source_archive"
(cd "$dist" && shasum -a 256 "$(basename "$package")" "$(basename "$source_archive")") > "$package.sha256"
echo "Created: $package"
printf '%s\n' "$package" > "$dist/.latest-installer"
echo "Distribute its corresponding-source archive and notices alongside the installer."
echo "Catalina 10.15.7 + Logic/GarageBand listening and runtime validation still required."
if ! /bin/bash "$project_dir/scripts/create-dmg-macos.sh" "$package" "$source_archive"; then
    echo "The .pkg installer is ready. Disk-image creation failed; you can install directly from the .pkg." >&2
fi
