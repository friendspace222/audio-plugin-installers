#!/bin/bash
set -euo pipefail
build_dir="${1:?Usage: verify-macos.sh BUILD_DIR [ARCHITECTURES] [MINIMUM_MACOS]}"
expected_arch="${2:-x86_64}"
minimum="${3:-10.15}"
artifacts="$build_dir/Tideglass_artefacts/Release"
fail() { echo "ERROR: $*" >&2; exit 1; }
[[ "$(uname -s)" == Darwin ]] || fail "Verification requires macOS lipo and otool."
for binary in \
    "$artifacts/AU/Tideglass.component/Contents/MacOS/Tideglass" \
    "$artifacts/VST3/Tideglass.vst3/Contents/MacOS/Tideglass" \
    "$artifacts/Standalone/Tideglass.app/Contents/MacOS/Tideglass"; do
    [[ -f "$binary" ]] || fail "Build output missing: $binary"
    actual_arch="$(lipo -archs "$binary")"
    expected_sorted="$(echo "$expected_arch" | tr ';' '\n' | sort | tr '\n' ' ')"
    actual_sorted="$(echo "$actual_arch" | tr ' ' '\n' | sort | tr '\n' ' ')"
    [[ "$expected_sorted" == "$actual_sorted" ]] || fail "Architecture mismatch: $actual_arch in $binary; wanted $expected_arch"
    for architecture in $actual_arch; do
        declared="$(otool -arch "$architecture" -l "$binary" | awk '
            $1 == "cmd" { mode = $2 }
            mode == "LC_BUILD_VERSION" && $1 == "minos" { print $2; exit }
            mode == "LC_VERSION_MIN_MACOSX" && $1 == "version" { print $2; exit }')"
        [[ -n "$declared" ]] || fail "No minimum-macOS load command in $binary"
        awk -v actual="$declared" -v wanted="$minimum" 'BEGIN {
            split(actual,a,"."); split(wanted,b,".");
            for(i=1;i<=3;i++) { if(a[i]+0>b[i]+0) exit 1; if(a[i]+0<b[i]+0) exit 0 }
        }' || fail "Binary requires macOS $declared, above requested $minimum: $binary"
        echo "Verified $architecture / minimum macOS $declared: $binary"
    done
    # An absolute build-machine dependency must never escape into a distributed plug-in.
    while IFS= read -r dependency; do
        case "$dependency" in
            /System/Library/*|/usr/lib/*|@rpath/*|@loader_path/*|@executable_path/*|'') ;;
            *) fail "Non-system dependency in $binary: $dependency" ;;
        esac
    done < <(otool -L "$binary" | awk '/compatibility version/ { print $1 }')
done
echo "Binary metadata checks passed. This does not establish Catalina or DAW runtime compatibility."
