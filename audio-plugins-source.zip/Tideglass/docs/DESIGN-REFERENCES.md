# Design references and original scope

Research reviewed on 24 October 2026. These are feature references, not copied DSP, endorsements or proof of a ranking. No third-party binaries, presets or proprietary source are embedded in Tideglass.

| Reference | Useful product principles | Tideglass implementation |
|---|---|---|
| [Soundtoys EchoBoy](https://www.soundtoys.com/product/echoboy/) | Musical timing, dual/ping-pong echoes, character, modulation and rhythmic multi-taps. | Independent stereo subdivisions, three rhythmic feels, six original delay modes, four-tap texture. No 16-step rhythm editor or 30-style library. |
| [ValhallaDelay](https://valhalladsp.com/shop/delay/valhalladelay/) | Clear choice of modern and vintage delay characters, feedback shaping and ducking. | Digital/tape/analog voices, ducking, reverse grains and feedback controls. No claim to reproduce Valhalla's modes. |
| [FabFilter Pro-R 2 manual](https://www.fabfilter.com/help/pro-r) | Usable space/decay controls, pre-delay, width, ducking and freeze. | Named reverb voices and independent density, tone and mix controls. No decay-EQ graph, IR analysis or measured spectrum. |
| [ValhallaFutureVerb controls](https://valhalladsp.com/2025/10/03/valhallafutureverb-the-controls/) | Combining echo and reverb with selectable processing order. | Both serial directions plus parallel routing; distinct mixing semantics documented in the guide. |

Tideglass's priorities are immediate independent stomp switching, readable parameter access, deterministic host synchronization, stable original algorithms, portable source, and an explicit Catalina build target. Sound quality still needs blind listening comparisons, acoustic measurements and host compatibility work on the intended Mac before this can be considered a release-quality product.
