# Validation record

Development snapshot: 24 October 2026. This describes executed checks, not a claim of commercial release readiness.

| Check | Result |
|---|---|
| Dependency-free C++17 DSP build | Passed with Clang 23 and strict warnings. |
| DSP regression suite | **558 checks passed.** Includes sample rates 32/44.1/48/96/192 kHz, note timing, 36-second sync, all 144 mode/routing combinations, stereo ping-pong, tails, freeze, ducking, decay, automation and block-size invariance. |
| Real-time allocation instrumentation | No heap allocations observed in the tested processing, parameter-update and reset paths. |
| Windows x64 VST3 and standalone compilation | Passed, JUCE 7.0.12, LLVM-MinGW 20261020, CMake 4.4.4, Release. |
| Processor/editor tests | Passed: 37 parameters, host/internal tempo, dry bypass, state recall, malformed-state rejection, 16 presets, oversized mono blocks, mono-to-stereo and native editor construction. |
| Native interface | Rendered from the actual JUCE editor, visually inspected, corrected and rendered again. See `Tideglass-interface.png`. |
| Independent pluginval 1.0.4 | **Strictness 5 passed**, exit 0, on the final Windows VST3. Audio, automation, programs, state, GUI and buses tested. See [full report](validation/pluginval-windows.txt). External Steinberg validator was not supplied and was skipped. |
| Shell scripts | Bash syntax checks passed. |
| Corresponding-source export | Exported and read back the full archive, confirming project/dependency source and licenses and excluding Git metadata. |
| Portable Mac CMake | Official 3.31.8 archive downloaded; SHA-256 verified against the release checksum. Its Mac executables were not run here. |
| macOS AU / VST3 compilation | User's Mac screenshot shows AU/VST3/standalone binary metadata and signature checks succeeded before packaging failed. Mac artifacts have not been independently inspected here. |
| Native Mac `.pkg`, signing or notarization | Initial user run stopped while setting missing component-plist metadata. Packaging scripts repaired; successful native package creation/installation still awaits the Mac run. No existing Mac installer is claimed. |
| Catalina 10.15.7, Logic Pro, GarageBand | **Not run.** Minimum-OS settings and binary inspection are not substitutes for runtime validation. |
| Subjective comparisons with commercial effects | **Not performed.** No claim of being the world's best. |

The final DSP also has repeatable measurements in `demos/ENGINE-REVIEW.txt`. First-order antiderivative antialiasing reduced the two measured drive foldback components by approximately 11 and 21 dB in one deliberately harsh test. Residual aliasing remains. This does not establish general perceptual superiority or oversampled behavior.

Shimmer Freeze previously lost about 28 dB in the measurement window; its pitch feedback now fades out during freeze, and the same measurement shows approximately 0.28 dB of loss. Stomp input transitions are smoothed and have a continuity regression. Topology changes still briefly fade the processing and can be audible.

One offline benchmark processed 10 seconds of stereo 48 kHz Reverse + Shimmer in a median 0.566 seconds on this machine. CPU load, compiler, host and hardware change the result; this is not a Catalina performance guarantee or a real-time dropout test.

Remaining release work includes target-Mac compilation/installation, AU validation, Logic/GarageBand session tests, long sessions at small buffers, listening comparisons, and signing/notarization if distributing to others. Decay is a nominal feedback-network setting rather than a calibrated full-band RT60. Spring is an original spring-inspired texture. No AAX, convolution IR engine, external sidechain, surround, or oversampling is provided in this preview.

## Installer repair

The user's screenshot on 24 October 2026 reached `pkgbuild --analyze` after
verification of all three Mac binary bundles. `PlistBuddy Set` then failed because
the script assumed component 0 already contained `BundleIsRelocatable`.
The correction handles empty arrays, adds absent flags, updates existing flags,
and processes every recognized component and child bundle. Empty analysis arrays
still package their complete file payload at the declared root path.

Packaging-only launchers reuse existing Mac build output, retain backup scripts,
create a native `.pkg` plus an HFS+/UDZO `.dmg`, and open Apple's Installer.
No installed plugin or DAW preference changes occur before normal Installer steps.
Shell checks and a simulated Apple-tool regression harness are provided in
`tests/test_packaging.py`. Simulation checks shell control flow; it does not prove
native `pkgbuild`, signing, DMG, Gatekeeper, or installation behavior on Catalina.
