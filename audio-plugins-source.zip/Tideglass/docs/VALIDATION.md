# Tideglass 0.2.0 validation

## Sonic changes

The late reverberator uses 16 modulated feedback paths, orthogonal scattering, frequency-shaped decay, denser input/output diffusion, and independent stereo output projections. The old late-output projections were identical; the new stereo projections correct that collapse. Size changes propagation/reflection spacing; Diffusion changes spreading and scattering. Default low cut/ducking are now 80Hz/5%, with explicit fuller Cathedral Air and new Deep Hall presets.

The DSP tests cover delay timing, all mode/routing combinations, bypass/tails/freeze, automation, block-size invariance, invalid input, allocations, and targeted reverberation behavior. Processor tests cover host tempo, 37 stable parameters, state restoration including older filter/ducking values, 17 presets, mono/stereo buses, oversized blocks, and the native editor. Windows pluginval checks and the final native test record must refer to this version's binary.

The default signal remains an effects processor with floating-point headroom, not a mastering limiter. The decay display is a nominal design target, not a measured broadband RT60 for every mode and setting. Spring is a spring-inspired texture; Shimmer is a pitch-shift feedback effect.

## Installer and compatibility checks

The Windows 0.2.0 Release build passed both CTest suites (DSP and processor/editor). The standalone DSP suite passed 581 checks. See [sonic measurements](SONIC-VALIDATION-0.2.txt) for density, stereo, decay, control-response and throughput conditions and results.

The final Windows VST3 also passed pluginval 1.0.4 at strictness level 5, exit 0, seed 6702. The validator identified version 0.2.0 and exercised audio, automation, state, programs, buses and GUI. These are VST3 host checks, separate from the Mac AU validation.

The public build workflow uses a standard Intel Mac runner, Xcode 16.4, pinned JUCE 7.0.12, x86_64 architecture, and a macOS 10.15 deployment target. It runs CTest, verifies architecture/deployment metadata, creates native PKG/DMG files, checks all four package payloads use Catalina-compatible legacy gzip, installs AU/VST3/docs with default choices, reinstalls with the optional standalone app, checks destinations/receipts/signatures/versions, validates the system-installed AU with auval, and verifies the DMG and checksums. The accompanying BUILD-VALIDATION.txt records the exact successful run and source commit. The source archive includes the exact plugin and JUCE source and license notices.

The earlier 0.1.0 build completed these native install/AU checks on macOS 15.7.9 in [run 40103969853](https://github.com/friendspace222/audio-plugin-installers/actions/runs/40103969853). This is historical evidence, not the test record for 0.2.0. The newer build must pass its own checks before delivery.

Package, AU, and VST3 identities are unchanged so normal updates replace the same installed plugin. Tests cover clean/default installation and optional-app reinstall; a 0.1-to-0.2 upgrade on Catalina has not been executed here. The binaries are ad-hoc signed; installers are unsigned and unnotarized.

**Not established:** Catalina 10.15.7 runtime, the user's exact Logic/GarageBand version, low-buffer operation on an older Mac, or superiority to commercial products. No real guitar/bass DI was supplied for controlled listening. Numerical tests and synthesized probes do not establish realism or subjective quality.

Load a revised factory preset when evaluating 0.2.0. Saved projects preserve their knob values, while the changed engine can change their sound. Keep rendered stems and the previous installer for important older sessions.
