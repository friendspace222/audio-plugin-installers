# Tideglass user guide

Version 0.2.0 is an original algorithmic effects development preview. The algorithms are voiced for the named uses; they are not copies of commercial plugin algorithms or exact physical models of particular hardware.

## First session

Insert Tideglass on a stereo track, load First Light, and play audio. The turquoise Delay switch and amber Reverb switch are independent. Their illuminated state means that new audio is entering that effect. With Tails enabled, a bypassed effect can continue sounding until its existing tail decays. Panic immediately discards both effects' histories; it is intended to stop sustained feedback, and an abrupt cut can be audible.

Knobs support dragging and editable numeric values. Double-click restores a control's default. Hover for a tooltip. The window resizes while preserving its layout. All effect parameters can be automated by the host. Session save/restore includes settings; delay/reverb audio currently in memory is not saved.

## Evaluating the 0.2 update

Load **Deep Hall** for a broad, dense space or **Cathedral Air** for a larger, slower bloom. These presets explicitly lower the reverb low cut, raise diffusion, and remove ducking. A saved session keeps its old settings, including a high low cut or strong ducking, until you change them or load a preset. Changing presets resets all controls. The updated engine changes old presets' sound as well, so retain rendered stems of important older mixes.

Start with Size 80–95%, Diffusion 90–95%, a 30–50 ms pre-delay, and 40–50% Reverb Mix for an obvious effect on an insert. For a send, use 100% wet and set the amount with the send. Reduce Mix for a subtler result. Ducking deliberately hides the tail while you play; leave it at zero when judging depth.

## Delay

Sync follows the host BPM when the host supplies a valid tempo. The tempo readout identifies host versus internal timing. Internal BPM and Tap are used when the host supplies no tempo; Tap does not change the DAW's tempo. Sync is tempo-based, not locked to a particular bar position. In free mode the left and right times are milliseconds.

Each channel has its own note and rhythm selector. Straight is the written duration; Dotted multiplies it by 1.5; Triplet multiplies it by 2/3. At 120 BPM, a quarter is 500 ms, dotted eighth 375 ms, and eighth-note triplet 166.67 ms. Free timing spans 1–8,000 ms, while sync supports the full range up to 36 seconds. Changes crossfade read heads, so fast continuous automation intentionally smooths to the requested timing.

| Character | Behavior |
|---|---|
| Digital | Interpolated stereo repeats with optional filters, drive and modulation. |
| Tape | Softer bandwidth, saturation, wow and flutter. An original tape-inspired voice. |
| Analog | Darker two-pole filtering, saturation and stronger modulation. |
| Ping Pong | Mono-summed input starts on the left and alternates through cross-feedback. With zero feedback there is only the first left repeat. |
| Multi Tap | Four weighted taps distributed across both channels. Feedback recirculates the combined rhythm. |
| Reverse | Overlapping windowed reverse grains. Time controls grain span, rather than an exact conventional first-repeat timestamp. |

Feedback sets the amount recirculated, up to 98%. Hold suppresses new input and raises feedback close to unity. Tone filtering still operates, so held delay can darken and decay. Mix sets the effect's wet/dry blend. Low Cut and High Cut shape repeating audio; Drive saturates the repeats using first-order antiderivative antialiasing. This reduces, but does not eliminate, aliasing; it is not an oversampled saturator. Mod Depth and Rate move the delay read heads. Duck reduces the wet return while the input is strong, allowing it to emerge in gaps.

## Reverb

A sixteen-path modulated feedback delay network creates the late reverb. Six stages of stereo input diffusion, size-dependent early reflections, and independent stereo output diffusion shape its density and width. Low, middle, and high-frequency decay are shaped separately. Mode changes alter the size profile, early/late balance, diffusion, damping and modulation; Spring, Shimmer and Gated add their corresponding processing.

| Space | Starting use |
|---|---|
| Room | Small, immediate ambience and strong early reflections. |
| Chamber | Compact, lively reflections for instruments and voice. |
| Plate | Dense, bright, low-early-reflection texture. |
| Hall | Broader, smoother space for general ambience. |
| Cathedral | Large dimensions and a slower, darker build. |
| Spring | Compact space with additional dispersive allpass processing. This is a spring-inspired texture, not a calibrated mechanical model. |
| Shimmer | An actual dual-grain octave-up return feeds the reverb network. |
| Gated | Input-triggered hold and short release shape the reverb output. |

Decay controls nominal network decay time. Damping, mode, filters, modulation and Shimmer alter the measured broadband decay; the seconds display is not a measured acoustic RT60. Gated uses Decay to derive its hold window, from 80 to 900 ms, and caps network decay at 1.6 seconds. Size changes propagation and reflection spacing and can create pitch movement during automation. Pre-delay separates the input from both early reflections and the late tail. Diffusion changes input/output spreading and feedback scattering: higher values produce a thicker, smoother texture. Damping changes the frequency-dependent loss inside the network; Low/High Cut shape the output. Modulation animates the tail. Duck responds to the original input envelope.

Freeze closes the input and greatly extends the network decay while reducing damping and modulation. Shimmer progressively suspends its pitch-shift feedback during Freeze to sustain the existing field. Freeze includes slight loss and an amplitude bound for stability, so it is not a bit-perfect endless loop. Release Freeze to restore normal decay, or press Panic to clear all audio history.

## Mixing and routing

Parallel sends input to both engines and sums their wet returns. Its dry gain is `1 − max(active delay mix, active reverb mix)`. This uses one dry path. Two large wet returns can add level; use Output trim and watch the output meter. There is no mastering limiter or true-peak ceiling.

Delay → Reverb feeds the delay insert's mixed result into reverb. Reverb → Delay reverses the order. Each stage retains its own wet/dry setting. Setting both mixes to 100% in serial makes the second effect process only the first effect's wet output. Parallel at both 100% instead sums the two independent wet outputs, as a shared send effect.

Master Mix blends the original dry input with the entire configured processing result. Zero is dry;100% applies the configured routing and individual mixes. For a wet-only send, also set the active engine mixes to 100%. If both switches are off and tails have ended, audio passes dry even with Master Mix at 100%. Stereo Width operates on the wet returns; zero collapses them to mono,100% is their original width and 150% increases the side component. Output trim follows the global mix.

Routing and mode changes briefly fade the processing down and back up. This avoids sudden topology discontinuities, but it can create a short dip. Stomps smooth their output blend. Spillover switches stop new injection while existing tails continue; at extreme settings, an input cutoff or routing change can still be audible. Host bypass is controlled by the DAW and may handle tails differently.

## Presets and displays

The 17 factory presets are starting points, not loudness-matched product comparisons. Saving a user preset writes a `.tideglass` XML file. Loading one restores the controls. Loading a factory preset resets all controls, including Master Mix and Output; there is no mix lock in this version. The displayed factory preset name remains the starting preset when controls are edited.

The response display is a parameter-driven schematic, not a measured impulse response, waveform or spectrum analyzer. Input and output meters use the actual sample peaks. Output above 0 dBFS can clip downstream; reduce Output or the wet mixes. The internal feedback bounds are protective, not a substitute for gain staging.

## Compatibility and scope

The Mac target is Intel x86_64, minimum macOS 10.15, with AU for Logic Pro/GarageBand and VST3 for compatible hosts. Catalina 10.15.7 validation on hardware remains pending. Apple Silicon builds need macOS 11 or later. This is not an iOS/iPad app and does not include AAX for Pro Tools, VST 2, convolution IR loading, external sidechain input, oversampled saturation, MIDI learn or surround/immersive formats.

The standalone is useful for testing audio hardware, but the AU plugin is the normal way to work in Logic/GarageBand. Audio hardware and buffer settings are controlled by the host. Start at 44.1 or 48 kHz and a moderate buffer. Maximum-delay storage scales with sample rate; allow roughly 18 MB of DSP history at 48 kHz and 72 MB at 192 kHz per instance, plus framework overhead.
