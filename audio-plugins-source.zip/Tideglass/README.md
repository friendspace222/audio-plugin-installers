# Tideglass

**Stereo delay + algorithmic reverb · version 0.2.0 · development preview**

Tideglass combines two independently switchable effects in one native audio plugin. It is built for an Intel Mac running **macOS Catalina 10.15.7**, with **Audio Unit** as the primary format for Logic Pro and GarageBand. VST3 and a standalone effects application are also configured.

**Installation:** Use the compiled Mac Installer ZIP, unzip it, and double-click the `.pkg`. No developer tools are needed on the destination Mac. The corresponding-source archive is included for licensing and rebuilding. See the installer's `BUILD-VALIDATION.txt` for its exact native build/test record. Catalina 10.15.7 and Logic/GarageBand listening tests remain separate from the newer-Mac build checks.

## What's inside

- Six delay characters: Digital, Tape, Analog, Ping Pong, Multi Tap, Reverse.
- Independent left/right note values from 1/64 to two whole notes, each with straight, dotted or triplet timing. Host sync, internal tempo, tap tempo and 1–8,000 ms free timing. Synced timing reaches 36 seconds at 20 BPM.
- Feedback, delay wet/dry mix, feedback filtering, drive, modulation, ducking and hold.
- Eight reverb voices: Room, Chamber, Plate, Hall, Cathedral, Spring, Shimmer and Gated.
- Decay, size, pre-delay, damping, diffusion, modulation, wet/dry mix, filters, ducking and freeze.
- Parallel, Delay → Reverb and Reverb → Delay routing, stereo width, global mix and output trim.
- Large independent illuminated switches, optional spillover tails, a panic button, actual input/output peak meters and a response schematic.
- 17 factory presets, portable user presets, host automation and session-state recall.
- Mono and stereo processing; no network service, account or activation is required to use a built plugin.

## Install on a Mac

Transfer **Tideglass-0.2.0-Mac-Installer.zip** through Google Drive, download it on the Intel Mac, and extract it. Quit Logic/GarageBand and double-click **Tideglass-0.2.0-macOS-Intel-Unsigned.pkg**. AU and VST3 are selected by default; the standalone application is optional. The DMG contains the same installer.

The free build has no Apple Developer ID signature or notarization. If Catalina blocks the trusted package, use System Preferences → Security & Privacy → General → Open Anyway after trying to open it. Do not change global security settings.

To rebuild from source, see [build and packaging](docs/BUILD.md). Compiling is optional and is not part of normal installation.

## Use in Logic Pro or GarageBand

After running the Mac installer, quit and reopen the DAW. Choose an audio-effect insert, then **Audio Units → Tideglass Audio → Tideglass**. Try **Deep Hall** or **Cathedral Air** for the new spacious reverb tuning, and **Dotted Horizon** for rhythmic delay. When updating from 0.1, load a factory preset once: saved sessions retain their old filter and ducking values. The revised engine also changes the sound of old settings. The Delay and Reverb switches independently enable each effect.

For a bus/send return, choose **Send / Return**: both effect mixes are 100%, routing is Parallel and output is trimmed. The global Master Mix scales the configured processing; setting it to 100% alone does **not** remove the dry signal retained by each effect's own mix. See [the user guide](docs/USER-GUIDE.md) for routing and tails.

## Project map

- `Source/`: dependency-free DSP, JUCE processor and native editor.
- `tests/`: DSP regression suite and full processor/editor smoke tests.
- `scripts/`: Mac build, binary verification, packaging and source bundling.
- `.github/workflows/build.yml`: optional manually started builds on Mac and Windows.
- `docs/`: user guide, build notes, research and validation status.

Original Tideglass code is MIT licensed. The pinned JUCE 7.0.12 and VST3 SDK have their own licensing conditions; this default combined build follows their GPLv 3 route. Keep corresponding source and notices with distributed binaries. See `LICENSE` and `THIRD_PARTY_NOTICES.md` before distributing a commercial closed-source version.
