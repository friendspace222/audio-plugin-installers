# Tideglass

**Stereo delay + algorithmic reverb · version 0.1.0 · development preview**

Tideglass combines two independently switchable effects in one native audio plugin. It is built for an Intel Mac running **macOS Catalina 10.15.7**, with **Audio Unit** as the primary format for Logic Pro and GarageBand. VST3 and a standalone effects application are also configured.

**Release status:** The source, DSP tests, native interface and installer-generation workflow are provided. This Windows workspace cannot compile Apple Audio Units or run Apple's installer tools. No macOS binary or `.pkg` is represented as built or Catalina-tested. See [validation](docs/VALIDATION.md) for the actual checks completed. This is an original development build; it has not established superiority over commercial effects in listening tests.

## What's inside

- Six delay characters: Digital, Tape, Analog, Ping Pong, Multi Tap, Reverse.
- Independent left/right note values from 1/64 to two whole notes, each with straight, dotted or triplet timing. Host sync, internal tempo, tap tempo and 1–8,000 ms free timing. Synced timing reaches 36 seconds at 20 BPM.
- Feedback, delay wet/dry mix, feedback filtering, drive, modulation, ducking and hold.
- Eight reverb voices: Room, Chamber, Plate, Hall, Cathedral, Spring, Shimmer and Gated.
- Decay, size, pre-delay, damping, diffusion, modulation, wet/dry mix, filters, ducking and freeze.
- Parallel, Delay → Reverb and Reverb → Delay routing, stereo width, global mix and output trim.
- Large independent illuminated switches, optional spillover tails, a panic button, actual input/output peak meters and a response schematic.
- 16 factory presets, portable user presets, host automation and session-state recall.
- Mono and stereo processing; no network service, account or activation is required to use a built plugin.

## Build the Mac installer

Upload the complete **Mac Build Kit ZIP** to Google Drive, download it on your Mac, and extract it locally. Start with **START-HERE-MAC.txt**. On an Intel Mac with Apple's Command Line Tools, open **Build-and-Package.command**. The kit includes portable CMake and the exact JUCE source. If Finder does not launch it, run this from Terminal inside the extracted Tideglass directory:

```bash
bash scripts/build-macos.sh
```

The script builds and tests the plugin, checks CPU architecture and minimum-OS metadata, and uses Apple's `pkgbuild`/`productbuild` to create an actual installer in `dist/`. The complete ZIP needs no JUCE/CMake download; a smaller source-only checkout downloads missing dependencies from their official repositories. The Intel package targets macOS 10.15 and later. A newer Mac can build it, but **Catalina runtime testing remains necessary**. Apple Silicon builds are a separate optional target with macOS 11 or later.

The unsigned development installer offers AU and VST3 plus an optional standalone app. Developer ID signing and notarization are supported when the corresponding identities and credentials are supplied; they have not been performed here. No Gatekeeper settings need to be globally disabled. See [build and packaging](docs/BUILD.md) for prerequisites, signing and the optional manual GitHub Actions workflow.

## Use in Logic Pro or GarageBand

After building and running the Mac installer, quit and reopen the DAW. Choose an audio-effect insert, then **Audio Units → Tideglass Audio → Tideglass**. Start with **First Light**, **Vocal Halo** or **Dotted Horizon**. The Delay and Reverb switches independently enable each effect.

For a bus/send return, choose **Send / Return**: both effect mixes are 100%, routing is Parallel and output is trimmed. The global Master Mix scales the configured processing; setting it to 100% alone does **not** remove the dry signal retained by each effect's own mix. See [the user guide](docs/USER-GUIDE.md) for routing and tails.

## Project map

- `Source/`: dependency-free DSP, JUCE processor and native editor.
- `tests/`: DSP regression suite and full processor/editor smoke tests.
- `scripts/`: Mac build, binary verification, packaging and source bundling.
- `.github/workflows/build.yml`: optional manually started builds on Mac and Windows.
- `docs/`: user guide, build notes, research and validation status.

Original Tideglass code is MIT licensed. The pinned JUCE 7.0.12 and VST3 SDK have their own licensing conditions; this default combined build follows their GPLv 3 route. Keep corresponding source and notices with distributed binaries. See `LICENSE` and `THIRD_PARTY_NOTICES.md` before distributing a commercial closed-source version.
