# Tideglass third-party notices

Original Tideglass code is provided under the MIT license in `LICENSE`. No code,
presets, impulse responses, artwork, or algorithms have been extracted from any
commercial plug-in. Product names mentioned in research remain their owners' marks.

## JUCE 7.0.12

The default build fetches JUCE from the official repository, pinned to commit
`4f43011b96eb0636104cb3e433894cda98243626` (release 7.0.12). JUCE offers GPLv3 or
JUCE commercial/personal licensing options; some core modules use ISC. The default
open-source distribution of the combined Tideglass/JUCE plug-in uses GPLv3.
The MIT license for original
Tideglass files does not remove the combined work's JUCE licensing obligations.

The upstream license notice is preserved in `docs/licenses/JUCE-7.0.12-LICENSE.md`.
GPLv3 is preserved in `docs/licenses/GPL-3.0.txt`. Distribution of the default
compiled product must include its corresponding source and applicable notices.
The packaging script creates a `*Corresponding-Source.tar.gz` archive beside
the installer, including the source tree of JUCE used in that build. Distribute
both files together. The Mac Build Kit ZIP also includes the pinned JUCE tree under `vendor/JUCE`.

For a proprietary distribution, obtain and comply with the applicable JUCE license
and all SDK/dependency licenses; this project does not grant those rights.

Sources: [pinned JUCE license](https://github.com/juce-framework/JUCE/blob/4f43011b96eb0636104cb3e433894cda98243626/LICENSE.md),
[JUCE 7 license terms](https://www.juce.com/juce-7-licence).

## Bundled VST3 SDK and other dependencies

The VST3 SDK shipped in this pinned JUCE release offers GPLv3 or the Steinberg
proprietary VST3 license. This project's default open-source build uses the GPLv3
option. Preserve
`docs/licenses/VST3-SDK-LICENSE.txt` and `docs/licenses/GPL-3.0.txt`. Do not assume
that a different license in a newer SDK retroactively applies to this pinned copy.

JUCE also embeds dependencies including PNG/zlib, JPEG, and FLAC/Ogg Vorbis.
Actual compiled dependencies vary by platform and enabled modules. Their original
source headers and license files are preserved with the complete JUCE source in
the corresponding-source archive. Consult those embedded notices for the terms
of each component; the archive also includes source components that this project
does not compile (for example AAX and Android components).

The build disables JUCE's web browser and curl options. It fetches no commercial
plug-in assets and contains no paid SDK credentials or signing keys.

## Build tools

The Mac Build Kit includes the unmodified official CMake 3.31.8 universal archive
as a separate build tool. Its copyright and bundled dependency notices remain
inside that archive. It is not linked into the plugin. The bootstrap verifies
SHA-256 `d1449f969c54d5c00886d5b643340d493dfb3c81cb39ee29b35453395c11ebf7` before extraction.
Source: [official CMake release](https://github.com/Kitware/CMake/releases/tag/v3.31.8).

Windows development tests used LLVM-MinGW with static runtime linking. Its
upstream notice is preserved in `docs/licenses/LLVM-MinGW.txt`. No Windows binary
is included in the Mac Build Kit.
