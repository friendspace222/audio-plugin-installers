// Offline, level-independent impulse-response measurements for sonic validation.
// Build from the project root:
// clang++ -std=c++17 -O2 -I Source Source/DSP.cpp tests/reverb_probe.cpp -o reverb_probe
// Scenario0 Hall;1 Cathedral;2 low diffusion;3/4 small/large size;5 short decay;
// 6/7 dark/bright damping;8 100ms predelay;9 mono wet width.
#include "DSP.h"
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <vector>
constexpr double pi=3.14159265358979323846;
constexpr int rate=48000;
struct Audio{std::vector<float> l,r;Audio(int n):l(n),r(n){}};
double energy(const Audio& a,int from,int to){double e=0;for(int i=from;i<to;++i)e+=double(a.l[i])*a.l[i]+double(a.r[i])*a.r[i];return e;}
Audio band(const Audio& a,double low,double high){auto b=a;double hp[2]={},lp[2]={};const double ca=1-std::exp(-2*pi*low/rate),cb=1-std::exp(-2*pi*high/rate);for(std::size_t i=0;i<a.l.size();++i)for(int c=0;c<2;++c){double x=c?a.r[i]:a.l[i];hp[c]+=ca*(x-hp[c]);lp[c]+=cb*(x-hp[c]-lp[c]);(c?b.r[i]:b.l[i])=float(lp[c]);}return b;}
double t20(const Audio& a){double total=energy(a,0,int(a.l.size())),remain=total;int first=-1,last=-1;for(std::size_t i=0;i<a.l.size();++i){double db=10*std::log10(std::max(remain/total,1e-30));if(first<0&&db<=-5)first=int(i);if(db<=-25){last=int(i);break;}remain-=double(a.l[i])*a.l[i]+double(a.r[i])*a.r[i];}return 3.*(last-first)/rate;}
double density(const Audio& a,int from,int to){double sum=0;int windows=0;for(int start=from;start+960<=to;start+=480){double rms=std::sqrt(energy(a,start,start+960)/(1920.));int count=0;for(int i=start;i<start+960;++i){if(std::abs(a.l[i])>rms)++count;if(std::abs(a.r[i])>rms)++count;}sum+=count/1920./0.3173105;++windows;}return sum/windows;}
double corr(const Audio& a,int from,int to){double lr=0,ll=0,rr=0;for(int i=from;i<to;++i){lr+=double(a.l[i])*a.r[i];ll+=double(a.l[i])*a.l[i];rr+=double(a.r[i])*a.r[i];}return lr/std::sqrt(ll*rr);}
int onset(const Audio& a){for(std::size_t i=0;i<a.l.size();++i)if(std::abs(a.l[i])+std::abs(a.r[i])>1e-6)return int(i);return -1;}
int main(){std::cout<<std::fixed<<std::setprecision(4);for(int scenario=0;scenario<10;++scenario){tideglass::Parameters p;p.delayEnabled=false;p.spillover=false;p.reverbMode=scenario==1?4:3;p.reverbMix=1;p.reverbDuck=0;p.reverbMod=0;p.reverbLowCut=80;p.reverbHighCut=12000;p.decay=8;p.size=.8f;p.diffusion=.95f;p.preDelay=0;p.damping=6500;if(scenario==2)p.diffusion=.05f;if(scenario==3)p.size=.1f;if(scenario==4)p.size=.95f;if(scenario==5)p.decay=2;if(scenario==6)p.damping=800;if(scenario==7)p.damping=18000;if(scenario==8)p.preDelay=100;if(scenario==9)p.width=0;tideglass::Engine engine;engine.prepare(rate);engine.setParameters(p);Audio a(rate*15);a.l[0]=a.r[0]=.5f;for(std::size_t i=0;i<a.l.size();i+=512)engine.process(a.l.data()+i,a.r.data()+i,int(std::min<std::size_t>(512,a.l.size()-i)));auto low=band(a,70,250),high=band(a,3000,10000);std::cout<<scenario<<" totalE="<<energy(a,0,int(a.l.size()))<<" onsetms="<<1000.*onset(a)/rate<<" NED50-200="<<density(a,2400,9600)<<" NED120-300="<<density(a,5760,14400)<<" T20="<<t20(a)<<" LF_T20="<<t20(low)<<" HF_T20="<<t20(high)<<" corr="<<corr(a,rate/5,rate*3)<<" lateH_L="<<energy(high,rate,rate*3)/energy(low,rate,rate*3)<<'\n';}}
