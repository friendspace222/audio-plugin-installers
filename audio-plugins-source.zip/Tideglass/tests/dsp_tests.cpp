#include "DSP.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <new>
#include <numeric>
#include <string>
#include <vector>

// Instrument ordinary heap allocation to verify the real-time contract.
static bool trackAllocations = false;
static std::size_t allocationCount = 0;
void* operator new(std::size_t size)
{
    if (trackAllocations) ++allocationCount;
    if (void* p = std::malloc(size ? size : 1)) return p;
    throw std::bad_alloc();
}
void* operator new[](std::size_t size) { return ::operator new(size); }
void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
void operator delete[](void* p, std::size_t) noexcept { std::free(p); }

namespace
{
int checks = 0;
void require(bool ok, const std::string& message)
{
    ++checks;
    if (!ok) { std::cerr << "FAIL: " << message << '\n'; std::exit(1); }
}
double energy(const std::vector<float>& values, std::size_t start = 0)
{
    double result = 0;
    for (std::size_t i = start; i < values.size(); ++i) result += values[i] * values[i];
    return result;
}
int firstSignal(const std::vector<float>& x, float threshold = 1.0e-6f)
{
    for (std::size_t i = 0; i < x.size(); ++i) if (std::abs(x[i]) > threshold) return static_cast<int>(i);
    return -1;
}
void blocks(tideglass::Engine& engine, std::vector<float>& l, std::vector<float>& r, int block = 127)
{
    for (std::size_t start = 0; start < l.size(); start += static_cast<std::size_t>(block))
        engine.process(l.data() + start, r.data() + start,
                       std::min(block, static_cast<int>(l.size() - start)));
}
tideglass::Parameters dryDelay()
{
    tideglass::Parameters p;
    p.reverbEnabled = false; p.spillover = false; p.delayMix = 1;
    p.feedback = 0; p.modDepth = 0; p.delayDuck = 0;
    p.delayLowCut = 10; p.delayHighCut = 22000;
    return p;
}
void testNotesAndTiming()
{
    require(std::abs(tideglass::Engine::noteMilliseconds(3,1,120)-375.0) < 1.0e-9,"dotted eighth is375ms at120BPM");
    require(std::abs(tideglass::Engine::noteMilliseconds(3,2,120)-166.6666666667) < 1.0e-7,"eighth triplet is166.667ms");
    require(std::abs(tideglass::Engine::noteMilliseconds(7,1,20)-36000.0) < 1.0e-9,"longest sync division is36seconds");
    require(std::isfinite(tideglass::Engine::noteMilliseconds(-9,8,std::numeric_limits<double>::quiet_NaN())),"bad tempo sanitized");
    for (const int rate : {32000,44100,48000,96000,192000})
    {
        tideglass::Engine engine; engine.prepare(rate);
        auto p=dryDelay(); p.noteL=3;p.noteR=3;p.rhythmL=1;p.rhythmR=2;
        engine.setParameters(p);
        std::vector<float> l(static_cast<std::size_t>(rate)),r(l.size());l[0]=r[0]=0.5f;
        blocks(engine,l,r);
        const int expectedL=static_cast<int>(rate*0.375),expectedR=static_cast<int>(std::round(rate/6.0));
        require(std::abs(firstSignal(l)-expectedL)<=1,"dotted impulse timing at"+std::to_string(rate));
        require(std::abs(firstSignal(r)-expectedR)<=1,"triplet impulse timing at"+std::to_string(rate));
        require(std::all_of(l.begin(),l.begin()+expectedL-2,[](float x){return x==0.0f;}),"no early digital repeat");
    }
    tideglass::Engine longDelay;longDelay.prepare(8000);
    auto p=dryDelay();p.noteL=p.noteR=7;p.rhythmL=p.rhythmR=1;p.bpm=20;longDelay.setParameters(p);
    std::vector<float> l(288100),r(l.size());l[0]=0.5f;blocks(longDelay,l,r,1024);
    require(firstSignal(l)==288000,"36-second delay is supported without truncation");
}
void testBypassAndReset()
{
    tideglass::Engine engine;engine.prepare(48000);
    tideglass::Parameters p;p.delayEnabled=p.reverbEnabled=false;
    engine.setParameters(p);
    std::vector<float> l(7000),r(l.size());
    for(std::size_t i=0;i<l.size();++i){l[i]=0.2f*std::sin(static_cast<float>(i)*0.17f);r[i]=0.3f*std::cos(static_cast<float>(i)*0.11f);}
    const auto originalL=l,originalR=r;blocks(engine,l,r);
    require(l==originalL&&r==originalR,"both stomps off preserve dry unity and stereo at master100percent");
    p.delayEnabled=p.reverbEnabled=true;p.masterMix=0;engine.reset();engine.setParameters(p);
    l=originalL;r=originalR;blocks(engine,l,r);
    require(l==originalL&&r==originalR,"master zero is sample-exact dry");
    p=dryDelay();p.sync=false;p.timeMsL=p.timeMsR=100;engine.reset();engine.setParameters(p);
    l.assign(2400,0);r.assign(2400,0);l[0]=1;blocks(engine,l,r);
    engine.reset();l.assign(24000,0);r.assign(24000,0);blocks(engine,l,r);
    require(energy(l)+energy(r)==0,"panic logically invalidates all historical audio");
}
void testStereoAndPingPong()
{
    tideglass::Engine engine;engine.prepare(48000);
    auto p=dryDelay();p.sync=false;p.timeMsL=100;p.timeMsR=150;engine.setParameters(p);
    std::vector<float> l(20000),r(l.size());l[0]=0.5f;blocks(engine,l,r);
    require(firstSignal(l)==4800&&energy(r)==0,"digital delay preserves channel separation");
    p.delayMode=3;p.feedback=0.6f;engine.reset();engine.setParameters(p);
    l.assign(26000,0);r.assign(l.size(),0);l[0]=0.5f;blocks(engine,l,r);
    require(firstSignal(l)==4800,"pingpong first repeat is left");
    require(firstSignal(r)==12000,"pingpong crosses feedback to right at summed delay time");
    require(energy(l,16000)>0&&energy(r)>0,"pingpong continues alternating");
}
void testSpillover()
{
    for(bool spill:{false,true})
    {
        tideglass::Engine engine;engine.prepare(48000);
        auto p=dryDelay();p.spillover=spill;p.sync=false;p.timeMsL=p.timeMsR=100;engine.setParameters(p);
        std::vector<float> l(2400),r(l.size());l[0]=0.5f;blocks(engine,l,r);
        p.delayEnabled=false;engine.setParameters(p);
        l.assign(9600,0);r.assign(l.size(),0);blocks(engine,l,r);
        require(spill?energy(l)>0.01:energy(l)<1.0e-12,spill?"delay tail survives stomp with spillover":"delay tail clears when spillover disabled");
    }
    for(bool spill:{false,true})
    {
        tideglass::Engine engine;engine.prepare(48000);
        auto p=dryDelay();p.delayEnabled=false;p.reverbEnabled=true;p.reverbMix=1;p.reverbDuck=0;p.spillover=spill;
        p.preDelay=0;p.reverbMod=0;p.decay=3;engine.setParameters(p);
        std::vector<float> l(24000),r(l.size());l[0]=r[0]=0.5f;blocks(engine,l,r);
        p.reverbEnabled=false;engine.setParameters(p);
        l.assign(48000,0);r.assign(l.size(),0);blocks(engine,l,r);
        require(spill?energy(l,4800)>1.0e-7:energy(l,4800)<1.0e-12,spill?"reverb tail survives stomp":"reverb tail clears with spillover disabled");
    }
}
void testModesAndRouting()
{
    tideglass::Engine engine;engine.prepare(12000);
    std::array<double,6> delaySignatures {};
    std::array<double,8> reverbSignatures {};
    for(int dm=0;dm<6;++dm)for(int rm=0;rm<8;++rm)for(int route=0;route<3;++route)
    {
        tideglass::Parameters p;p.delayMode=dm;p.reverbMode=rm;p.routing=route;
        p.sync=false;p.timeMsL=67;p.timeMsR=91;p.feedback=0.83f;p.decay=8;
        p.delayMix=p.reverbMix=0.6f;p.delayDuck=p.reverbDuck=0;p.preDelay=7;
        engine.reset();engine.setParameters(p);
        std::vector<float> l(16000),r(l.size());l[0]=0.5f;r[11]=-0.35f;
        for(int i=1;i<1800;++i){l[static_cast<std::size_t>(i)]+=0.12f*std::sin(i*0.113f);r[static_cast<std::size_t>(i)]+=0.08f*std::sin(i*0.077f);}
        blocks(engine,l,r,173);
        require(std::all_of(l.begin(),l.end(),[](float x){return std::isfinite(x)&&std::abs(x)<4;}),"left stability mode"+std::to_string(dm)+"/"+std::to_string(rm)+"/"+std::to_string(route));
        require(std::all_of(r.begin(),r.end(),[](float x){return std::isfinite(x)&&std::abs(x)<4;}),"right stability across modes/routing");
        require(energy(l,3000)+energy(r,3000)>1.0e-10,"audible effect tail across mode/routing matrix");
        if(rm==3&&route==0)delaySignatures[static_cast<std::size_t>(dm)]=energy(l,3000);
        if(dm==0&&route==0)reverbSignatures[static_cast<std::size_t>(rm)]=energy(r,3000);
    }
    for(std::size_t i=0;i<delaySignatures.size();++i)for(std::size_t j=i+1;j<delaySignatures.size();++j)
        require(std::abs(delaySignatures[i]-delaySignatures[j])>1.0e-7,"delay algorithms produce distinct responses");
    for(std::size_t i=0;i<reverbSignatures.size();++i)for(std::size_t j=i+1;j<reverbSignatures.size();++j)
        require(std::abs(reverbSignatures[i]-reverbSignatures[j])>1.0e-7,"reverb algorithms produce distinct responses");
}
void testFreezeAutomationAndBadInput()
{
    tideglass::Engine engine;engine.prepare(48000);
    tideglass::Parameters p;p.delayEnabled=false;p.reverbMix=1;p.reverbDuck=0;p.reverbMod=0;p.preDelay=0;
    p.decay=10;engine.setParameters(p);
    std::vector<float> l(48000),r(l.size());l[0]=r[0]=0.5f;blocks(engine,l,r);
    p.freeze=true;engine.setParameters(p);l.assign(240000,0);r.assign(l.size(),0);blocks(engine,l,r);
    require(energy(l,192000)+energy(r,192000)>1.0e-7,"freeze retains a populated tail");
    require(std::all_of(l.begin(),l.end(),[](float x){return std::isfinite(x)&&std::abs(x)<4;}),"freeze remains bounded");
    p.delayEnabled=true;p.hold=true;p.feedback=std::numeric_limits<float>::infinity();p.decay=std::numeric_limits<float>::quiet_NaN();
    p.timeMsL=-1;p.timeMsR=1.0e20f;p.modDepth=10;p.width=10;engine.setParameters(p);
    l.assign(1024,0);r.assign(1024,0);l[0]=std::numeric_limits<float>::quiet_NaN();r[1]=std::numeric_limits<float>::infinity();
    blocks(engine,l,r);
    require(std::all_of(l.begin(),l.end(),[](float x){return std::isfinite(x);}),"invalid host audio and automation do not poison state");
    for(int i=0;i<40;++i)
    {
        p.delayMode=i%6;p.reverbMode=i%8;p.routing=i%3;p.timeMsL=10.0f+i*37.0f;p.size=static_cast<float>(i%10)*0.1f;
        p.freeze=(i%3)==0;p.hold=(i%4)==0;engine.setParameters(p);
        l.assign(1024,0.1f);r.assign(1024,-0.1f);blocks(engine,l,r);
        require(std::all_of(l.begin(),l.end(),[](float x){return std::isfinite(x)&&std::abs(x)<=32;}),"automated switching bounded");
    }
}
void testBlockInvarianceAndReverbStereo()
{
    tideglass::Parameters p;p.sync=false;p.timeMsL=83;p.timeMsR=121;p.delayDuck=p.reverbDuck=0;
    tideglass::Engine one,two;one.prepare(44100);two.prepare(44100);one.setParameters(p);two.setParameters(p);
    std::vector<float> a(44100),b(a.size());a[0]=b[0]=0.5f;
    auto c=a,d=b;blocks(one,a,b,1);blocks(two,c,d,511);
    require(a==c&&b==d,"DSP is invariant to host block boundaries");
    p.delayEnabled=false;p.reverbMix=1;p.reverbMod=0;one.reset();one.setParameters(p);
    a.assign(44100,0);b.assign(a.size(),0);a[0]=b[0]=0.5f;blocks(one,a,b);
    double difference=0;for(std::size_t i=0;i<a.size();++i)difference+=std::abs(a[i]-b[i]);
    require(energy(a)>0&&energy(b)>0&&difference>0.01,"mono source produces decorrelated stereo reverb");
}
void testDecayDuckingAndAllocation()
{
    tideglass::Engine engine;engine.prepare(24000);
    tideglass::Parameters p;p.delayEnabled=false;p.reverbMix=1;p.reverbDuck=0;p.preDelay=0;p.reverbMod=0;p.size=0.4f;
    std::array<double,2> tailEnergy {};
    for(int i=0;i<2;++i)
    {
        p.decay=i==0?0.3f:6.0f;engine.reset();engine.setParameters(p);
        std::vector<float> l(72000),r(l.size());l[0]=r[0]=0.5f;blocks(engine,l,r);
        tailEnergy[static_cast<std::size_t>(i)]=energy(l,36000)+energy(r,36000);
    }
    require(tailEnergy[1]>1.0e-6&&tailEnergy[1]>tailEnergy[0]*1000,"longer decay creates a substantially longer tail");
    std::array<double,2> duckEnergy {};
    for(int i=0;i<2;++i)
    {
        p=dryDelay();p.sync=false;p.timeMsL=p.timeMsR=100;p.delayDuck=static_cast<float>(i);
        engine.reset();engine.setParameters(p);
        std::vector<float> l(24000),r(l.size());
        for(std::size_t n=0;n<l.size();++n)l[n]=r[n]=0.5f*std::sin(static_cast<float>(n)*0.115f);
        blocks(engine,l,r);duckEnergy[static_cast<std::size_t>(i)]=energy(l,12000);
    }
    require(duckEnergy[1]<duckEnergy[0]*0.15,"delay ducking lowers wet energy under active source");
    p=tideglass::Parameters{};engine.reset();engine.setParameters(p);
    std::array<float,256> left {},right {};left[0]=right[0]=0.5f;
    allocationCount=0;trackAllocations=true;
    for(int i=0;i<100;++i)
    {
        p.delayMode=i%6;p.reverbMode=i%8;p.routing=i%3;
        engine.setParameters(p);engine.process(left.data(),right.data(),static_cast<int>(left.size()));
        if(i==50)engine.reset();
    }
    trackAllocations=false;
    require(allocationCount==0,"process,parameter changes and panic allocate no heap memory");
}
void testSmoothStompAndShimmerFreeze()
{
    tideglass::Engine engine;engine.prepare(48000);
    auto p=dryDelay();p.sync=false;p.timeMsL=p.timeMsR=100;p.spillover=true;engine.setParameters(p);
    std::vector<float> l(24000),r(l.size());
    constexpr double tau=6.2831853071795864769;
    for(int i=0;i<24000;++i)l[static_cast<std::size_t>(i)]=r[static_cast<std::size_t>(i)]=static_cast<float>(0.5*std::cos(tau*1000*i/48000));
    blocks(engine,l,r);
    p.delayEnabled=false;engine.setParameters(p);
    l.assign(7200,0);r.assign(l.size(),0);
    for(int i=0;i<7200;++i)l[static_cast<std::size_t>(i)]=r[static_cast<std::size_t>(i)]=static_cast<float>(0.5*std::cos(tau*1000*(i+24000)/48000));
    const auto reference=l;blocks(engine,l,r);
    float maximumStep=0;
    for(std::size_t i=4776;i<4825;++i)
        maximumStep=std::max(maximumStep,std::abs((l[i]-reference[i])-(l[i-1]-reference[i-1])));
    require(maximumStep<0.15f,"stomp fades source injection without a delayed waveform-cut click");
    p=tideglass::Parameters{};p.delayEnabled=false;p.spillover=false;p.reverbMode=6;p.reverbMix=1;p.reverbDuck=0;
    p.reverbMod=0;p.preDelay=0;p.decay=6;p.damping=12000;p.reverbHighCut=16000;p.reverbLowCut=20;
    engine.reset();engine.setParameters(p);l.assign(48000,0);r.assign(l.size(),0);
    for(int i=0;i<24000;++i)
    {
        const double envelope=std::pow(std::sin(tau*0.5*i/24000),2);
        l[static_cast<std::size_t>(i)]=static_cast<float>(0.12*envelope*(std::sin(tau*220*i/48000)+0.6*std::sin(tau*554.365*i/48000)));
        r[static_cast<std::size_t>(i)]=static_cast<float>(0.12*envelope*(std::sin(tau*330*i/48000)+0.6*std::sin(tau*659.255*i/48000)));
    }
    blocks(engine,l,r);p.freeze=true;engine.setParameters(p);l.assign(288000,0);r.assign(l.size(),0);blocks(engine,l,r);
    auto windowEnergy=[&](std::size_t begin,std::size_t end)
    {
        double sum=0;for(std::size_t i=begin;i<end;++i)sum+=static_cast<double>(l[i])*l[i]+static_cast<double>(r[i])*r[i];return sum;
    };
    const double earlier=windowEnergy(24000,72000),later=windowEnergy(192000,240000);
    require(earlier>1.0e-6&&later/earlier>0.5&&later/earlier<2.0,"Shimmer Freeze retains energy within3dB over several seconds");
}
void testDriveAliasing()
{
    tideglass::Engine engine;engine.prepare(48000);
    auto p=dryDelay();p.sync=false;p.timeMsL=p.timeMsR=10;p.driveDb=18;engine.setParameters(p);
    constexpr double tau=6.2831853071795864769;
    std::vector<float> l(96000),r(l.size());
    for(std::size_t i=0;i<l.size();++i)l[i]=r[i]=static_cast<float>(0.7*std::sin(tau*7000*static_cast<double>(i)/48000));
    blocks(engine,l,r);
    auto amplitude=[&](double hz)
    {
        double real=0,imaginary=0;
        for(std::size_t i=0;i<48000;++i)
        {
            const double phase=tau*hz*static_cast<double>(i)/48000;
            real+=l[i+48000]*std::cos(phase);imaginary-=l[i+48000]*std::sin(phase);
        }
        return std::hypot(real,imaginary);
    };
    const double fundamental=amplitude(7000);
    require(fundamental>0&&amplitude(13000)/fundamental<0.06,"ADAA reduces fifth-harmonic foldback below-24dBc in7kHz drive probe");
    require(amplitude(1000)/fundamental<0.015,"ADAA reduces seventh-harmonic foldback below-36dBc in7kHz drive probe");
}
}

int main()
{
    testNotesAndTiming();testBypassAndReset();testStereoAndPingPong();testSpillover();
    testModesAndRouting();testFreezeAutomationAndBadInput();testBlockInvarianceAndReverbStereo();testDecayDuckingAndAllocation();
    testSmoothStompAndShimmerFreeze();
    testDriveAliasing();
    std::cout<<"PASS: "<<checks<<" DSP checks (timing,36s sync,stereo,144 mode/routing combinations,bypass,tails,freeze,automation,block invariance).\n";
    return 0;
}
