// Repeatable, original synthetic source, stereo PCM16 WAV demos and DSP review.
// Build from project root: clang++ -std=c++17 -O2 -static -I Source
//   Source/DSP.cpp tests/render_demo.cpp -o render_demo
// Run: ./render_demo demos
#include "DSP.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

namespace
{
constexpr double pi = 3.14159265358979323846;
constexpr int sr = 48000;
struct Audio { std::vector<float> l, r; explicit Audio(int n) : l(n), r(n) {} };
double peak(const Audio& x)
{
    double p = 0;
    for (std::size_t i=0;i<x.l.size();++i) p=std::max(p,std::max(std::abs(static_cast<double>(x.l[i])),std::abs(static_cast<double>(x.r[i]))));
    return p;
}
double energy(const Audio& x,int begin,int end)
{
    double e=0;end=std::min(end,static_cast<int>(x.l.size()));
    for(int i=begin;i<end;++i)e+=static_cast<double>(x.l[i])*x.l[i]+static_cast<double>(x.r[i])*x.r[i];
    return e;
}
void run(tideglass::Engine& engine,Audio& x)
{
    for(std::size_t start=0;start<x.l.size();start+=256)
        engine.process(x.l.data()+start,x.r.data()+start,static_cast<int>(std::min<std::size_t>(256,x.l.size()-start)));
}
Audio render(const Audio& source,const tideglass::Parameters& p)
{
    auto out=source;tideglass::Engine engine;engine.prepare(sr);engine.setParameters(p);run(engine,out);return out;
}
void u16(std::ofstream& f,std::uint16_t v){f.put(static_cast<char>(v&255));f.put(static_cast<char>((v>>8)&255));}
void u32(std::ofstream& f,std::uint32_t v){u16(f,static_cast<std::uint16_t>(v&65535));u16(f,static_cast<std::uint16_t>(v>>16));}
void wav(const std::filesystem::path& path,const Audio& audio,double gain)
{
    std::ofstream out(path,std::ios::binary);
    if(!out)throw std::runtime_error("Cannot write "+path.string());
    const auto size=static_cast<std::uint32_t>(audio.l.size()*4);
    out.write("RIFF",4);u32(out,size+36);out.write("WAVEfmt ",8);u32(out,16);u16(out,1);u16(out,2);
    u32(out,sr);u32(out,sr*4);u16(out,4);u16(out,16);out.write("data",4);u32(out,size);
    std::uint32_t rng=0x71de61a5u;
    auto uniform=[&](){rng=1664525u*rng+1013904223u;return static_cast<double>(rng)/4294967296.0;};
    auto sample=[&](float x)
    {
        // Fixed-seed TPDF dither at one quantization step, except digital silence.
        const double dither=std::abs(x)>1.0e-10f?uniform()-uniform():0.0;
        const double value=std::max(-32768.0,std::min(32767.0,std::round(x*gain*32767.0+dither)));
        u16(out,static_cast<std::uint16_t>(static_cast<std::int16_t>(value)));
    };
    for(std::size_t i=0;i<audio.l.size();++i){sample(audio.l[i]);sample(audio.r[i]);}
}
Audio makeSource()
{
    Audio source(sr*12);
    const int chords[4][4]={{57,60,64,71},{53,57,60,64},{48,55,59,62},{55,60,62,67}};
    for(int chord=0;chord<4;++chord)for(int voice=0;voice<4;++voice)
    {
        const double start=0.15+chord*1.5+voice*0.105;
        const double f=440.0*std::pow(2.0,(chords[chord][voice]-69)/12.0);
        const double pan=0.20+voice*0.20;
        const double left=std::cos(pan*pi*0.5),right=std::sin(pan*pi*0.5);
        for(int i=static_cast<int>(start*sr);i<static_cast<int>((start+3.2)*sr)&&i<sr*8;++i)
        {
            const double t=static_cast<double>(i)/sr-start;
            const double attack=1.0-std::exp(-t/0.0015);
            double x=0;
            for(int harmonic=1;harmonic<=9;++harmonic)
            {
                const double life=1.25/(1.0+0.43*(harmonic-1));
                const double partial=std::sin(2*pi*f*harmonic*t+0.013*harmonic*harmonic);
                x+=partial*std::exp(-t/life)/std::pow(harmonic,1.5);
            }
            // A faint, smoothly enveloped sine layer gives the delays musical sustain.
            x+=0.08*std::sin(2*pi*f*0.997*t)*(1.0-std::exp(-t/0.08))*std::exp(-t/0.7);
            x*=attack*0.14;
            const double fade=std::min(1.0,std::max(0.0,(3.2-t)/0.12));
            source.l[i]+=static_cast<float>(x*left*fade);source.r[i]+=static_cast<float>(x*right*fade);
        }
    }
    const double gain=std::pow(10.0,-8.0/20.0)/peak(source);
    for(std::size_t i=0;i<source.l.size();++i){source.l[i]*=static_cast<float>(gain);source.r[i]*=static_cast<float>(gain);}
    return source;
}
double t20(const Audio& response)
{
    std::vector<double> integrated(response.l.size());double total=0;
    // Schroeder integration of the full stereo impulse response, no noise floor.
    for(std::size_t i=response.l.size();i-->0;)
    {
        total+=static_cast<double>(response.l[i])*response.l[i]+static_cast<double>(response.r[i])*response.r[i];
        integrated[i]=total;
    }
    int first=-1,last=-1;
    for(std::size_t i=0;i<integrated.size();++i)
    {
        const double db=10*std::log10(std::max(1e-30,integrated[i]/std::max(total,1e-30)));
        if(first<0&&db<=-5)first=static_cast<int>(i);
        if(db<=-25){last=static_cast<int>(i);break;}
    }
    return first>=0&&last>first?3.0*(last-first)/sr:0;
}
double frequencyAmplitude(const Audio& audio,int start,int length,double hz)
{
    double real=0,imag=0;
    for(int i=0;i<length;++i)
    {
        const double phase=2*pi*hz*i/sr;
        real+=audio.l[start+i]*std::cos(phase);imag-=audio.l[start+i]*std::sin(phase);
    }
    return 2.0*std::hypot(real,imag)/length;
}
std::string review()
{
    std::ostringstream out;out<<std::fixed<<std::setprecision(3);
    out<<"Tideglass DSP engineering measurements\n48 kHz, offline stereo; this machine only.\n\n";
    out<<"Freeze: energy change from seconds 0-1 to seconds 4-5 after activation (dB).\n";
    const char* names[8]={"Room","Chamber","Plate","Hall","Cathedral","Spring","Shimmer","Gated"};
    tideglass::Engine engine;engine.prepare(sr);
    for(int mode=0;mode<8;++mode)
    {
        tideglass::Parameters p;p.delayEnabled=false;p.spillover=false;p.reverbMode=mode;p.reverbMix=1;p.reverbDuck=0;p.reverbMod=0;
        p.preDelay=0;p.decay=6;p.damping=12000;p.reverbHighCut=16000;p.reverbLowCut=20;
        engine.reset();engine.setParameters(p);Audio excitation(sr);
        for(int i=0;i<sr/2;++i)
        {
            const double env=std::pow(std::sin(pi*i/(sr/2)),2);
            excitation.l[i]=static_cast<float>(0.12*env*(std::sin(2*pi*220*i/sr)+0.6*std::sin(2*pi*554.365*i/sr)));
            excitation.r[i]=static_cast<float>(0.12*env*(std::sin(2*pi*330*i/sr)+0.6*std::sin(2*pi*659.255*i/sr)));
        }
        run(engine,excitation);p.freeze=true;engine.setParameters(p);Audio tail(sr*6);run(engine,tail);
        const double ratio=energy(tail,sr*4,sr*5)/std::max(1e-30,energy(tail,0,sr));
        out<<names[mode]<<": "<<10*std::log10(std::max(1e-30,ratio))<<" dB; peak="<<peak(tail)<<'\n';
    }
    out<<"\nNominal decay 6 s; full-band Schroeder T20 extrapolated RT60 (s), default voicing except modulation/ducking 0, pre-delay 0.\n";
    for(int mode=0;mode<8;++mode)
    {
        tideglass::Parameters p;p.delayEnabled=false;p.spillover=false;p.reverbMode=mode;p.reverbMix=1;p.reverbDuck=0;p.reverbMod=0;p.preDelay=0;p.decay=6;
        engine.reset();engine.setParameters(p);Audio impulse(sr*12);impulse.l[0]=impulse.r[0]=0.5f;run(engine,impulse);
        out<<names[mode]<<": "<<t20(impulse)<<" s\n";
    }
    out<<"\nDrive alias probe: 7 kHz sine, 0.7 peak, Digital, wet 100%, drive 18 dB, high cut 22 kHz, feedback 0.\n";
    out<<"Drive uses first-order antiderivative antialiasing; it is not oversampled or free of aliasing.\n";
    tideglass::Parameters p;p.reverbEnabled=false;p.spillover=false;p.delayMix=1;p.delayDuck=0;p.modDepth=0;p.sync=false;
    p.timeMsL=p.timeMsR=10;p.feedback=0;p.delayLowCut=10;p.delayHighCut=22000;p.driveDb=18;
    Audio tone(sr*2);for(int i=0;i<sr*2;++i)tone.l[i]=tone.r[i]=static_cast<float>(0.7*std::sin(2*pi*7000*i/sr));
    engine.reset();engine.setParameters(p);run(engine,tone);
    const double fundamental=frequencyAmplitude(tone,sr,sr,7000);
    out<<"13 kHz fifth-harmonic foldback: "<<20*std::log10(std::max(1e-30,frequencyAmplitude(tone,sr,sr,13000)/fundamental))<<" dBc\n";
    out<<"1 kHz seventh-harmonic foldback: "<<20*std::log10(std::max(1e-30,frequencyAmplitude(tone,sr,sr,1000)/fundamental))<<" dBc\n";
    out<<"\nWorst-feature benchmark: Reverse + Shimmer, drive 24 dB, modulation 100%, both wet 75%, 10 s stereo.\n";
    p=tideglass::Parameters{};p.delayMode=5;p.reverbMode=6;p.driveDb=24;p.modDepth=p.reverbMod=1;p.delayMix=p.reverbMix=0.75f;
    p.sync=false;p.timeMsL=181;p.timeMsR=253;p.feedback=0.9f;p.decay=12;p.size=1;
    Audio source(sr*10);for(int i=0;i<sr*10;++i){source.l[i]=static_cast<float>(0.1*std::sin(2*pi*330*i/sr));source.r[i]=static_cast<float>(0.1*std::sin(2*pi*440*i/sr));}
    std::array<double,3> seconds {};
    for(std::size_t i=0;i<3;++i)
    {
        auto audio=source;engine.reset();engine.setParameters(p);
        const auto before=std::chrono::steady_clock::now();run(engine,audio);const auto after=std::chrono::steady_clock::now();
        seconds[i]=std::chrono::duration<double>(after-before).count();
        out<<"Run "<<i+1<<": "<<seconds[i]<<" wall seconds ("<<seconds[i]*10<<"% of one core's 10-second budget).\n";
    }
    std::sort(seconds.begin(),seconds.end());out<<"Median CPU time fraction: "<<seconds[1]/10<<" ("<<seconds[1]*10<<"%).\n";
    out<<"Wall time includes no file writing or preparation; it is not a DAW realtime/dropout certification.\n";
    return out.str();
}
}
int main(int argc,char** argv)
{
    try
    {
        const std::filesystem::path directory=argc>1?argv[1]:"demos";std::filesystem::create_directories(directory);
        const auto source=makeSource();
        std::ofstream notes(directory/"README.txt");
        notes<<"Tideglass audio demonstrations\n\nFour stereo 48 kHz / 16-bit WAV files, 12 seconds each.\n"
             <<"The musical source is an original deterministic additive-synthesis plucked chord progression.\n"
             <<"It is not a recording of a guitar, piano, performer, commercial sample, or third-party plugin.\n"
             <<"Source peak is -8 dBFS. All examples use this identical input. No mastering, compression, EQ,\n"
             <<"or output normalization is applied unless a measured peak requires safety attenuation, listed below.\n"
             <<"PCM16 export uses fixed-seed TPDF dither on non-silent samples.\n\n";
        auto save=[&](const std::string& name,const Audio& audio,const std::string& settings)
        {
            const double originalPeak=peak(audio),gain=originalPeak>0.95?0.95/originalPeak:1.0;
            wav(directory/name,audio,gain);
            notes<<name<<"\n"<<settings<<"\nPeak before export: "<<std::fixed<<std::setprecision(2)
                 <<20*std::log10(std::max(originalPeak,1e-30))<<" dBFS; export gain: "<<20*std::log10(gain)<<" dB.\n\n";
            std::cout<<"Wrote "<<name<<" (peak "<<20*std::log10(std::max(originalPeak,1e-30))<<" dBFS).\n";
        };
        save("01-Dry-Synthetic-Plucks.wav",source,"Dry reference.");
        tideglass::Parameters p;p.delayMode=1;p.reverbMode=2;p.sync=false;p.timeMsL=375;p.timeMsR=500;p.feedback=0.48f;
        p.delayMix=0.30f;p.driveDb=6;p.modDepth=0.26f;p.delayHighCut=7200;p.reverbMix=0.29f;p.decay=3.8f;p.size=0.68f;
        p.preDelay=18;p.damping=7800;p.reverbMod=0.28f;
        save("02-Tape-and-Plate.wav",render(source,p),"Parallel Tape 375/500 ms, feedback 48%, drive 6 dB, delay mix 30%; Plate 3.8 s, mix 29%.");
        p=tideglass::Parameters{};p.delayMode=3;p.reverbMode=3;p.noteL=3;p.rhythmL=1;p.noteR=4;p.rhythmR=0;p.bpm=120;
        p.feedback=0.47f;p.delayMix=0.35f;p.reverbMix=0.35f;p.decay=4.8f;p.size=0.72f;p.preDelay=32;p.routing=1;
        save("03-Dotted-Ping-Pong-and-Hall.wav",render(source,p),"Delay into Reverb. Ping Pong: dotted eighth 375 ms left/quarter 500 ms right at 120 BPM, feedback 47%, mix 35%; Hall 4.8 s, mix 35%.");
        p=tideglass::Parameters{};p.delayEnabled=false;p.reverbMode=6;p.reverbMix=0.50f;p.decay=8;p.size=0.82f;p.reverbMod=0.32f;
        p.preDelay=40;p.reverbDuck=0.15f;p.width=1.25f;
        save("04-Shimmer-Bloom.wav",render(source,p),"Shimmer, nominal decay 8 s, size 82%, pre-delay 40 ms, reverb mix 50%, width 125%; delay off.");
        notes<<"Regenerate from project root:\nclang++ -std=c++17 -O2 -static -I Source Source/DSP.cpp tests/render_demo.cpp -o render_demo\n"
             <<"./render_demo demos\nOn macOS, omit -static; static system-library linking is unsupported there.\n\n"
             <<"ENGINE-REVIEW.txt contains development measurements, including a machine-specific CPU benchmark.\n";
        const auto report=review();std::ofstream reviewFile(directory/"ENGINE-REVIEW.txt");reviewFile<<report;std::cout<<report;
        return 0;
    }
    catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
