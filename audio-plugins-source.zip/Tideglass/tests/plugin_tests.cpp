#include "PluginProcessor.h"
#include <cmath>
#include <iostream>
#include <stdexcept>

static void check(bool ok,const char* message) { if(!ok) throw std::runtime_error(message); }
static void set(TideglassAudioProcessor& p,const char* id,float value)
{
    auto* parameter=p.parameters.getParameter(id);
    check(parameter!=nullptr,"Missing parameter");
    parameter->setValueNotifyingHost(parameter->convertTo0to1(value));
}
class TestPlayHead : public juce::AudioPlayHead
{
public:
    juce::Optional<PositionInfo> getPosition() const override
    { PositionInfo p;p.setBpm(137.0);p.setIsPlaying(true);return p; }
};
int main(int argc,char** argv)
{
    try
    {
        juce::ScopedJuceInitialiser_GUI initialise;
        TideglassAudioProcessor plugin;
        check(plugin.getParameters().size()==37,"Parameter count changed unexpectedly");
        plugin.prepareToPlay(48000,256);
        juce::AudioBuffer<float> audio(2,256);
        juce::MidiBuffer midi;
        TestPlayHead playHead;
        plugin.setPlayHead(&playHead);
        set(plugin,"delayEnabled",0);set(plugin,"reverbEnabled",0);set(plugin,"spillover",0);
        for(int block=0;block<50;++block)
        {audio.clear();plugin.processBlock(audio,midi);}
        for(int i=0;i<256;++i) {audio.setSample(0,i,0.1f);audio.setSample(1,i,-0.1f);}
        plugin.processBlock(audio,midi);
        check(std::abs(audio.getSample(0,255)-0.1f)<0.0001f,"Both off must pass dry unchanged");
        check(std::abs(plugin.currentBpm.load()-137)<0.001,"Host tempo not used");
        check(plugin.hostTempoActive.load(),"Host tempo flag missing");
        plugin.setPlayHead(nullptr);
        set(plugin,"bpm",93);audio.clear();plugin.processBlock(audio,midi);
        check(std::abs(plugin.currentBpm.load()-93)<0.001,"Fallback tempo not used");
        check(!plugin.hostTempoActive.load(),"Fallback tempo flag incorrect");

        set(plugin,"feedback",72.5f);set(plugin,"reverbMode",6);set(plugin,"rhythmL",2);
        set(plugin,"reverbLowCut",160);set(plugin,"reverbDuck",20);
        juce::MemoryBlock state;plugin.getStateInformation(state);
        set(plugin,"feedback",11);set(plugin,"reverbMode",0);
        set(plugin,"reverbLowCut",80);set(plugin,"reverbDuck",5);
        plugin.setStateInformation(state.getData(),(int)state.getSize());
        check(std::abs(plugin.parameters.getRawParameterValue("feedback")->load()-72.5f)<0.01f,"Feedback state not recalled");
        check((int)plugin.parameters.getRawParameterValue("reverbMode")->load()==6,"Reverb state not recalled");
        check((int)plugin.parameters.getRawParameterValue("rhythmL")->load()==2,"Rhythm state not recalled");
        check(std::abs(plugin.parameters.getRawParameterValue("reverbLowCut")->load()-160)<0.01f
              && std::abs(plugin.parameters.getRawParameterValue("reverbDuck")->load()-20)<0.01f,
              "Older session controls were replaced by new defaults");
        const char invalid[]="invalid data";plugin.setStateInformation(invalid,sizeof(invalid));
        check((int)plugin.parameters.getRawParameterValue("reverbMode")->load()==6,"Malformed state changed values");

        for(int preset=0;preset<plugin.getNumPrograms();++preset)
        {
            plugin.loadFactoryPreset(preset);plugin.requestPanic();
            for(int block=0;block<32;++block)
            {
                for(int i=0;i<256;++i)
                    for(int c=0;c<2;++c) audio.setSample(c,i,block==0&&i==0?0.5f:0.0f);
                plugin.processBlock(audio,midi);
                for(int c=0;c<2;++c) for(int i=0;i<256;++i)
                    check(std::isfinite(audio.getSample(c,i)),"Factory preset returned nonfinite audio");
            }
        }
        // Hosts may exceed their announced block size. The mono path must chunk safely.
        auto layout=plugin.getBusesLayout();
        layout.inputBuses.set(0,juce::AudioChannelSet::mono());
        layout.outputBuses.set(0,juce::AudioChannelSet::mono());
        check(plugin.setBusesLayout(layout),"Mono layout rejected");
        plugin.prepareToPlay(44100,64);
        juce::AudioBuffer<float> mono(1,777);mono.clear();mono.setSample(0,0,0.25f);
        plugin.processBlock(mono,midi);
        for(int i=0;i<777;++i) check(std::isfinite(mono.getSample(0,i)),"Oversized mono block failed");

        layout.outputBuses.set(0,juce::AudioChannelSet::stereo());
        check(plugin.setBusesLayout(layout),"Mono-to-stereo layout rejected");
        plugin.prepareToPlay(48000,256);
        set(plugin,"delayEnabled",0);set(plugin,"reverbEnabled",0);set(plugin,"spillover",0);set(plugin,"outputDb",0);
        audio.clear();audio.setSample(0,0,0.25f);plugin.processBlock(audio,midi);
        check(std::abs(audio.getSample(0,0)-audio.getSample(1,0))<0.0001f,"Mono-to-stereo dry path not duplicated");

        plugin.loadFactoryPreset(0);
        std::unique_ptr<juce::AudioProcessorEditor> editor(plugin.createEditor());
        check(editor!=nullptr && editor->getWidth()>500,"Editor construction failed");
        if(argc>1)
        {
            const juce::File file(juce::String::fromUTF8(argv[1]));
            file.deleteFile();
            auto output=file.createOutputStream();
            check(output!=nullptr,"Could not write editor snapshot");
            juce::PNGImageFormat format;
            check(format.writeImageToStream(editor->createComponentSnapshot(editor->getLocalBounds(),true,1.0f),*output),"Editor PNG rendering failed");
        }
        editor.reset();
        plugin.releaseResources();
        std::cout<<"PASS: 37 parameters, host/fallback tempo, bypass, state recall, 17 factory presets, oversized mono blocks, mono-to-stereo, native editor construction.\n";
        return 0;
    }
    catch(const std::exception& e) {std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}
}
