#!/usr/bin/env python3
"""SIMULATED Apple packaging regression tests (Python 3.8+ + Bash, no extra packages).

Runs the production shell scripts against fixture bundles and fake Apple tools.
This checks control flow, plist handling, payload selection, and failure behavior.
It does NOT validate real pkgbuild, DMGs, signing, installation, or Catalina.
Run: python tests/test_packaging.py
On Windows Git Bash is found automatically; set PACKAGING_TEST_BASH if needed.
Temporary fixtures stay inside workspace/work/packaging-tests and are removed.
"""

import json
import os
from pathlib import Path
import plistlib
import shlex
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unittest


PROJECT = Path(__file__).resolve().parents[1]
WORKSPACE = PROJECT.parents[1] if PROJECT.parent.name == "outputs" else PROJECT
WORK_ROOT = (WORKSPACE / "work" / "packaging-tests").resolve()
BASH = os.environ.get("PACKAGING_TEST_BASH")
if not BASH and os.name == "nt":
    for candidate in (r"C:\Program Files\Git\bin\bash.exe", r"C:\Program Files\Git\usr\bin\bash.exe"):
        if Path(candidate).is_file():
            BASH = candidate
            break
if not BASH:
    BASH = shutil.which("bash")


FAKE_APPLE = r'''
import hashlib, json, os, pathlib, plistlib, re, shlex, shutil, sys
import xml.etree.ElementTree as ET
sys.stdout.reconfigure(newline="\n")
sys.stderr.reconfigure(newline="\n")

def path(value):
    if os.name == "nt" and re.match(r"^/[A-Za-z]/", value):
        value = value[1] + ":" + value[2:]
    return pathlib.Path(value)

tool, args = sys.argv[1], sys.argv[2:]
with path(os.environ["FAKE_LOG"]).open("a", encoding="utf-8") as stream:
    stream.write(json.dumps({"tool": tool, "args": args}) + "\n")
if os.environ.get("FAKE_FAIL") == tool:
    print("SIMULATED failure of " + tool, file=sys.stderr)
    sys.exit(19)

def option(name):
    return args[args.index(name) + 1]

def dump(value, destination):
    path(destination).write_text(json.dumps(value), encoding="utf-8")

def no_relocation(items):
    for item in items:
        assert item["BundleIsRelocatable"] is False, item
        no_relocation(item.get("ChildBundles", []))

if tool == "uname":
    print("Darwin")
elif tool == "lipo":
    print(os.environ.get("FAKE_ARCH", "x86_64"))
elif tool == "otool":
    if "-l" in args:
        print("cmd LC_VERSION_MIN_MACOSX\nversion 10.15\nsdk 10.15")
    else:
        print("/usr/lib/libc++.1.dylib (compatibility version 1.0.0, current version 1.0.0)")
elif tool == "codesign":
    assert path(args[-1]).exists()
elif tool == "ditto":
    source, destination = map(path, args[-2:])
    if source.is_dir():
        shutil.copytree(str(source), str(destination), dirs_exist_ok=True)
    else:
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(source), str(destination))
elif tool == "PlistBuddy":
    command, filename = shlex.split(option("-c")), path(args[-1])
    try:
        with filename.open("rb") as stream:
            data = plistlib.load(stream)
        verb = command[0]
        pieces = [p for p in (command[1] if len(command) > 1 else "").split(":") if p]
        def follow(parts):
            value = data
            for part in parts:
                value = value[int(part)] if isinstance(value, list) else value[part]
            return value
        if verb == "Print":
            value = follow(pieces)
            if isinstance(value, list): print("Array {\n}")
            elif isinstance(value, dict): print("Dict {\n}")
            elif isinstance(value, bool): print(str(value).lower())
            else: print(value)
        else:
            parent, key = follow(pieces[:-1]), pieces[-1]
            if verb == "Set":
                assert key in parent
            elif verb == "Add":
                assert key not in parent and command[2] == "bool"
            else:
                raise AssertionError("Unknown fake PlistBuddy command")
            parent[key] = command[-1].lower() == "true"
            with filename.open("wb") as stream:
                plistlib.dump(data, stream)
    except Exception as error:
        print("SIMULATED PlistBuddy missing/invalid entry: " + str(error), file=sys.stderr)
        sys.exit(1)
elif tool == "pkgbuild":
    root = path(option("--root"))
    if "--analyze" in args:
        mode = os.environ.get("FAKE_ANALYZE", "mixed")
        if mode == "failure":
            sys.exit(21)
        if mode == "malformed":
            path(args[-1]).write_text("not a plist", encoding="utf-8")
        else:
            recognized = []
            if mode != "empty" and (root.name == "app" or mode == "all"):
                bundle_path = next(str(p.relative_to(root)).replace("\\", "/")
                                   for p in root.rglob("*") if p.suffix in (".app", ".component", ".vst3"))
                recognized = [{"RootRelativeBundlePath": bundle_path}]
            with path(args[-1]).open("wb") as stream:
                plistlib.dump(recognized, stream)
    else:
        assert option("--install-location") == "/"
        assert option("--ownership") == "recommended"
        components = None
        if "--component-plist" in args:
            with path(option("--component-plist")).open("rb") as stream:
                components = plistlib.load(stream)
            assert components
            no_relocation(components)
        payload = sorted(str(p.relative_to(root)).replace("\\", "/") for p in root.rglob("*") if p.is_file())
        assert payload
        dump({"identifier": option("--identifier"), "payload": payload, "components": components}, args[-1])
elif tool == "productbuild":
    distribution = path(option("--distribution")).read_text(encoding="utf-8")
    ET.fromstring(distribution)
    package_dir = path(option("--package-path"))
    components = {kind: json.loads((package_dir / (kind + ".pkg")).read_text(encoding="utf-8"))
                  for kind in ("au", "vst3", "app", "docs")}
    dump({"simulation": True, "distribution": distribution, "components": components}, args[-1])
elif tool == "hdiutil":
    if os.environ.get("FAKE_DMG_FAIL") == args[0]:
        sys.exit(22)
    if args[0] == "create":
        assert option("-fs") == "HFS+" and option("-format") == "UDZO"
        source = path(option("-srcfolder"))
        contents = sorted(p.name for p in source.iterdir())
        assert "Install Tideglass.pkg" in contents and "READ ME FIRST.txt" in contents
        assert any(name.endswith("Corresponding-Source.tar.gz") for name in contents)
        dump({"simulation": True, "contents": contents}, args[-1])
    elif args[0] == "verify":
        assert path(args[-1]).is_file()
    else:
        raise AssertionError("Unexpected hdiutil invocation")
elif tool == "shasum":
    assert args[:2] == ["-a", "256"]
    for filename in args[2:]:
        print(hashlib.sha256(path(filename).read_bytes()).hexdigest() + "  " + filename)
elif tool == "open":
    assert path(args[-1]).is_file()
elif tool in ("cmake", "ctest", "clang", "clang++", "xcrun", "xcode-select"):
    print("Forbidden compilation/developer-tool call in package-existing simulation", file=sys.stderr)
    sys.exit(93)
else:
    raise AssertionError("Unexpected fake tool " + tool)
'''


def shell_quote(value):
    return shlex.quote(str(value).replace("\\", "/"))


@unittest.skipUnless(BASH, "Bash required; install Git Bash or set PACKAGING_TEST_BASH")
class SimulatedApplePackaging(unittest.TestCase):
    def setUp(self):
        WORK_ROOT.mkdir(parents=True, exist_ok=True)
        if os.path.commonpath([str(WORK_ROOT), str(WORKSPACE.resolve())]) != str(WORKSPACE.resolve()):
            raise RuntimeError("Refusing work directory outside workspace")
        self.temp = Path(tempfile.mkdtemp(prefix="sim-", dir=str(WORK_ROOT)))
        self.project = self.temp / "Tideglass with spaces"
        self.bin = self.temp / "fake tools"
        self.bin.mkdir()
        self.project.mkdir()
        self.log = self.temp / "calls.jsonl"
        self.env = os.environ.copy()
        for key in ("DEVELOPER_ID_APPLICATION", "DEVELOPER_ID_INSTALLER", "NOTARY_KEYCHAIN_PROFILE",
                    "FAKE_FAIL", "FAKE_DMG_FAIL", "FAKE_ANALYZE", "FAKE_ARCH"):
            self.env.pop(key, None)
        self.env["FAKE_LOG"] = str(self.log)
        fake = self.temp / "fake_apple.py"
        fake.write_text(textwrap.dedent(FAKE_APPLE), encoding="utf-8")
        for name in ("uname", "lipo", "otool", "codesign", "ditto", "PlistBuddy", "pkgbuild", "productbuild",
                     "hdiutil", "shasum", "open", "cmake", "ctest", "clang", "clang++", "xcrun", "xcode-select"):
            wrapper = self.bin / name
            wrapper.write_text("#!/bin/bash\nexport MSYS2_ARG_CONV_EXCL='*'\nexec " + shell_quote(sys.executable)
                               + " " + shell_quote(fake) + " " + shell_quote(name) + ' "$@"\n', encoding="utf-8")
            wrapper.chmod(0o755)
        self.env["FAKE_PLISTBUDDY"] = str(self.bin / "PlistBuddy").replace("\\", "/")
        shutil.copytree(str(PROJECT / "scripts"), str(self.project / "scripts"))
        for name in ("Make-Installer.command", "Build-and-Package.command", "CMakeLists.txt", "LICENSE", "THIRD_PARTY_NOTICES.md"):
            shutil.copy2(str(PROJECT / name), str(self.project / name))
        for folder in ("Source", "tests", "docs", "vendor/JUCE"):
            (self.project / folder).mkdir(parents=True, exist_ok=True)
            (self.project / folder / "fixture.txt").write_text("SIMULATION fixture\n", encoding="utf-8")
        (self.project / "vendor/JUCE/LICENSE.md").write_text("SIMULATION source license\n", encoding="utf-8")
        helper = self.project / "scripts/prepare-component-plist.sh"
        helper.rename(self.project / "scripts/prepare-component-plist.actual.sh")
        helper.write_text('#!/bin/bash\nexec /bin/bash "$(dirname "$0")/prepare-component-plist.actual.sh" "$1" "$FAKE_PLISTBUDDY"\n', encoding="utf-8")
        self.build = self.project / "build/macos-x86_64"
        self.build.mkdir(parents=True)
        (self.build / "tideglass-build-info.txt").write_text("version=0.1.0\narchitecture=x86_64\ndeployment_target=10.15\n", encoding="utf-8")
        (self.build / "CMakeCache.txt").write_text("TIDEGLASS_JUCE_PATH:PATH=" + str(self.project / "vendor/JUCE").replace("\\", "/") + "\n", encoding="utf-8")
        for kind, extension in (("AU", "component"), ("VST3", "vst3"), ("Standalone", "app")):
            binary = self.build / "Tideglass_artefacts/Release" / kind / ("Tideglass." + extension) / "Contents/MacOS/Tideglass"
            binary.parent.mkdir(parents=True)
            binary.write_bytes(b"SIMULATED BINARY - NOT INSTALLABLE\n")
        self.dist = self.project / "dist"
        self.package = self.dist / "Tideglass-0.1.0-macOS-Intel-Unsigned.pkg"

    def tearDown(self):
        resolved = self.temp.resolve()
        if resolved.parent != WORK_ROOT or not resolved.name.startswith("sim-"):
            raise RuntimeError("Refusing cleanup outside validated simulation directory")
        shutil.rmtree(str(resolved))

    def run_script(self, script, *args, **environment):
        env = self.env.copy()
        env.update(environment)
        # Prepend inside Bash: Windows and POSIX PATH separators differ.
        bin_path = str(self.bin).replace("\\", "/")
        if os.name == "nt" and len(bin_path) > 2 and bin_path[1] == ":":
            bin_path = "/" + bin_path[0].lower() + bin_path[2:]
        command = "export PATH=" + shell_quote(bin_path) + ':"$PATH"; exec /bin/bash ' + shell_quote(script)
        command += "".join(" " + shell_quote(arg) for arg in args)
        return subprocess.run([BASH, "-c", command], cwd=str(self.project), env=env,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=120)

    def calls(self, tool=None):
        entries = [json.loads(line) for line in self.log.read_text(encoding="utf-8").splitlines()] if self.log.exists() else []
        return [entry for entry in entries if tool is None or entry["tool"] == tool]

    def helper(self, value):
        filename = self.temp / "component analysis with spaces.plist"
        with filename.open("wb") as stream:
            plistlib.dump(value, stream)
        result = self.run_script(PROJECT / "scripts/prepare-component-plist.sh", filename, self.bin / "PlistBuddy")
        with filename.open("rb") as stream:
            updated = plistlib.load(stream)
        return result, updated

    def assert_success(self, result):
        self.assertEqual(result.returncode, 0, result.stdout)

    def assert_never_opened(self):
        self.assertFalse(self.calls("open"))

    def test_empty_component_array(self):
        result, updated = self.helper([])
        self.assert_success(result)
        self.assertEqual(result.stdout.strip(), "0")
        self.assertEqual(updated, [])

    def test_existing_relocation_flag(self):
        result, updated = self.helper([{"RootRelativeBundlePath": "Applications/Tideglass.app", "BundleIsRelocatable": True}])
        self.assert_success(result)
        self.assertIs(updated[0]["BundleIsRelocatable"], False)
        self.assertEqual(result.stdout.strip(), "1")

    def test_absent_relocation_flag(self):
        result, updated = self.helper([{"RootRelativeBundlePath": "Library/Audio/Plug-Ins/Components/Tideglass.component"}])
        self.assert_success(result)
        self.assertIs(updated[0]["BundleIsRelocatable"], False)

    def test_multiple_and_nested_bundles(self):
        result, updated = self.helper([
            {"RootRelativeBundlePath": "Applications/A.app", "ChildBundles": [
                {"RootRelativeBundlePath": "Applications/A.app/Contents/Frameworks/B.framework", "BundleIsRelocatable": True}]},
            {"RootRelativeBundlePath": "Applications/C.app", "BundleIsRelocatable": False}])
        self.assert_success(result)
        self.assertEqual(result.stdout.strip(), "2")
        self.assertIs(updated[0]["BundleIsRelocatable"], False)
        self.assertIs(updated[0]["ChildBundles"][0]["BundleIsRelocatable"], False)
        self.assertIs(updated[1]["BundleIsRelocatable"], False)

    def test_reject_nonarray_plist(self):
        result, _ = self.helper({"RootRelativeBundlePath": "Applications/A.app"})
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Expected an array", result.stdout)

    def test_reject_missing_bundle_path(self):
        result, _ = self.helper([{"BundleIsRelocatable": True}])
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Missing RootRelativeBundlePath", result.stdout)

    def test_reject_malformed_plist(self):
        filename = self.temp / "broken.plist"
        filename.write_text("not a plist", encoding="utf-8")
        result = self.run_script(PROJECT / "scripts/prepare-component-plist.sh", filename, self.bin / "PlistBuddy")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Cannot read", result.stdout)

    def test_existing_build_creates_complete_pkg_dmg_without_compiler(self):
        result = self.run_script(self.project / "Make-Installer.command")
        self.assert_success(result)
        product = json.loads(self.package.read_text(encoding="utf-8"))
        expected = {"au": "Library/Audio/Plug-Ins/Components/Tideglass.component/Contents/MacOS/Tideglass",
                    "vst3": "Library/Audio/Plug-Ins/VST3/Tideglass.vst3/Contents/MacOS/Tideglass",
                    "app": "Applications/Tideglass.app/Contents/MacOS/Tideglass"}
        for kind, filename in expected.items():
            self.assertIn(filename, product["components"][kind]["payload"])
        self.assertIsNone(product["components"]["au"]["components"])
        self.assertIsNone(product["components"]["vst3"]["components"])
        self.assertIs(product["components"]["app"]["components"][0]["BundleIsRelocatable"], False)
        self.assertTrue(self.package.with_suffix(".dmg").is_file())
        source = next(self.dist.glob("*Corresponding-Source.tar.gz"))
        self.assertGreater(source.stat().st_size, 0)
        import tarfile
        with tarfile.open(str(source)) as archive:
            self.assertTrue(any(name.endswith("/Make-Installer.command") for name in archive.getnames()))
        for forbidden in ("cmake", "ctest", "clang", "clang++", "xcrun", "xcode-select"):
            self.assertFalse(self.calls(forbidden))
        self.assertEqual(len(self.calls("open")), 2)
        self.assertFalse(list(self.dist.glob(".tideglass-package.*")))
        self.assertFalse(list(self.dist.glob(".tideglass-dmg.*")))

    def test_all_empty_analysis_still_packages_payloads(self):
        result = self.run_script(self.project / "Make-Installer.command", FAKE_ANALYZE="empty")
        self.assert_success(result)
        product = json.loads(self.package.read_text(encoding="utf-8"))
        for component in product["components"].values():
            self.assertIsNone(component["components"])
            self.assertTrue(component["payload"])

    def test_all_recognized_analysis_uses_fixed_plists(self):
        result = self.run_script(self.project / "Make-Installer.command", FAKE_ANALYZE="all")
        self.assert_success(result)
        product = json.loads(self.package.read_text(encoding="utf-8"))
        for kind in ("au", "vst3", "app"):
            self.assertIs(product["components"][kind]["components"][0]["BundleIsRelocatable"], False)

    def test_dmg_creation_failure_keeps_pkg_and_opens_installer(self):
        result = self.run_script(self.project / "Make-Installer.command", FAKE_DMG_FAIL="create")
        self.assert_success(result)
        self.assertTrue(self.package.is_file())
        self.assertFalse(self.package.with_suffix(".dmg").exists())
        self.assertIn("Disk-image creation failed", result.stdout)
        self.assertEqual(len(self.calls("open")), 2)

    def test_dmg_verify_failure_keeps_pkg_without_publishing_bad_dmg(self):
        result = self.run_script(self.project / "Make-Installer.command", FAKE_DMG_FAIL="verify")
        self.assert_success(result)
        self.assertTrue(self.package.is_file())
        self.assertFalse(self.package.with_suffix(".dmg").exists())
        self.assertEqual(len(self.calls("open")), 2)

    def test_failed_analysis_never_opens_installer(self):
        result = self.run_script(self.project / "Make-Installer.command", FAKE_ANALYZE="failure")
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(self.package.exists())
        self.assert_never_opened()

    def test_malformed_analysis_never_opens_installer(self):
        result = self.run_script(self.project / "Make-Installer.command", FAKE_ANALYZE="malformed")
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(self.package.exists())
        self.assert_never_opened()

    def test_productbuild_failure_never_opens_stale_installer(self):
        self.dist.mkdir()
        stale = self.dist / "old.pkg"
        stale.write_bytes(b"OLD INSTALLER")
        (self.dist / ".latest-installer").write_text(str(stale).replace("\\", "/") + "\n", encoding="utf-8")
        result = self.run_script(self.project / "Make-Installer.command", FAKE_FAIL="productbuild")
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(self.package.exists())
        self.assertEqual(stale.read_bytes(), b"OLD INSTALLER")
        self.assert_never_opened()

    def test_existing_package_is_not_overwritten(self):
        self.dist.mkdir()
        self.package.write_bytes(b"PRESERVE EXISTING INSTALLER")
        result = self.run_script(self.project / "Make-Installer.command")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.package.read_bytes(), b"PRESERVE EXISTING INSTALLER")
        self.assertIn("Output already exists", result.stdout)
        self.assertFalse(self.calls("productbuild"))
        self.assert_never_opened()

    def test_missing_build_does_not_try_compilation_or_open_installer(self):
        (self.build / "tideglass-build-info.txt").unlink()
        result = self.run_script(self.project / "Make-Installer.command")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("No completed build", result.stdout)
        self.assertFalse(self.calls("cmake"))
        self.assert_never_opened()

    def test_wrong_architecture_stops_before_packaging(self):
        result = self.run_script(self.project / "Make-Installer.command", FAKE_ARCH="arm64")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Architecture mismatch", result.stdout)
        self.assertFalse(self.calls("pkgbuild"))
        self.assert_never_opened()


if __name__ == "__main__":
    print("SIMULATION ONLY: real Apple installer/DMG/Catalina validation is still required.", flush=True)
    unittest.main(verbosity=2)
