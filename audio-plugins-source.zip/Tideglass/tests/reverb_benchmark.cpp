// Offline wall-time throughput, not a realtime DAW/dropout certification.
// Build from the project root:
// clang++ -std=c++17 -O2 -I Source Source/DSP.cpp tests/reverb_benchmark.cpp -o reverb_benchmark
#include "DSP.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <vector>
int main(){std::cout<<std::fixed<<std::setprecision(4);for(int rate:{48000,96000})for(int mode:{3,4,6}){tideglass::Engine engine;engine.prepare(rate);tideglass::Parameters p;p.delayMode=5;p.reverbMode=mode;p.reverbMix=p.delayMix=.75f;p.reverbDuck=p.delayDuck=0;p.modDepth=p.reverbMod=1;p.driveDb=24;p.feedback=.98f;p.diffusion=1;p.decay=30;p.size=1;p.sync=false;p.timeMsL=181;p.timeMsR=253;std::vector<float> sourceL(rate*10),sourceR(rate*10);for(std::size_t i=0;i<sourceL.size();++i){sourceL[i]=float(.1*std::sin(6.283185307179586*330*i/rate));sourceR[i]=float(.1*std::sin(6.283185307179586*440*i/rate));}std::array<double,3> times;double peak=0;for(auto& seconds:times){auto l=sourceL,r=sourceR;engine.reset();engine.setParameters(p);auto begin=std::chrono::steady_clock::now();for(std::size_t i=0;i<l.size();i+=256)engine.process(l.data()+i,r.data()+i,int(std::min<std::size_t>(256,l.size()-i)));seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count();for(float v:l)peak=std::max(peak,std::abs(double(v)));}std::sort(times.begin(),times.end());std::cout<<rate<<" mode="<<mode<<" medianWallSecondsFor10s="<<times[1]<<" percentOfCoreBudget="<<times[1]*10<<" peak="<<peak<<'\n';}}
