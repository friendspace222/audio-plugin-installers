#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_extra/juce_gui_extra.h>

class TideglassAudioProcessor;

class TideglassAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                            private juce::Timer
{
public:
    explicit TideglassAudioProcessorEditor (TideglassAudioProcessor&);
    ~TideglassAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    struct Interface;
    std::unique_ptr<Interface> ui;
    void timerCallback() override;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TideglassAudioProcessorEditor)
};
