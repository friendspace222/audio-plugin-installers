#include "PluginEditor.h"
#include "PluginProcessor.h"
#include <cmath>
#include <vector>

namespace
{
const juce::Colour background { 0xff0b131b };
const juce::Colour surface { 0xff121f29 };
const juce::Colour raised { 0xff1a2a36 };
const juce::Colour edge { 0xff2b3c48 };
const juce::Colour ink { 0xffe6ecec };
const juce::Colour quiet { 0xff8fa5b4 };
const juce::Colour echo { 0xff62dfcf };
const juce::Colour space { 0xffedb27c };

juce::Font face (float height, bool bold = false)
{
    return juce::Font (height, bold ? juce::Font::bold : juce::Font::plain);
}

void drawTextLabel (juce::Graphics& g, const juce::String& value, juce::Rectangle<int> bounds,
           float height, juce::Colour colour, juce::Justification align = juce::Justification::centredLeft,
           bool bold = false)
{
    g.setColour (colour);
    g.setFont (face (height, bold));
    g.drawText (value, bounds, align);
}

class TideglassLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    TideglassLookAndFeel()
    {
        setColour (juce::PopupMenu::backgroundColourId, surface);
        setColour (juce::PopupMenu::textColourId, ink);
        setColour (juce::PopupMenu::highlightedBackgroundColourId, raised.brighter (0.15f));
        setColour (juce::PopupMenu::highlightedTextColourId, echo);
        setColour (juce::TooltipWindow::backgroundColourId, raised);
        setColour (juce::TooltipWindow::textColourId, ink);
        setColour (juce::TooltipWindow::outlineColourId, edge);
        setColour (juce::Label::textColourId, ink);
        setColour (juce::ComboBox::textColourId, ink);
        setColour (juce::ComboBox::backgroundColourId, background);
        setColour (juce::ComboBox::outlineColourId, edge);
        setColour (juce::TextButton::buttonColourId, raised);
        setColour (juce::TextButton::buttonOnColourId, echo);
        setColour (juce::TextButton::textColourOffId, quiet);
        setColour (juce::TextButton::textColourOnId, ink);
        setColour (juce::Slider::textBoxTextColourId, ink);
        setColour (juce::Slider::textBoxBackgroundColourId, juce::Colours::transparentBlack);
        setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        setColour (juce::Slider::textBoxHighlightColourId, echo.withAlpha (0.25f));
    }

    juce::Font getComboBoxFont (juce::ComboBox&) override { return face (13.0f); }
    juce::Font getLabelFont (juce::Label& label) override { return label.getFont(); }
    juce::Font getTextButtonFont (juce::TextButton&, int) override { return face (11.0f, true); }

    juce::Label* createSliderTextBox (juce::Slider& slider) override
    {
        // Keep JUCE's slider-label accessibility and editing behavior, but give
        // both display and edit states a consistent, restrained inset surface.
        auto* label = juce::LookAndFeel_V4::createSliderTextBox (slider);
        const auto accent = slider.findColour (juce::Slider::rotarySliderFillColourId);
        label->getProperties().set ("tideglassValue", true);
        label->setFont (face (12.0f));
        label->setBorderSize (juce::BorderSize<int> (0, 4, 0, 4));
        label->setColour (juce::Label::textColourId, ink);
        label->setColour (juce::Label::outlineColourId, juce::Colours::transparentBlack);
        label->setColour (juce::Label::backgroundColourId, background);
        label->setColour (juce::Label::textWhenEditingColourId, ink);
        label->setColour (juce::Label::backgroundWhenEditingColourId, background);
        label->setColour (juce::Label::outlineWhenEditingColourId, accent.withAlpha (0.75f));
        label->setColour (juce::TextEditor::textColourId, ink);
        label->setColour (juce::TextEditor::backgroundColourId, background);
        label->setColour (juce::TextEditor::outlineColourId, juce::Colours::transparentBlack);
        label->setColour (juce::TextEditor::focusedOutlineColourId, accent.withAlpha (0.75f));
        label->setColour (juce::TextEditor::highlightColourId, accent.withAlpha (0.25f));
        label->setColour (juce::TextEditor::highlightedTextColourId, ink);
        return label;
    }

    void drawLabel (juce::Graphics& g, juce::Label& label) override
    {
        if (! static_cast<bool> (label.getProperties()["tideglassValue"])
            && dynamic_cast<juce::Slider*> (label.getParentComponent()) == nullptr)
        {
            juce::LookAndFeel_V4::drawLabel (g, label);
            return;
        }

        const auto bounds = label.getLocalBounds().toFloat().reduced (0.5f);
        g.setColour (background.withAlpha (label.isEnabled() ? 0.88f : 0.4f));
        g.fillRoundedRectangle (bounds, 4.5f);
        g.setColour (edge.withAlpha (label.isMouseOverOrDragging() ? 0.95f : 0.48f));
        g.drawRoundedRectangle (bounds, 4.5f, 1.0f);
        if (! label.isBeingEdited())
        {
            g.setFont (face (12.0f));
            g.setColour (ink.withAlpha (label.isEnabled() ? 0.94f : 0.4f));
            g.drawText (label.getText(), label.getLocalBounds().reduced (4, 0), juce::Justification::centred);
        }
    }

    static bool isValueEditor (juce::TextEditor& editor)
    {
        if (auto* label = dynamic_cast<juce::Label*> (editor.getParentComponent()))
            return static_cast<bool> (label->getProperties()["tideglassValue"])
                   || dynamic_cast<juce::Slider*> (label->getParentComponent()) != nullptr;
        return false;
    }

    void fillTextEditorBackground (juce::Graphics& g, int width, int height, juce::TextEditor& editor) override
    {
        if (! isValueEditor (editor))
        {
            juce::LookAndFeel_V4::fillTextEditorBackground (g, width, height, editor);
            return;
        }
        g.setColour (background);
        g.fillRoundedRectangle (0.0f, 0.0f, (float) width, (float) height, 4.5f);
    }

    void drawTextEditorOutline (juce::Graphics& g, int width, int height, juce::TextEditor& editor) override
    {
        if (! isValueEditor (editor))
        {
            juce::LookAndFeel_V4::drawTextEditorOutline (g, width, height, editor);
            return;
        }
        g.setColour (editor.findColour (juce::TextEditor::focusedOutlineColourId));
        g.drawRoundedRectangle (0.5f, 0.5f, (float) width - 1.0f, (float) height - 1.0f, 4.5f, 1.0f);
    }

    void drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                           float position, float startAngle, float endAngle, juce::Slider& slider) override
    {
        const auto area = juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height)
                              .reduced (7.0f);
        const auto radius = juce::jmin (area.getWidth(), area.getHeight()) * 0.5f;
        const auto centre = area.getCentre();
        const auto accent = slider.findColour (juce::Slider::rotarySliderFillColourId)
                                 .withMultipliedAlpha (slider.isEnabled() ? 1.0f : 0.35f);
        const auto angle = startAngle + position * (endAngle - startAngle);
        const auto ring = radius - 1.5f;
        juce::Path track, active;
        track.addCentredArc (centre.x, centre.y, ring, ring, 0.0f, startAngle, endAngle, true);
        active.addCentredArc (centre.x, centre.y, ring, ring, 0.0f, startAngle, angle, true);
        g.setColour (edge);
        g.strokePath (track, juce::PathStrokeType (2.3f));
        g.setColour (accent);
        g.strokePath (active, juce::PathStrokeType (2.3f, juce::PathStrokeType::curved,
                                                 juce::PathStrokeType::rounded));
        for (int i = 0; i <= 10; ++i)
        {
            const auto tickAngle = startAngle + (endAngle - startAngle) * (float) i / 10.0f;
            const auto inner = ring + 4.0f;
            const auto outer = ring + 6.0f;
            g.setColour (edge.brighter (0.15f));
            g.drawLine (centre.x + std::sin (tickAngle) * inner, centre.y - std::cos (tickAngle) * inner,
                        centre.x + std::sin (tickAngle) * outer, centre.y - std::cos (tickAngle) * outer, 1.0f);
        }
        const auto disc = juce::Rectangle<float> (radius * 1.48f, radius * 1.48f).withCentre (centre);
        g.setColour (juce::Colours::black.withAlpha (0.28f));
        g.fillEllipse (disc.translated (0.0f, 2.0f).expanded (1.0f));
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff2b3d49), centre.x, disc.getY(),
                                               juce::Colour (0xff15232e), centre.x, disc.getBottom(), false));
        g.fillEllipse (disc);
        g.setColour (juce::Colour (0xff3b4d59));
        g.drawEllipse (disc.reduced (0.5f), 1.0f);
        g.setColour (accent);
        g.drawLine (centre.x + std::sin (angle) * radius * 0.42f,
                    centre.y - std::cos (angle) * radius * 0.42f,
                    centre.x + std::sin (angle) * radius * 0.63f,
                    centre.y - std::cos (angle) * radius * 0.63f, 2.3f);
        if (slider.hasKeyboardFocus (true))
        {
            g.setColour (accent.withAlpha (0.65f));
            g.drawEllipse (disc.expanded (3.0f), 1.0f);
        }
    }

    void drawLinearSlider (juce::Graphics& g, int x, int y, int width, int height,
                           float sliderPosition, float, float,
                           juce::Slider::SliderStyle, juce::Slider& slider) override
    {
        const auto cy = (float) y + (float) height * 0.5f;
        const auto start = (float) x;
        const auto finish = (float) (x + width);
        g.setColour (edge);
        g.drawLine (start, cy, finish, cy, 3.0f);
        g.setColour (slider.findColour (juce::Slider::trackColourId)
                          .withMultipliedAlpha (slider.isEnabled() ? 1.0f : 0.3f));
        g.drawLine (start, cy, sliderPosition, cy, 3.0f);
        g.fillEllipse (sliderPosition - 4.0f, cy - 4.0f, 8.0f, 8.0f);
    }

    void drawComboBox (juce::Graphics& g, int width, int height, bool, int, int, int, int,
                       juce::ComboBox& box) override
    {
        const auto bounds = juce::Rectangle<float> (0.5f, 0.5f, (float) width - 1.0f, (float) height - 1.0f);
        g.setColour (background);
        g.fillRoundedRectangle (bounds, 6.0f);
        g.setColour (box.hasKeyboardFocus (true) ? echo : edge);
        g.drawRoundedRectangle (bounds, 6.0f, 1.0f);
        juce::Path chevron;
        const auto cx = (float) width - 15.0f;
        const auto cy = (float) height * 0.5f;
        chevron.startNewSubPath (cx - 3.5f, cy - 1.5f);
        chevron.lineTo (cx, cy + 2.0f);
        chevron.lineTo (cx + 3.5f, cy - 1.5f);
        g.setColour (quiet);
        g.strokePath (chevron, juce::PathStrokeType (1.4f));
    }

    void drawButtonBackground (juce::Graphics& g, juce::Button& button, const juce::Colour&,
                               bool highlighted, bool down) override
    {
        auto bounds = button.getLocalBounds().toFloat().reduced (0.5f);
        auto accent = button.findColour (juce::TextButton::buttonOnColourId);
        g.setColour (button.getToggleState() ? accent.withAlpha (down ? 0.22f : 0.12f)
                                             : (highlighted ? raised.brighter (0.12f) : raised));
        g.fillRoundedRectangle (bounds, 6.0f);
        g.setColour ((button.getToggleState() || button.hasKeyboardFocus (true)) ? accent : edge);
        g.drawRoundedRectangle (bounds, 6.0f, 1.0f);
    }
};

void formatSlider (juce::Slider& slider, const juce::String& unit)
{
    slider.textFromValueFunction = [unit] (double value)
    {
        if (unit == "Hz" && value >= 1000.0) return juce::String (value / 1000.0, 1) + " kHz";
        if (unit == "Hz") return juce::String (value, 0) + " Hz";
        if (unit == "rate") return juce::String (value, 2) + " Hz";
        if (unit == "s") return juce::String (value, 2) + " s";
        if (unit == "ms") return juce::String (value, value < 100.0 ? 1 : 0) + " ms";
        if (unit == "dB") return juce::String (value, 1) + " dB";
        if (unit == "BPM") return juce::String (value, 1);
        return juce::String (value, 0) + unit;
    };
    slider.valueFromTextFunction = [unit] (const juce::String& value)
    {
        return value.getDoubleValue() * ((unit == "Hz" && value.containsIgnoreCase ("k")) ? 1000.0 : 1.0);
    };
}

class ParameterControl final : public juce::Component
{
public:
    ParameterControl (juce::AudioProcessorValueTreeState& state, const juce::String& id,
                      const juce::String& name, const juce::String& unit, juce::Colour accent,
                      const juce::String& tip, bool horizontal = false)
        : compact (horizontal)
    {
        label.setText (name, juce::dontSendNotification);
        label.setFont (face (10.5f, true));
        label.setColour (juce::Label::textColourId, quiet);
        label.setJustificationType (compact ? juce::Justification::centredLeft : juce::Justification::centred);
        label.setInterceptsMouseClicks (false, false);
        const auto accessibleName = name.isNotEmpty() ? name : state.getParameter (id)->getName (128);
        slider.setName (accessibleName);
        slider.setTitle (accessibleName);
        slider.setDescription (tip);
        slider.setTooltip (tip + " Double-click to reset; drag or type a value. Shift-drag for fine adjustment.");
        slider.setSliderStyle (compact ? juce::Slider::LinearHorizontal : juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle (compact ? juce::Slider::TextBoxRight : juce::Slider::TextBoxBelow,
                               false, compact ? 80 : 84, 22);
        slider.setColour (juce::Slider::rotarySliderFillColourId, accent);
        slider.setColour (juce::Slider::trackColourId, accent);
        slider.setMouseDragSensitivity (220);
        slider.setWantsKeyboardFocus (true);
        if (auto* parameter = state.getParameter (id))
            slider.setDoubleClickReturnValue (true, parameter->convertFrom0to1 (parameter->getDefaultValue()));
        addAndMakeVisible (label);
        addAndMakeVisible (slider);
        attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (state, id, slider);
        formatSlider (slider, unit);
        slider.updateText();
    }

    void resized() override
    {
        auto bounds = getLocalBounds();
        label.setBounds (bounds.removeFromTop (18));
        slider.setBounds (bounds);
    }

    juce::Slider slider;

private:
    bool compact;
    juce::Label label;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
};

class StompSwitch final : public juce::Button
{
public:
    StompSwitch (const juce::String& name, juce::Colour colour) : juce::Button (name), accent (colour)
    {
        setClickingTogglesState (true);
        setWantsKeyboardFocus (true);
        setTitle (name + " on or off");
        setTooltip ("Toggle " + name.toLowerCase() + ". Enable Tails to let the effect decay naturally when switched off.");
    }

    void paintButton (juce::Graphics& g, bool hover, bool down) override
    {
        auto bounds = getLocalBounds().toFloat().reduced (1.0f);
        const bool on = getToggleState();
        g.setColour (on ? accent.withAlpha (0.07f) : background);
        g.fillRoundedRectangle (bounds, 10.0f);
        g.setColour ((hover || hasKeyboardFocus (true)) ? accent : (on ? accent.withAlpha (0.48f) : edge));
        g.drawRoundedRectangle (bounds, 10.0f, 1.0f);
        const auto centre = juce::Point<float> (37.0f, bounds.getCentreY());
        const auto circle = juce::Rectangle<float> (36.0f, 36.0f).withCentre (centre);
        if (on)
        {
            g.setColour (accent.withAlpha (0.055f));
            g.fillEllipse (circle.expanded (7.0f));
            g.setColour (accent.withAlpha (0.10f));
            g.fillEllipse (circle.expanded (3.0f));
        }
        g.setGradientFill (juce::ColourGradient (raised.brighter (0.12f), circle.getX(), circle.getY(),
                                               background, circle.getX(), circle.getBottom(), false));
        g.fillEllipse (circle.reduced (down ? 2.0f : 0.0f));
        g.setColour (on ? accent : quiet.darker (0.5f));
        g.drawEllipse (circle, 1.5f);
        juce::Path power;
        power.addCentredArc (centre.x, centre.y + 1.0f, 8.0f, 8.0f, 0.0f,
                             0.6f, juce::MathConstants<float>::twoPi - 0.6f, true);
        g.strokePath (power, juce::PathStrokeType (1.7f));
        g.drawLine (centre.x, centre.y - 10.0f, centre.x, centre.y - 1.0f, 1.7f);
        drawTextLabel (g, getButtonText(), { 67, 15, getWidth() - 74, 24 }, 17.0f, on ? ink : quiet, juce::Justification::centredLeft, true);
        drawTextLabel (g, on ? "ENGAGED" : "BYPASSED", { 68, 40, getWidth() - 75, 17 }, 9.5f, on ? accent : quiet);
    }

private:
    juce::Colour accent;
};
}

struct TideglassAudioProcessorEditor::Interface final : public juce::Component
{
    explicit Interface (TideglassAudioProcessorEditor& editor, TideglassAudioProcessor& owner)
        : processor (owner), tooltip (&editor, 750), delaySwitch ("DELAY", echo), reverbSwitch ("REVERB", space)
    {
        setLookAndFeel (&look);
        tooltip.setLookAndFeel (&look);
        setupChoice (delayMode, "delayMode", { "Digital", "Tape", "Analog", "Ping Pong", "Multi Tap", "Reverse" },
                     "Delay character", "Select the echo engine: clean, coloured, bouncing, multi-tap or reverse.");
        setupChoice (reverbMode, "reverbMode", { "Room", "Chamber", "Plate", "Hall", "Cathedral", "Spring", "Shimmer", "Gated" },
                     "Reverb character", "Choose the space and diffusion character.");
        setupChoice (routing, "routing", { "Parallel", "Delay > Reverb", "Reverb > Delay" },
                     "Signal path", "Parallel keeps the engines separate. Serial paths feed the first effect into the second.");
        const juce::StringArray notes { "1/64", "1/32", "1/16", "1/8", "1/4", "1/2", "1/1", "2/1" };
        const juce::StringArray rhythms { "Straight", "Dotted", "Triplet" };
        setupChoice (noteL, "noteL", notes, "Left note division", "Left delay note duration, synchronized to tempo.");
        setupChoice (noteR, "noteR", notes, "Right note division", "Right delay note duration, synchronized to tempo.");
        setupChoice (rhythmL, "rhythmL", rhythms, "Left rhythm", "Straight, dotted (one and a half times), or triplet (two thirds). Times cap at 8 seconds.");
        setupChoice (rhythmR, "rhythmR", rhythms, "Right rhythm", "Straight, dotted (one and a half times), or triplet (two thirds). Times cap at 8 seconds.");
        setupToggle (sync, "sync", "SYNC", echo, "Synchronize echoes to the host tempo. Turn off for independent millisecond times.");
        setupToggle (freeze, "freeze", "FREEZE", space, "Sustain the reverb field. Turn off to return to the normal decay.");
        setupToggle (hold, "hold", "HOLD ECHO", echo, "Sustain the delay buffer. Turn off to return to the normal feedback.");
        setupToggle (tails, "spillover", "TAILS", ink, "Allow existing echo and reverb tails to decay after switching an engine off.");
        addAndMakeVisible (delaySwitch);
        addAndMakeVisible (reverbSwitch);
        buttonAttachments.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.parameters, "delayEnabled", delaySwitch));
        buttonAttachments.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.parameters, "reverbEnabled", reverbSwitch));

        addControl ("feedback", "FEEDBACK", "%", echo, "Amount of echo fed back into the delay; higher values create longer repeats.");
        addControl ("delayMix", "WET MIX", "%", echo, "Delay engine wet/dry balance. Master Mix scales the complete effect.");
        addControl ("driveDb", "DRIVE", "dB", echo, "Drive the delay colour stage for saturation and texture.");
        addControl ("modDepth", "MOD DEPTH", "%", echo, "Depth of delay time modulation.");
        addControl ("delayLowCut", "LOW CUT", "Hz", echo, "Remove low frequencies from the delay feedback path.");
        addControl ("delayHighCut", "HIGH CUT", "Hz", echo, "Soften the high frequencies in delay repeats.");
        addControl ("modRate", "MOD RATE", "rate", echo, "Speed of delay modulation.");
        addControl ("delayDuck", "DUCKING", "%", echo, "Lower echoes while the input plays, allowing them to bloom in the gaps.");
        addControl ("decay", "DECAY", "s", space, "Reverb decay time. Size, damping and the selected algorithm also shape the tail.");
        addControl ("size", "SIZE", "%", space, "Scale the virtual acoustic space.");
        addControl ("preDelay", "PRE-DELAY", "ms", space, "Gap before the reverb arrives, separating the dry attack from the tail.");
        addControl ("reverbMix", "WET MIX", "%", space, "Reverb engine wet/dry balance. For a wet-only send, set this and Master Mix to 100%.");
        addControl ("damping", "DAMPING", "Hz", space, "High-frequency damping inside the reverberation network.");
        addControl ("diffusion", "DIFFUSION", "%", space, "Density and smoothness of the reverb reflections.");
        addControl ("reverbMod", "MODULATION", "%", space, "Motion and variation within the reverberation network.");
        addControl ("reverbDuck", "DUCKING", "%", space, "Reduce the reverb under the input to preserve clarity and let tails bloom.");
        addControl ("reverbLowCut", "LOW CUT", "Hz", space, "Remove low frequencies from the wet reverb output.", true);
        addControl ("reverbHighCut", "HIGH CUT", "Hz", space, "Remove high frequencies from the wet reverb output.", true);
        addControl ("timeMsL", "", "ms", echo, "Left echo time in milliseconds, used when Sync is off.", true);
        addControl ("timeMsR", "", "ms", echo, "Right echo time in milliseconds, used when Sync is off.", true);
        addControl ("bpm", "INTERNAL BPM", "BPM", quiet, "Fallback tempo when the host supplies no tempo. Tap sets this value.", true);
        addControl ("width", "WIDTH", "%", ink, "Stereo width of the wet signal. Zero is mono; 100% is the original width.");
        addControl ("masterMix", "MASTER MIX", "%", ink, "Blend between dry and combined processing. For a wet-only send, set this and at least one active engine Wet Mix to 100%.");
        addControl ("outputDb", "OUTPUT", "dB", ink, "Final output gain. Watch the OUT peak meter to preserve headroom.");

        preset.setName ("Factory preset");
        preset.setTooltip ("Load a factory preset. Saving a user preset also stores every control.");
        preset.addItemList (processor.getFactoryPresetNames(), 1);
        preset.setSelectedItemIndex (processor.getCurrentProgram(), juce::dontSendNotification);
        preset.onChange = [this]
        {
            const int index = preset.getSelectedItemIndex();
            if (index >= 0)
            {
                processor.loadFactoryPreset (index);
                currentProgram = processor.getCurrentProgram();
                status = "FACTORY PRESET";
                repaint();
            }
        };
        addAndMakeVisible (preset);
        setupAction (save, "SAVE", "Save every parameter to a portable Tideglass preset file.", [this] { choosePreset (true); });
        setupAction (load, "LOAD", "Load a saved Tideglass preset file.", [this] { choosePreset (false); });
        setupAction (tap, "TAP", "Tap quarter notes to set the internal tempo. The host tempo takes priority when available.", [this] { processor.tapTempo(); });
        setupAction (panic, "CLEAR TAILS", "Immediately clear delay and reverb memory. Use this to stop held or frozen tails.", [this] { processor.requestPanic(); });
        currentProgram = processor.getCurrentProgram();
        update();
    }

    ~Interface() override
    {
        chooser.reset();
        tooltip.setLookAndFeel (nullptr);
        setLookAndFeel (nullptr);
    }

    void setupChoice (juce::ComboBox& box, const juce::String& id, const juce::StringArray& items,
                      const juce::String& name, const juce::String& tip)
    {
        box.addItemList (items, 1);
        box.setName (name);
        box.setTitle (name);
        box.setTooltip (tip);
        box.setJustificationType (juce::Justification::centredLeft);
        addAndMakeVisible (box);
        comboAttachments.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (processor.parameters, id, box));
    }

    void setupToggle (juce::TextButton& button, const juce::String& id, const juce::String& title,
                      juce::Colour accent, const juce::String& tip)
    {
        button.setButtonText (title);
        button.setClickingTogglesState (true);
        button.setColour (juce::TextButton::buttonOnColourId, accent);
        button.setTooltip (tip);
        addAndMakeVisible (button);
        buttonAttachments.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.parameters, id, button));
    }

    void setupAction (juce::TextButton& button, const juce::String& title, const juce::String& tip,
                      std::function<void()> action)
    {
        button.setButtonText (title);
        button.setTooltip (tip);
        button.onClick = std::move (action);
        addAndMakeVisible (button);
    }

    void addControl (const juce::String& id, const juce::String& title, const juce::String& unit,
                     juce::Colour accent, const juce::String& tip, bool compact = false)
    {
        auto item = std::make_unique<ParameterControl> (processor.parameters, id, title, unit, accent, tip, compact);
        addAndMakeVisible (*item);
        // Slider creates its value Label during construction, before joining
        // this component tree. Explicitly refresh its LookAndFeel now so the
        // editable label is rebuilt with the value-field palette.
        item->slider.setLookAndFeel (&look);
        ids.push_back (id);
        controls.push_back (std::move (item));
    }

    ParameterControl& control (const juce::String& id)
    {
        for (size_t i = 0; i < ids.size(); ++i)
            if (ids[i] == id) return *controls[i];
        jassertfalse;
        return *controls.front();
    }

    float value (const char* id) const
    {
        if (const auto* parameter = processor.parameters.getRawParameterValue (id))
            return parameter->load (std::memory_order_relaxed);
        return 0.0f;
    }

    double delayTime (bool right) const
    {
        if (value ("sync") < 0.5f) return value (right ? "timeMsR" : "timeMsL");
        const double beats[] { 0.0625, 0.125, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0 };
        const double multipliers[] { 1.0, 1.5, 2.0 / 3.0 };
        const auto note = juce::jlimit (0, 7, (int) value (right ? "noteR" : "noteL"));
        const auto rhythm = juce::jlimit (0, 2, (int) value (right ? "rhythmR" : "rhythmL"));
        return juce::jlimit (1.0, 8000.0, 60000.0 / juce::jmax (20.0, processor.currentBpm.load()) * beats[note] * multipliers[rhythm]);
    }

    void update()
    {
        const auto synced = value ("sync") >= 0.5f;
        noteL.setVisible (synced);
        noteR.setVisible (synced);
        rhythmL.setVisible (synced);
        rhythmR.setVisible (synced);
        control ("timeMsL").setVisible (! synced);
        control ("timeMsR").setVisible (! synced);
        const auto externalTempo = processor.hostTempoActive.load();
        control ("bpm").setEnabled (! externalTempo);
        tap.setEnabled (! externalTempo);
        const auto input = juce::jlimit (0.0f, 8.0f, processor.inputPeak.load());
        const auto output = juce::jlimit (0.0f, 8.0f, processor.outputPeak.load());
        inputMeter = juce::jmax (input, inputMeter * 0.87f);
        outputMeter = juce::jmax (output, outputMeter * 0.87f);
        clipFrames = output >= 1.0f ? 36 : juce::jmax (0, clipFrames - 1);
        const auto program = processor.getCurrentProgram();
        if (program != currentProgram)
        {
            currentProgram = program;
            preset.setSelectedItemIndex (program, juce::dontSendNotification);
            status = "FACTORY PRESET";
            repaint (472, 16, 458, 16);
        }
        // Only the schematic, meters and synchronized-time readouts animate.
        // Knobs repaint when changed, keeping idle UI load low in large sessions.
        repaint (28, 102, 1124, 98);
        repaint (48, 284, 500, 22);
    }

    void resized() override
    {
        preset.setBounds (472, 35, 310, 34);
        save.setBounds (794, 35, 64, 34);
        load.setBounds (866, 35, 64, 34);
        panic.setBounds (1014, 35, 138, 34);
        tap.setBounds (145, 134, 60, 32);
        control ("bpm").setBounds (223, 119, 144, 56);
        delayMode.setBounds (256, 235, 216, 34);
        sync.setBounds (486, 235, 70, 34);
        reverbMode.setBounds (828, 235, 210, 34);
        freeze.setBounds (1050, 235, 82, 34);
        noteL.setBounds (48, 314, 94, 32);
        rhythmL.setBounds (150, 314, 128, 32);
        noteR.setBounds (314, 314, 94, 32);
        rhythmR.setBounds (416, 314, 128, 32);
        control ("timeMsL").setBounds (48, 294, 230, 57);
        control ("timeMsR").setBounds (314, 294, 230, 57);
        const char* echoTop[] { "feedback", "delayMix", "driveDb", "modDepth" };
        const char* echoBottom[] { "delayLowCut", "delayHighCut", "modRate", "delayDuck" };
        const char* spaceTop[] { "decay", "size", "preDelay", "reverbMix" };
        const char* spaceBottom[] { "damping", "diffusion", "reverbMod", "reverbDuck" };
        for (int i = 0; i < 4; ++i)
        {
            control (echoTop[i]).setBounds (43 + 131 * i, 369, 112, 115);
            control (echoBottom[i]).setBounds (43 + 131 * i, 503, 112, 115);
            control (spaceTop[i]).setBounds (615 + 131 * i, 292, 112, 119);
            control (spaceBottom[i]).setBounds (615 + 131 * i, 428, 112, 119);
        }
        control ("reverbLowCut").setBounds (621, 564, 239, 52);
        control ("reverbHighCut").setBounds (887, 564, 239, 52);
        delaySwitch.setBounds (44, 669, 198, 70);
        reverbSwitch.setBounds (254, 669, 198, 70);
        routing.setBounds (476, 699, 228, 33);
        hold.setBounds (728, 669, 104, 30);
        tails.setBounds (728, 709, 104, 30);
        control ("width").setBounds (847, 653, 98, 100);
        control ("masterMix").setBounds (945, 653, 98, 100);
        control ("outputDb").setBounds (1043, 653, 98, 100);
    }

    void paint (juce::Graphics& g) override
    {
        g.fillAll (background);
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff132630), 0.0f, 0.0f,
                                               background, 1180.0f, 780.0f, false));
        g.fillRect (getLocalBounds());
        drawMark (g);
        drawTextLabel (g, "TIDEGLASS", { 78, 24, 350, 42 }, 31.0f, ink, juce::Justification::centredLeft, true);
        drawTextLabel (g, "ECHOES INTO ATMOSPHERE", { 80, 67, 350, 17 }, 10.0f, quiet);
        drawTextLabel (g, status, { 473, 16, 455, 15 }, 9.0f, quiet);
        card (g, { 28.0f, 102.0f, 1124.0f, 98.0f });
        card (g, { 28.0f, 216.0f, 548.0f, 420.0f });
        card (g, { 600.0f, 216.0f, 552.0f, 420.0f });
        card (g, { 28.0f, 652.0f, 1124.0f, 102.0f });
        g.setColour (echo.withAlpha (0.6f));
        g.fillRoundedRectangle (48.0f, 238.0f, 3.0f, 29.0f, 1.5f);
        g.setColour (space.withAlpha (0.6f));
        g.fillRoundedRectangle (620.0f, 238.0f, 3.0f, 29.0f, 1.5f);
        drawTextLabel (g, "01", { 62, 235, 28, 17 }, 9.0f, echo);
        drawTextLabel (g, "DELAY", { 62, 249, 178, 25 }, 20.0f, ink, juce::Justification::centredLeft, true);
        drawTextLabel (g, "02", { 634, 235, 28, 17 }, 9.0f, space);
        drawTextLabel (g, "REVERB", { 634, 249, 178, 25 }, 20.0f, ink, juce::Justification::centredLeft, true);
        drawTextLabel (g, "LEFT", { 49, 286, 90, 17 }, 10.0f, quiet, juce::Justification::centredLeft, true);
        drawTextLabel (g, "RIGHT", { 315, 286, 90, 17 }, 10.0f, quiet, juce::Justification::centredLeft, true);
        if (value ("sync") >= 0.5f)
        {
            drawTextLabel (g, juce::String (delayTime (false), 1) + " ms", { 151, 286, 126, 17 }, 10.0f, echo, juce::Justification::centredRight);
            drawTextLabel (g, juce::String (delayTime (true), 1) + " ms", { 417, 286, 126, 17 }, 10.0f, echo, juce::Justification::centredRight);
        }
        g.setColour (edge.withAlpha (0.65f));
        g.drawHorizontalLine (489, 49.0f, 554.0f);
        g.drawHorizontalLine (418, 621.0f, 1130.0f);
        g.drawHorizontalLine (555, 621.0f, 1130.0f);
        drawTextLabel (g, "SIGNAL PATH", { 478, 672, 225, 18 }, 10.0f, quiet, juce::Justification::centredLeft, true);
        drawTextLabel (g, juce::String ("v") + JucePlugin_VersionString + "  /  STEREO / TEMPO-SYNCED", { 31, 759, 350, 15 }, 8.5f, quiet.withAlpha (0.7f));
        drawTextLabel (g, "DOUBLE-CLICK TO RESET  /  TYPE VALUES FOR PRECISION", { 650, 759, 499, 15 },
              8.5f, quiet.withAlpha (0.7f), juce::Justification::centredRight);
        drawOverview (g);
    }

    void card (juce::Graphics& g, juce::Rectangle<float> area)
    {
        g.setColour (juce::Colours::black.withAlpha (0.16f));
        g.fillRoundedRectangle (area.translated (0.0f, 3.0f), 12.0f);
        g.setColour (surface);
        g.fillRoundedRectangle (area, 12.0f);
        g.setColour (edge.withAlpha (0.65f));
        g.drawRoundedRectangle (area.reduced (0.5f), 12.0f, 1.0f);
    }

    void drawMark (juce::Graphics& g)
    {
        juce::Path mark;
        mark.startNewSubPath (31.0f, 35.0f);
        mark.cubicTo (58.0f, 35.0f, 33.0f, 68.0f, 61.0f, 68.0f);
        mark.startNewSubPath (61.0f, 35.0f);
        mark.cubicTo (34.0f, 35.0f, 59.0f, 68.0f, 31.0f, 68.0f);
        g.setGradientFill (juce::ColourGradient (echo, 30.0f, 35.0f, space, 61.0f, 68.0f, false));
        g.strokePath (mark, juce::PathStrokeType (2.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.drawLine (31.0f, 35.0f, 61.0f, 35.0f, 2.2f);
        g.drawLine (31.0f, 68.0f, 61.0f, 68.0f, 2.2f);
    }

    void drawOverview (juce::Graphics& g)
    {
        const auto external = processor.hostTempoActive.load();
        drawTextLabel (g, external ? "HOST TEMPO" : "INTERNAL TEMPO", { 46, 117, 160, 14 }, 9.0f, quiet);
        drawTextLabel (g, juce::String (processor.currentBpm.load(), 1), { 44, 135, 96, 36 }, 26.0f, ink);
        drawTextLabel (g, "BPM", { 47, 175, 100, 13 }, 8.5f, quiet);
        drawTextLabel (g, "RESPONSE SCHEMATIC", { 392, 116, 300, 14 }, 9.0f, quiet);
        drawTextLabel (g, "ECHO", { 778, 116, 70, 14 }, 8.5f, echo);
        drawTextLabel (g, "SPACE", { 859, 116, 70, 14 }, 8.5f, space);
        const float left = 394.0f, right = 982.0f, baseline = 180.0f;
        g.setColour (edge);
        g.drawLine (left, baseline, right, baseline, 1.0f);
        for (int i = 0; i < 9; ++i)
            g.drawLine (left + (right - left) * (float) i / 8.0f, baseline,
                        left + (right - left) * (float) i / 8.0f, baseline - 3.0f, 1.0f);
        const auto repeat = juce::jlimit (0.05f, 0.98f, value ("feedback") * 0.01f);
        const auto enabled = value ("delayEnabled") >= 0.5f;
        const auto spacing = juce::jlimit (16.0f, 89.0f, (float) std::sqrt (delayTime (false)) * 2.2f);
        const auto inputGlow = juce::jlimit (0.0f, 1.0f, inputMeter * 2.0f);
        for (int i = 0; i < 18; ++i)
        {
            const auto x = left + 6.0f + (float) i * spacing;
            if (x > right) break;
            const auto amplitude = 36.0f * std::pow (repeat, (float) i);
            if (amplitude < 0.8f) break;
            g.setColour (echo.withAlpha (enabled ? 0.35f + inputGlow * 0.55f : 0.10f));
            g.fillRoundedRectangle (x, baseline - amplitude, 2.0f, amplitude, 1.0f);
        }
        juce::Path envelope;
        const float pre = juce::jlimit (0.0f, 70.0f, value ("preDelay") * 0.28f);
        const float decayFactor = juce::jmap (value ("decay"), 0.15f, 30.0f, 18.0f, 1.2f);
        envelope.startNewSubPath (left + pre, baseline);
        for (int i = 1; i < 180; ++i)
        {
            const float t = (float) i / 179.0f;
            const float level = 42.0f * (1.0f - std::exp (-t * 55.0f)) * std::exp (-t * decayFactor);
            envelope.lineTo (left + pre + t * (right - left - pre), baseline - level);
        }
        const bool reverbOn = value ("reverbEnabled") >= 0.5f;
        g.setColour (space.withAlpha (reverbOn ? 0.5f + inputGlow * 0.45f : 0.12f));
        g.strokePath (envelope, juce::PathStrokeType (1.5f));
        drawMeter (g, 1010, "IN", inputMeter, false);
        drawMeter (g, 1070, "OUT", outputMeter, clipFrames > 0);
    }

    void drawMeter (juce::Graphics& g, int x, const juce::String& label, float peak, bool clipping)
    {
        const auto db = juce::Decibels::gainToDecibels (peak, -60.0f);
        const auto fraction = juce::jlimit (0.0f, 1.0f, (db + 60.0f) / 60.0f);
        drawTextLabel (g, label, { x, 116, 48, 14 }, 9.0f, quiet, juce::Justification::centred);
        for (int i = 0; i < 12; ++i)
        {
            const auto lit = fraction > (float) i / 12.0f;
            const auto colour = i >= 11 ? juce::Colour (0xfff57d7d) : (i >= 9 ? space : echo);
            g.setColour (lit ? colour : edge.withAlpha (0.7f));
            g.fillRoundedRectangle ((float) x + 12.0f, 169.0f - (float) i * 3.1f, 24.0f, 2.0f, 0.5f);
        }
        drawTextLabel (g, clipping ? "CLIP" : (db <= -59.9f ? "-inf" : juce::String (db, 1)),
              { x - 2, 177, 52, 13 }, 9.0f, clipping ? juce::Colour (0xfff57d7d) : quiet, juce::Justification::centred);
    }

    void choosePreset (bool saving)
    {
        if (chooser != nullptr) return;
        const auto initial = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory)
                                 .getChildFile (saving ? "Tideglass Preset.tideglass" : "");
        chooser = std::make_unique<juce::FileChooser> (saving ? "Save Tideglass preset" : "Load Tideglass preset",
                                                     initial, "*.tideglass", true);
        const int flags = saving ? juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles
                                    | juce::FileBrowserComponent::warnAboutOverwriting
                                 : juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles;
        const juce::Component::SafePointer<Interface> safe (this);
        chooser->launchAsync (flags, [safe, saving] (const juce::FileChooser& dialog)
        {
            if (safe == nullptr) return;
            auto selected = dialog.getResult();
            if (selected != juce::File())
            {
                if (saving)
                {
                    selected = selected.withFileExtension ("tideglass");
                    safe->processor.savePresetToFile (selected);
                    safe->status = selected.existsAsFile() ? "SAVED / " + selected.getFileNameWithoutExtension().toUpperCase()
                                                           : "PRESET COULD NOT BE SAVED";
                }
                else if (safe->processor.loadPresetFromFile (selected))
                {
                    safe->preset.setSelectedId (0, juce::dontSendNotification);
                    safe->preset.setText (selected.getFileNameWithoutExtension(), juce::dontSendNotification);
                    safe->currentProgram = safe->processor.getCurrentProgram();
                    safe->status = "USER PRESET";
                }
                else
                {
                    safe->status = "INVALID OR UNREADABLE PRESET";
                    juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::WarningIcon, "Could not load preset",
                        "This file is not a valid Tideglass preset, or it could not be read.");
                }
                safe->repaint();
            }
            // Destroy the dialog after its own callback has returned.
            juce::MessageManager::callAsync ([safe] { if (safe != nullptr) safe->chooser.reset(); });
        });
    }

    TideglassAudioProcessor& processor;
    TideglassLookAndFeel look;
    juce::TooltipWindow tooltip;
    juce::ComboBox preset, delayMode, reverbMode, routing, noteL, noteR, rhythmL, rhythmR;
    juce::TextButton save, load, tap, panic, sync, freeze, hold, tails;
    StompSwitch delaySwitch, reverbSwitch;
    std::vector<juce::String> ids;
    std::vector<std::unique_ptr<ParameterControl>> controls;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAttachments;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAttachments;
    std::unique_ptr<juce::FileChooser> chooser;
    juce::String status { "FACTORY PRESET" };
    int currentProgram = -1, clipFrames = 0;
    float inputMeter = 0.0f, outputMeter = 0.0f;
};

TideglassAudioProcessorEditor::TideglassAudioProcessorEditor (TideglassAudioProcessor& owner)
    : juce::AudioProcessorEditor (&owner), ui (std::make_unique<Interface> (*this, owner))
{
    setOpaque (true);
    addAndMakeVisible (*ui);
    setResizable (true, true);
    setResizeLimits (944, 624, 1652, 1092);
    getConstrainer()->setFixedAspectRatio (1180.0 / 780.0);
    setSize (1180, 780);
    startTimerHz (24);
}

TideglassAudioProcessorEditor::~TideglassAudioProcessorEditor()
{
    stopTimer();
    ui.reset();
}

void TideglassAudioProcessorEditor::paint (juce::Graphics& g) { g.fillAll (background); }

void TideglassAudioProcessorEditor::resized()
{
    if (ui != nullptr)
    {
        const auto scale = juce::jmin ((float) getWidth() / 1180.0f, (float) getHeight() / 780.0f);
        ui->setTransform (juce::AffineTransform::scale (scale));
        ui->setBounds (0, 0, 1180, 780);
    }
}

void TideglassAudioProcessorEditor::timerCallback() { ui->update(); }
