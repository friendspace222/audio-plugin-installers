#pragma once
#include <JuceHeader.h>
#include "DSP.h"
#include <array>
#include <atomic>

class TideglassAudioProcessor final : public juce::AudioProcessor
{
public:
    TideglassAudioProcessor();
    ~TideglassAudioProcessor() override = default;
    void prepareToPlay(double, int) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Tideglass"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override;
    int getNumPrograms() override;
    int getCurrentProgram() override { return selectedPreset.load(); }
    void setCurrentProgram(int index) override { loadFactoryPreset(index); }
    const juce::String getProgramName(int) override;
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    juce::StringArray getFactoryPresetNames() const;
    void loadFactoryPreset(int);
    void tapTempo();
    void requestPanic() noexcept { panicRequested.store(true); }
    void savePresetToFile(const juce::File&);
    bool loadPresetFromFile(const juce::File&);
    juce::AudioProcessorValueTreeState parameters;
    std::atomic<float> inputPeak{0.0f}, outputPeak{0.0f};
    std::atomic<double> currentBpm{120.0};
    std::atomic<bool> hostTempoActive{false};

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    tideglass::Parameters readParameters() const noexcept;
    bool restoreState(const juce::ValueTree&);
    tideglass::Engine engine;
    juce::AudioBuffer<float> monoScratch;
    std::array<std::atomic<float>*, 37> raw{};
    std::atomic<int> selectedPreset{0};
    std::atomic<bool> panicRequested{false};
    double lastTap = 0.0;
    std::array<double, 4> tapIntervals{};
    int tapCount = 0;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TideglassAudioProcessor)
};
