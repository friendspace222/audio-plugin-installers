#pragma once

#include <memory>

namespace tideglass
{
struct Parameters
{
    bool delayEnabled = true, reverbEnabled = true, sync = true;
    bool hold = false, freeze = false, spillover = true;
    int delayMode = 0, reverbMode = 3, routing = 0;
    int noteL = 4, noteR = 4, rhythmL = 0, rhythmR = 1;
    float bpm = 120.0f, timeMsL = 375.0f, timeMsR = 500.0f;
    float feedback = 0.4f, delayMix = 0.3f;
    float delayLowCut = 120.0f, delayHighCut = 6500.0f, driveDb = 0.0f;
    float modDepth = 0.15f, modRate = 0.4f, delayDuck = 0.2f;
    float decay = 3.5f, size = 0.65f, preDelay = 25.0f, damping = 6500.0f;
    float diffusion = 0.85f, reverbMix = 0.30f;
    float reverbLowCut = 80.0f, reverbHighCut = 9000.0f;
    float reverbMod = 0.2f, reverbDuck = 0.05f;
    float width = 1.0f, masterMix = 1.0f, outputDb = 0.0f;
};

// One instance per audio processor. prepare() allocates; all other operations
// are allocation-free. Call setters, reset and process from the audio thread.
class Engine
{
public:
    Engine();
    ~Engine();
    Engine(Engine&&) noexcept;
    Engine& operator=(Engine&&) noexcept;
    Engine(const Engine&) = delete;
    Engine& operator=(const Engine&) = delete;

    void prepare(double sampleRate);
    void reset();
    void setParameters(const Parameters& parameters);
    void process(float* left, float* right, int numSamples);
    static double noteMilliseconds(int note, int rhythm, double bpm);

private:
    struct Impl;
    std::unique_ptr<Impl> impl;
};
} // namespace tideglass
