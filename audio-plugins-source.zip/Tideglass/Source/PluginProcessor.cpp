#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>
#include <limits>
#include <utility>
#include <vector>

namespace
{
enum ParameterIndex
{
    delayEnabled, reverbEnabled, sync, hold, freeze, spillover,
    delayMode, reverbMode, routing, noteL, noteR, rhythmL, rhythmR,
    bpm, timeMsL, timeMsR, feedback, delayMix, delayLowCut, delayHighCut,
    driveDb, modDepth, modRate, delayDuck, decay, size, preDelay, damping,
    diffusion, reverbMix, reverbLowCut, reverbHighCut, reverbMod, reverbDuck,
    width, masterMix, outputDb, parameterCount
};
constexpr std::array<const char*, parameterCount> ids {
    "delayEnabled", "reverbEnabled", "sync", "hold", "freeze", "spillover",
    "delayMode", "reverbMode", "routing", "noteL", "noteR", "rhythmL", "rhythmR",
    "bpm", "timeMsL", "timeMsR", "feedback", "delayMix", "delayLowCut", "delayHighCut",
    "driveDb", "modDepth", "modRate", "delayDuck", "decay", "size", "preDelay", "damping",
    "diffusion", "reverbMix", "reverbLowCut", "reverbHighCut", "reverbMod", "reverbDuck",
    "width", "masterMix", "outputDb"
};
struct FactoryPreset { const char* name; std::vector<std::pair<const char*, float>> values; };
const std::vector<FactoryPreset>& presets()
{
    static const std::vector<FactoryPreset> all {
        { "01  First Light", {} },
        { "02  Dotted Horizon", {{"delayMode",3},{"noteL",3},{"noteR",3},{"rhythmL",1},{"rhythmR",1},{"feedback",48},{"delayMix",40},{"reverbMode",3},{"reverbMix",18},{"decay",4.2f}} },
        { "03  Tape & Velvet", {{"delayMode",1},{"driveDb",5},{"modDepth",32},{"delayHighCut",4200},{"reverbMode",2},{"decay",2.6f},{"reverbMix",27}} },
        { "04  Vocal Halo", {{"delayDuck",65},{"reverbDuck",55},{"delayMix",20},{"delayHighCut",4200},{"feedback",27},{"reverbMode",2},{"preDelay",65},{"decay",2.2f},{"reverbMix",25},{"reverbLowCut",250}} },
        { "05  Triplet Orbit", {{"delayMode",3},{"rhythmL",2},{"rhythmR",2},{"noteL",4},{"noteR",3},{"feedback",52},{"delayMix",38},{"reverbMode",1},{"reverbMix",19}} },
        { "06  Slap & Spring", {{"sync",0},{"timeMsL",95},{"timeMsR",120},{"delayMode",2},{"feedback",12},{"delayMix",28},{"reverbMode",5},{"decay",1.3f},{"size",35},{"reverbMix",22}} },
        { "07  Small Hours", {{"delayEnabled",0},{"reverbMode",0},{"decay",0.65f},{"size",25},{"preDelay",8},{"reverbMix",22},{"diffusion",60}} },
        { "08  Silver Plate", {{"delayEnabled",0},{"reverbMode",2},{"decay",3.2f},{"preDelay",30},{"reverbMix",32},{"damping",10000},{"reverbMod",12}} },
        { "09  Cathedral Air", {{"delayMix",18},{"feedback",35},{"reverbMode",4},{"decay",9},{"size",95},{"preDelay",45},{"reverbMix",48},{"reverbMod",35},{"routing",1}} },
        { "10  Shimmer Bloom", {{"delayMode",1},{"delayMix",24},{"feedback",48},{"reverbMode",6},{"decay",12},{"size",90},{"reverbMix",55},{"damping",10000},{"routing",1}} },
        { "11  Reverse Constellation", {{"delayMode",5},{"feedback",42},{"delayMix",50},{"reverbMode",3},{"decay",6},{"reverbMix",30},{"routing",1},{"rhythmL",1},{"rhythmR",2}} },
        { "12  Four Head Drift", {{"delayMode",4},{"feedback",55},{"delayMix",42},{"modDepth",40},{"modRate",0.25f},{"reverbMode",1},{"reverbMix",25}} },
        { "13  Gated Chrome", {{"delayEnabled",0},{"reverbMode",7},{"decay",0.8f},{"size",50},{"preDelay",15},{"reverbMix",40},{"damping",11000}} },
        { "14  Chamber Echo", {{"routing",2},{"delayMode",2},{"feedback",44},{"delayMix",38},{"reverbMode",1},{"decay",1.8f},{"reverbMix",32},{"preDelay",15}} },
        { "15  Long Division", {{"noteL",5},{"noteR",6},{"rhythmL",1},{"rhythmR",2},{"feedback",65},{"delayMix",48},{"delayMode",0},{"reverbMix",15},{"delayDuck",40}} },
        { "16  Send / Return", {{"delayMix",100},{"reverbMix",100},{"routing",0},{"outputDb",-6},{"delayDuck",25},{"reverbDuck",25}} }
    };
    return all;
}
}

juce::AudioProcessorValueTreeState::ParameterLayout TideglassAudioProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    auto boolean = [&](const char* id, const char* name, bool def) {
        layout.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID(id,1),name,def));
    };
    auto choice = [&](const char* id, const char* name, juce::StringArray values, int def) {
        layout.add(std::make_unique<juce::AudioParameterChoice>(juce::ParameterID(id,1),name,values,def));
    };
    auto number = [&](const char* id, const char* name, float lo, float hi, float step, float def, float skew, const char* unit) {
        juce::NormalisableRange<float> range(lo,hi,step,skew);
        auto attributes = juce::AudioParameterFloatAttributes().withLabel(unit);
        layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID(id,1),name,range,def,attributes));
    };
    boolean("delayEnabled","Delay active",true); boolean("reverbEnabled","Reverb active",true);
    boolean("sync","Tempo sync",true); boolean("hold","Delay hold",false);
    boolean("freeze","Reverb freeze",false); boolean("spillover","Spillover tails",true);
    choice("delayMode","Delay character",{"Digital","Tape","Analog","Ping Pong","Multi Tap","Reverse"},0);
    choice("reverbMode","Reverb space",{"Room","Chamber","Plate","Hall","Cathedral","Spring","Shimmer","Gated"},3);
    choice("routing","Signal routing",{"Parallel","Delay > Reverb","Reverb > Delay"},0);
    const juce::StringArray notes {"1/64","1/32","1/16","1/8","1/4","1/2","1/1","2/1"};
    const juce::StringArray rhythms {"Straight","Dotted","Triplet"};
    choice("noteL","Left note",notes,4); choice("noteR","Right note",notes,4);
    choice("rhythmL","Left rhythm",rhythms,0); choice("rhythmR","Right rhythm",rhythms,1);
    number("bpm","Internal tempo",20,300,0.1f,120,1,"BPM");
    number("timeMsL","Left time",1,8000,0.1f,375,0.35f,"ms");
    number("timeMsR","Right time",1,8000,0.1f,500,0.35f,"ms");
    number("feedback","Delay feedback",0,98,0.1f,40,1,"%");
    number("delayMix","Delay mix",0,100,0.1f,30,1,"%");
    number("delayLowCut","Delay low cut",20,2000,1,120,0.35f,"Hz");
    number("delayHighCut","Delay high cut",500,20000,1,6500,0.35f,"Hz");
    number("driveDb","Delay drive",0,18,0.1f,0,1,"dB");
    number("modDepth","Delay modulation",0,100,0.1f,15,1,"%");
    number("modRate","Delay mod rate",0.05f,8,0.01f,0.4f,0.4f,"Hz");
    number("delayDuck","Delay ducking",0,100,0.1f,20,1,"%");
    number("decay","Reverb decay",0.15f,30,0.01f,3.5f,0.4f,"s");
    number("size","Reverb size",0,100,0.1f,65,1,"%");
    number("preDelay","Reverb pre-delay",0,250,0.1f,25,0.5f,"ms");
    number("damping","Reverb damping",500,20000,1,6500,0.35f,"Hz");
    number("diffusion","Reverb diffusion",0,100,0.1f,75,1,"%");
    number("reverbMix","Reverb mix",0,100,0.1f,25,1,"%");
    number("reverbLowCut","Reverb low cut",20,2000,1,160,0.35f,"Hz");
    number("reverbHighCut","Reverb high cut",500,20000,1,9000,0.35f,"Hz");
    number("reverbMod","Reverb modulation",0,100,0.1f,20,1,"%");
    number("reverbDuck","Reverb ducking",0,100,0.1f,20,1,"%");
    number("width","Stereo width",0,150,0.1f,100,1,"%");
    number("masterMix","Global mix",0,100,0.1f,100,1,"%");
    number("outputDb","Output gain",-24,12,0.1f,0,1,"dB");
    return layout;
}

TideglassAudioProcessor::TideglassAudioProcessor()
    : AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true)
                                     .withOutput("Output",juce::AudioChannelSet::stereo(),true)),
      parameters(*this,nullptr,"TideglassState",createLayout())
{
    for(size_t i=0;i<ids.size();++i) raw[i]=parameters.getRawParameterValue(ids[i]);
}

bool TideglassAudioProcessor::isBusesLayoutSupported(const BusesLayout& l) const
{
    const auto in=l.getMainInputChannelSet(), out=l.getMainOutputChannelSet();
    return (in==juce::AudioChannelSet::mono() &&
            (out==juce::AudioChannelSet::mono() || out==juce::AudioChannelSet::stereo())) ||
           (in==juce::AudioChannelSet::stereo() && out==juce::AudioChannelSet::stereo());
}
void TideglassAudioProcessor::prepareToPlay(double sampleRate,int maxBlock)
{
    monoScratch.setSize(1,juce::jmax(1,maxBlock));
    engine.prepare(sampleRate);
    engine.setParameters(readParameters());
    inputPeak.store(0); outputPeak.store(0);
}
void TideglassAudioProcessor::releaseResources() { engine.reset(); }

double TideglassAudioProcessor::getTailLengthSeconds() const
{
    const auto p=readParameters();
    if(p.hold || p.freeze) return std::numeric_limits<double>::infinity();
    const double tempo=currentBpm.load(std::memory_order_relaxed);
    const double delaySeconds=0.001*(p.sync
        ? std::max(tideglass::Engine::noteMilliseconds(p.noteL,p.rhythmL,tempo),
                   tideglass::Engine::noteMilliseconds(p.noteR,p.rhythmR,tempo))
        : std::max(p.timeMsL,p.timeMsR));
    const double repeats=p.feedback>0.001f ? std::ceil(std::log(0.001)/std::log(p.feedback)) : 1.0;
    // Conservative RT60 budget, including the longest multi-tap and serial reverb tail.
    return 1.5*delaySeconds*(repeats+1.0)+2.0*p.decay+0.001*p.preDelay;
}

tideglass::Parameters TideglassAudioProcessor::readParameters() const noexcept
{
    auto f=[&](ParameterIndex i){return raw[static_cast<size_t>(i)]->load(std::memory_order_relaxed);};
    tideglass::Parameters p;
    p.delayEnabled=f(delayEnabled)>0.5f; p.reverbEnabled=f(reverbEnabled)>0.5f;
    p.sync=f(sync)>0.5f; p.hold=f(hold)>0.5f; p.freeze=f(freeze)>0.5f; p.spillover=f(spillover)>0.5f;
    p.delayMode=(int)f(delayMode); p.reverbMode=(int)f(reverbMode); p.routing=(int)f(routing);
    p.noteL=(int)f(noteL); p.noteR=(int)f(noteR); p.rhythmL=(int)f(rhythmL); p.rhythmR=(int)f(rhythmR);
    p.bpm=f(bpm); p.timeMsL=f(timeMsL); p.timeMsR=f(timeMsR);
    p.feedback=f(feedback)*0.01f; p.delayMix=f(delayMix)*0.01f;
    p.delayLowCut=f(delayLowCut); p.delayHighCut=f(delayHighCut); p.driveDb=f(driveDb);
    p.modDepth=f(modDepth)*0.01f; p.modRate=f(modRate); p.delayDuck=f(delayDuck)*0.01f;
    p.decay=f(decay); p.size=f(size)*0.01f; p.preDelay=f(preDelay); p.damping=f(damping);
    p.diffusion=f(diffusion)*0.01f; p.reverbMix=f(reverbMix)*0.01f;
    p.reverbLowCut=f(reverbLowCut); p.reverbHighCut=f(reverbHighCut);
    p.reverbMod=f(reverbMod)*0.01f; p.reverbDuck=f(reverbDuck)*0.01f;
    p.width=f(width)*0.01f; p.masterMix=f(masterMix)*0.01f; p.outputDb=f(outputDb);
    return p;
}

void TideglassAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer,juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    midi.clear();
    const int n=buffer.getNumSamples(), channels=buffer.getNumChannels();
    if(channels==0 || n==0) return;
    for(int c=getTotalNumInputChannels();c<channels;++c) buffer.clear(c,0,n);
    if(getTotalNumInputChannels()==1 && channels>=2) buffer.copyFrom(1,0,buffer,0,0,n);
    auto p=readParameters();
    bool hostTempo=false;
    if(auto* playHead=getPlayHead())
        if(auto position=playHead->getPosition())
            if(auto tempo=position->getBpm())
                if(std::isfinite(*tempo) && *tempo>=20 && *tempo<=300)
                { p.bpm=(float)*tempo; hostTempo=true; }
    currentBpm.store(p.bpm,std::memory_order_relaxed);
    hostTempoActive.store(hostTempo,std::memory_order_relaxed);
    if(panicRequested.exchange(false)) engine.reset();
    engine.setParameters(p);
    float in=0;
    for(int c=0;c<juce::jmin(2,channels);++c) in=juce::jmax(in,buffer.getMagnitude(c,0,n));
    if(channels>=2) engine.process(buffer.getWritePointer(0),buffer.getWritePointer(1),n);
    else
    {
        const int capacity=monoScratch.getNumSamples();
        if(capacity<=0) return;
        for(int offset=0;offset<n;)
        {
            const int count=juce::jmin(capacity,n-offset);
            auto* left=buffer.getWritePointer(0,offset);
            auto* right=monoScratch.getWritePointer(0);
            juce::FloatVectorOperations::copy(right,left,count);
            engine.process(left,right,count);
            for(int i=0;i<count;++i) left[i]=0.5f*(left[i]+right[i]);
            offset+=count;
        }
    }
    float out=0;
    for(int c=0;c<juce::jmin(2,channels);++c) out=juce::jmax(out,buffer.getMagnitude(c,0,n));
    inputPeak.store(juce::jmax(in,inputPeak.load()*0.92f),std::memory_order_relaxed);
    outputPeak.store(juce::jmax(out,outputPeak.load()*0.92f),std::memory_order_relaxed);
}

juce::AudioProcessorEditor* TideglassAudioProcessor::createEditor() { return new TideglassAudioProcessorEditor(*this); }
int TideglassAudioProcessor::getNumPrograms() { return (int)presets().size(); }
const juce::String TideglassAudioProcessor::getProgramName(int index)
{ return juce::isPositiveAndBelow(index,(int)presets().size()) ? presets()[(size_t)index].name : juce::String(); }
juce::StringArray TideglassAudioProcessor::getFactoryPresetNames() const
{
    juce::StringArray result;
    for(const auto& preset:presets()) result.add(preset.name);
    return result;
}
void TideglassAudioProcessor::loadFactoryPreset(int index)
{
    if(!juce::isPositiveAndBelow(index,(int)presets().size())) return;
    for(const char* id:ids)
        if(auto* p=parameters.getParameter(id))
        {
            auto value=p->getDefaultValue();
            for(const auto& entry:presets()[(size_t)index].values)
                if(juce::StringRef(id)==juce::StringRef(entry.first)) {value=p->convertTo0to1(entry.second);break;}
            p->beginChangeGesture(); p->setValueNotifyingHost(value); p->endChangeGesture();
        }
    selectedPreset.store(index);
}
void TideglassAudioProcessor::tapTempo()
{
    const double now=juce::Time::getMillisecondCounterHiRes();
    const double delta=now-lastTap; lastTap=now;
    if(delta<200 || delta>3000) {tapCount=0;return;}
    tapIntervals[(size_t)(tapCount%4)]=delta;
    ++tapCount;
    double mean=0; const int count=juce::jmin(tapCount,4);
    for(int i=0;i<count;++i) mean+=tapIntervals[(size_t)i];
    if(auto* tempo=parameters.getParameter("bpm"))
    {
        tempo->beginChangeGesture(); tempo->setValueNotifyingHost(tempo->convertTo0to1((float)(60000.0*count/mean))); tempo->endChangeGesture();
    }
}

void TideglassAudioProcessor::getStateInformation(juce::MemoryBlock& dest)
{
    auto state=parameters.copyState(); state.setProperty("factoryPreset",selectedPreset.load(),nullptr);
    state.setProperty("schemaVersion",1,nullptr);
    if(auto xml=state.createXml()) copyXmlToBinary(*xml,dest);
}
bool TideglassAudioProcessor::restoreState(const juce::ValueTree& state)
{
    if(!state.isValid() || !state.hasType("TideglassState")) return false;
    // Sanitize the complete snapshot before replacing state. Unknown parameter IDs are ignored.
    auto clean=parameters.copyState();
    for(const auto& child:state)
    {
        const auto id=child.getProperty("id").toString();
        if(auto* parameter=parameters.getParameter(id))
        {
            const float value=(float)child.getProperty("value");
            if(!std::isfinite(value)) return false;
            auto destination=clean.getChildWithProperty("id",id);
            if(destination.isValid()) destination.setProperty("value",parameter->convertFrom0to1(parameter->convertTo0to1(value)),nullptr);
        }
    }
    parameters.replaceState(clean);
    selectedPreset.store(juce::jlimit(0,(int)presets().size()-1,(int)state.getProperty("factoryPreset",0)));
    return true;
}
void TideglassAudioProcessor::setStateInformation(const void* data,int bytes)
{
    if(bytes<=0 || bytes>1024*1024) return;
    if(auto xml=getXmlFromBinary(data,bytes)) restoreState(juce::ValueTree::fromXml(*xml));
}
void TideglassAudioProcessor::savePresetToFile(const juce::File& file)
{
    auto state=parameters.copyState(); state.setProperty("factoryPreset",selectedPreset.load(),nullptr);
    state.setProperty("schemaVersion",1,nullptr);
    if(auto xml=state.createXml())
        if(!xml->writeTo(file)) juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon,"Preset not saved","Tideglass could not write to this location.");
}
bool TideglassAudioProcessor::loadPresetFromFile(const juce::File& file)
{
    if(file.getSize()>1024*1024) return false;
    if(auto xml=juce::XmlDocument::parse(file)) return restoreState(juce::ValueTree::fromXml(*xml));
    return false;
}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new TideglassAudioProcessor(); }
