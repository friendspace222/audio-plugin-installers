#include "DSP.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <vector>

namespace tideglass
{
namespace
{
constexpr double pi = 3.14159265358979323846;
constexpr std::size_t reverbOrder = 16;
constexpr float projectionGain = 0.25f; // 1/sqrt(reverbOrder)
constexpr double maxDelaySeconds = 36.1;

template <typename T> T clamp(T x, T lo, T hi) { return std::max(lo, std::min(hi, x)); }
float finite(float x, float fallback = 0.0f) { return std::isfinite(x) ? x : fallback; }
float clean(float x) { return std::isfinite(x) && std::abs(x) > 1.0e-25f ? clamp(x, -32.0f, 32.0f) : 0.0f; }
float approach(float x, float target, float a) { return x + a * (target - x); }
float lerp(float a, float b, float x) { return a + x * (b - a); }
float filterCoefficient(float hz, double sr)
{
    return static_cast<float>(1.0 - std::exp(-2.0 * pi * clamp(static_cast<double>(hz), 2.0, sr * 0.45) / sr));
}

// A logical clear makes panic/reset bounded in time even with 36-second rings.
// Reads outside the valid history return zero, including interpolation guards.
struct Ring
{
    std::vector<float> data;
    int pos = 0, valid = 0;
    void prepare(int length) { data.assign(static_cast<std::size_t>(std::max(length, 8)), 0.0f); reset(); }
    void reset() noexcept { pos = valid = 0; }
    void push(float x) noexcept
    {
        data[static_cast<std::size_t>(pos)] = clean(x);
        if (++pos == static_cast<int>(data.size())) pos = 0;
        valid = std::min(valid + 1, static_cast<int>(data.size()));
    }
    float age(int n) const noexcept
    {
        if (n < 0 || n >= valid) return 0.0f;
        int index = pos - 1 - n;
        if (index < 0) index += static_cast<int>(data.size());
        return data[static_cast<std::size_t>(index)];
    }
    // delay=1 reads the last pushed sample. Call before push for an exact
    // integer delay in samples. Four-point cubic interpolation is used.
    float read(double delay) const noexcept
    {
        const double ageInSamples = clamp(delay, 1.0, static_cast<double>(data.size() - 3)) - 1.0;
        const int i = static_cast<int>(ageInSamples);
        const float t = static_cast<float>(ageInSamples - i);
        const float y0 = age(i - 1), y1 = age(i), y2 = age(i + 1), y3 = age(i + 2);
        const float a = -0.5f * y0 + 1.5f * y1 - 1.5f * y2 + 0.5f * y3;
        const float b = y0 - 2.5f * y1 + 2.0f * y2 - 0.5f * y3;
        const float c = -0.5f * y0 + 0.5f * y2;
        return ((a * t + b) * t + c) * t + y1;
    }
};

struct Tone
{
    float low = 0.0f, high = 0.0f, extra = 0.0f;
    void reset() { low = high = extra = 0.0f; }
    float process(float x, float hp, float lp, bool secondPole = false)
    {
        low = clean(approach(low, x, hp));
        high = clean(approach(high, x - low, lp));
        extra = clean(approach(extra, high, lp));
        return secondPole ? extra : high;
    }
};

// First-order antiderivative antialiasing for the regular colour stages.
// Integrating tanh between adjacent samples reduces generated foldback without
// oversampling. It introduces about half a sample of effect-path group delay.
struct AntialiasedTanh
{
    double previous = 0.0, previousIntegral = 0.0;
    bool active = false;
    static double integral(double x)
    {
        const double magnitude = std::abs(x);
        return magnitude + std::log1p(std::exp(-2.0 * magnitude)) - 0.69314718055994530942;
    }
    void reset() { previous = previousIntegral = 0.0; active = false; }
    float process(float input)
    {
        const double x = std::isfinite(input) ? input : 0.0;
        const double currentIntegral = integral(x);
        double result;
        if (!active)
            result = std::tanh(x);
        else
        {
            const double difference = x - previous;
            result = std::abs(difference) < 1.0e-5 * (1.0 + std::max(std::abs(x),std::abs(previous)))
                   ? std::tanh(0.5 * (x + previous))
                   : (currentIntegral - previousIntegral) / difference;
        }
        previous = x; previousIntegral = currentIntegral; active = true;
        return clean(static_cast<float>(result));
    }
};

struct Allpass
{
    Ring ring;
    double length = 1.0;
    void prepare(double sr, double seconds) { length = seconds * sr; ring.prepare(static_cast<int>(length) + 8); }
    void reset() { ring.reset(); }
    float process(float x, float g)
    {
        const float z = ring.read(length);
        const float y = z - g * x;
        ring.push(x + g * y);
        return clean(y);
    }
};

struct DelayTime
{
    double current = 1.0, destination = 1.0, pending = 1.0;
    int remaining = 0, duration = 1;
    void reset(double value, double sr)
    {
        current = destination = pending = value;
        remaining = 0;
        duration = std::max(1, static_cast<int>(sr * 0.035));
    }
    void request(double value)
    {
        pending = value;
        if (remaining == 0 && std::abs(value - current) > 0.25)
        {
            destination = value;
            remaining = duration;
        }
    }
    float read(const Ring& ring, double modulation, double multiple = 1.0) const
    {
        const float a = ring.read(current * multiple + modulation);
        if (!remaining) return a;
        const float t = 1.0f - static_cast<float>(remaining) / static_cast<float>(duration);
        // Equal-gain prevents a +3 dB bump when the two heads are correlated.
        const float ease = t * t * (3.0f - 2.0f * t);
        return lerp(a, ring.read(destination * multiple + modulation), ease);
    }
    void advance()
    {
        if (remaining && --remaining == 0) { current = destination; request(pending); }
    }
    double nominal() const { return remaining ? destination : current; }
};

struct Stereo { float l = 0.0f, r = 0.0f; };

struct OctaveUp
{
    std::array<Ring, 2> ring;
    double phase = 0.0, window = 2400.0;
    void prepare(double sr)
    {
        window = sr * 0.055;
        for (auto& r : ring) r.prepare(static_cast<int>(window) + 64);
        reset();
    }
    void reset() { phase = 0.0; for (auto& r : ring) r.reset(); }
    Stereo process(Stereo x)
    {
        ring[0].push(x.l); ring[1].push(x.r);
        const double second = phase < 0.5 ? phase + 0.5 : phase - 0.5;
        const float w = static_cast<float>(0.5 - 0.5 * std::cos(2.0 * pi * phase));
        Stereo y;
        y.l = w * ring[0].read(8.0 + (1.0 - phase) * window)
            + (1.0f - w) * ring[0].read(8.0 + (1.0 - second) * window);
        y.r = w * ring[1].read(8.0 + (1.0 - phase) * window)
            + (1.0f - w) * ring[1].read(8.0 + (1.0 - second) * window);
        phase += 1.0 / window;
        if (phase >= 1.0) phase -= 1.0;
        return y;
    }
};

struct ReverbProfile
{
    float scale, early, diffusion, damping, modulation, bassDecay;
};
constexpr std::array<ReverbProfile, 8> profiles {{
    {0.47f, 0.48f, 0.65f, 0.80f, 0.45f, 1.04f}, // room: compact / strong early reflections
    {0.72f, 0.34f, 0.72f, 0.88f, 0.65f, 1.12f}, // chamber
    {0.84f, 0.14f, 0.88f, 1.12f, 0.80f, 1.04f}, // plate: dense and bright
    {1.12f, 0.23f, 0.83f, 0.83f, 0.85f, 1.30f}, // hall: deep diffuse late field
    {1.82f, 0.16f, 0.87f, 0.66f, 1.00f, 1.48f}, // cathedral: larger propagation / bass decay
    {0.40f, 0.27f, 0.54f, 0.66f, 0.25f, 1.02f}, // spring + dispersive allpasses
    {1.28f, 0.13f, 0.86f, 1.08f, 1.00f, 1.20f}, // shimmer + actual octave-up return
    {0.61f, 0.38f, 0.83f, 0.96f, 0.45f, 1.05f}  // gated + hold/release envelope
}};

Parameters sanitise(Parameters p)
{
    p.delayMode = clamp(p.delayMode, 0, 5); p.reverbMode = clamp(p.reverbMode, 0, 7);
    p.routing = clamp(p.routing, 0, 2);
    p.noteL = clamp(p.noteL, 0, 7); p.noteR = clamp(p.noteR, 0, 7);
    p.rhythmL = clamp(p.rhythmL, 0, 2); p.rhythmR = clamp(p.rhythmR, 0, 2);
    auto f = [](float x, float lo, float hi, float fallback) { return clamp(finite(x, fallback), lo, hi); };
    p.bpm = f(p.bpm, 20, 400, 120);
    p.timeMsL = f(p.timeMsL, 1, 8000, 375); p.timeMsR = f(p.timeMsR, 1, 8000, 500);
    p.feedback = f(p.feedback, 0, 0.985f, 0.4f); p.delayMix = f(p.delayMix, 0, 1, 0.3f);
    p.delayLowCut = f(p.delayLowCut, 10, 3000, 120); p.delayHighCut = f(p.delayHighCut, 500, 22000, 6500);
    p.driveDb = f(p.driveDb, 0, 24, 0); p.modDepth = f(p.modDepth, 0, 1, 0.15f);
    p.modRate = f(p.modRate, 0.01f, 10, 0.4f); p.delayDuck = f(p.delayDuck, 0, 1, 0.2f);
    p.decay = f(p.decay, 0.1f, 60, 3.5f); p.size = f(p.size, 0, 1, 0.65f);
    p.preDelay = f(p.preDelay, 0, 500, 25); p.damping = f(p.damping, 500, 22000, 6500);
    p.diffusion = f(p.diffusion, 0, 1, 0.85f); p.reverbMix = f(p.reverbMix, 0, 1, 0.30f);
    p.reverbLowCut = f(p.reverbLowCut, 10, 3000, 80); p.reverbHighCut = f(p.reverbHighCut, 500, 22000, 9000);
    p.reverbMod = f(p.reverbMod, 0, 1, 0.2f); p.reverbDuck = f(p.reverbDuck, 0, 1, 0.05f);
    p.width = f(p.width, 0, 2, 1); p.masterMix = f(p.masterMix, 0, 1, 1);
    p.outputDb = f(p.outputDb, -36, 12, 0);
    return p;
}

// A product of plane rotations remains orthogonal at EVERY density setting.
// Low diffusion leaves recognisable paths; high diffusion scatters energy to
// all sixteen paths on each circuit. No interpolation of feedback matrices.
void scatter(std::array<float, reverbOrder>& x, float cosine, float sine)
{
    for (int span = 1; span < static_cast<int>(reverbOrder); span *= 2)
        for (int base = 0; base < static_cast<int>(reverbOrder); base += span * 2)
            for (int j = 0; j < span; ++j)
            {
                const float a = x[static_cast<std::size_t>(base + j)];
                const float b = x[static_cast<std::size_t>(base + j + span)];
                x[static_cast<std::size_t>(base + j)] = cosine*a + sine*b;
                x[static_cast<std::size_t>(base + j + span)] = cosine*b - sine*a;
            }
}
} // namespace

struct Engine::Impl
{
    Parameters p, s;
    double sr = 48000.0;
    bool prepared = false, primed = false, delayCleared = false, reverbCleared = false;
    std::array<Ring, 2> delays, pre;
    std::array<DelayTime, 2> times;
    std::array<Tone, 2> delayTone, reverbTone;
    std::array<AntialiasedTanh, 2> drive;
    std::array<std::array<Allpass, 6>, 2> diffuser;
    std::array<std::array<Allpass, 4>, 2> spring;
    std::array<std::array<Allpass, 2>, 2> lateDiffuser;
    std::array<Ring, reverbOrder> lines;
    std::array<float, reverbOrder> lowBand {}, highBand {}, dc {}, lowGains {}, midGains {}, highGains {}, lengths {}, targetLengths {};
    std::array<double, reverbOrder> phases {}, secondaryPhases {};
    OctaveUp octave;
    double lfo = 0.0, wow = 0.0, flutter = 0.0;
    std::array<double, 2> reversePhase {{0.0, 0.23}};
    float smoothA = 0.001f, switchA = 0.004f, lengthSmoothA = 0.001f;
    float dEnable = 1, rEnable = 1, dWet = 1, rWet = 1;
    float dModeGain = 1, rModeGain = 1, routeGain = 1;
    float delayHP = 0, delayLP = 0, reverbHP = 0, reverbLP = 0, dampLP = 0, bassLP = 0;
    float scatterCos = 0.70710678f, scatterSin = 0.70710678f;
    float driveGain = 1, outputGain = 1, detector = 0, freezeAmount = 0, holdAmount = 0;
    float gate = 0, dcCoefficient = 0, gateRelease = 0;
    int gateRemaining = 0, tick = 0, delayMode = 0, reverbMode = 3, route = 0;

    void clearDelay()
    {
        for (auto& r : delays) r.reset();
        for (auto& f : delayTone) f.reset();
        for (auto& f : drive) f.reset();
        reversePhase = {{0.0, 0.23}};
    }
    void clearReverb()
    {
        for (auto& r : pre) r.reset();
        for (auto& r : lines) r.reset();
        for (auto& channel : diffuser) for (auto& ap : channel) ap.reset();
        for (auto& channel : spring) for (auto& ap : channel) ap.reset();
        for (auto& channel : lateDiffuser) for (auto& ap : channel) ap.reset();
        for (auto& f : reverbTone) f.reset();
        lowBand.fill(0); highBand.fill(0); dc.fill(0); octave.reset(); gate = 0; gateRemaining = 0;
    }
    void prepare(double sampleRate)
    {
        sr = std::isfinite(sampleRate) ? clamp(sampleRate, 8000.0, 384000.0) : 48000.0;
        for (auto& r : delays) r.prepare(static_cast<int>(sr * maxDelaySeconds) + 16);
        for (auto& r : pre) r.prepare(static_cast<int>(sr * 0.95) + 16);
        for (auto& r : lines) r.prepare(static_cast<int>(sr * 0.65) + 16);
        constexpr double diffusionTimes[2][6] = {{0.0031, 0.0057, 0.0093, 0.0137, 0.0209, 0.0311},
                                                {0.0037, 0.0067, 0.0109, 0.0163, 0.0233, 0.0349}};
        constexpr double springTimes[2][4] = {{0.0011, 0.0023, 0.0037, 0.0053}, {0.0013, 0.0029, 0.0041, 0.0059}};
        for (std::size_t c = 0; c < 2; ++c)
        {
            for (std::size_t i = 0; i < 6; ++i) diffuser[c][i].prepare(sr, diffusionTimes[c][i]);
            for (std::size_t i = 0; i < 4; ++i)
                spring[c][i].prepare(sr, springTimes[c][i]);
            lateDiffuser[c][0].prepare(sr,c == 0 ? 0.0071 : 0.0097);
            lateDiffuser[c][1].prepare(sr,c == 0 ? 0.0173 : 0.0211);
        }
        octave.prepare(sr);
        smoothA = static_cast<float>(1.0 - std::exp(-1.0 / (sr * 0.020)));
        switchA = static_cast<float>(1.0 - std::exp(-1.0 / (sr * 0.003)));
        lengthSmoothA = static_cast<float>(1.0 - std::exp(-1.0 / (sr * 0.080)));
        dcCoefficient = filterCoefficient(2.0f, sr);
        gateRelease = static_cast<float>(1.0 - std::exp(-1.0 / (sr * 0.012)));
        prepared = true;
        reset();
    }
    void reset()
    {
        clearDelay(); clearReverb();
        lfo = wow = flutter = 0.0;
        for (std::size_t i = 0; i < phases.size(); ++i)
        {
            phases[i] = std::fmod(static_cast<double>(i)*0.713,2*pi);
            secondaryPhases[i] = std::fmod(static_cast<double>(i)*1.173,2*pi);
        }
        detector = 0; tick = 0; primed = delayCleared = reverbCleared = false;
    }
    double desiredTime(int channel) const
    {
        const double ms = p.sync ? Engine::noteMilliseconds(channel ? p.noteR : p.noteL,
                                 channel ? p.rhythmR : p.rhythmL, p.bpm)
                                 : (channel ? p.timeMsR : p.timeMsL);
        return clamp(ms * sr / 1000.0, 2.0, sr * 36.0);
    }
    void initialise()
    {
        s = p; delayMode = p.delayMode; reverbMode = p.reverbMode; route = p.routing;
        dEnable = p.delayEnabled ? 1.0f : 0.0f; rEnable = p.reverbEnabled ? 1.0f : 0.0f;
        dWet = (p.delayEnabled || p.spillover) ? 1.0f : 0.0f;
        rWet = (p.reverbEnabled || p.spillover) ? 1.0f : 0.0f;
        dModeGain = rModeGain = routeGain = 1;
        freezeAmount = p.freeze ? 1.0f : 0.0f; holdAmount = p.hold ? 1.0f : 0.0f;
        driveGain = std::pow(10.0f, p.driveDb / 20.0f); outputGain = std::pow(10.0f, p.outputDb / 20.0f);
        times[0].reset(desiredTime(0), sr); times[1].reset(desiredTime(1), sr);
        updateCoefficients(true);
        primed = true;
    }
    void smooth()
    {
        auto f = [this](float& x, float target) { x = approach(x, target, smoothA); };
        f(s.feedback,p.feedback); f(s.delayMix,p.delayMix); f(s.delayLowCut,p.delayLowCut); f(s.delayHighCut,p.delayHighCut);
        f(s.driveDb,p.driveDb); f(s.modDepth,p.modDepth); f(s.modRate,p.modRate); f(s.delayDuck,p.delayDuck);
        f(s.decay,p.decay); f(s.size,p.size); f(s.preDelay,p.preDelay); f(s.damping,p.damping);
        f(s.diffusion,p.diffusion); f(s.reverbMix,p.reverbMix); f(s.reverbLowCut,p.reverbLowCut);
        f(s.reverbHighCut,p.reverbHighCut); f(s.reverbMod,p.reverbMod); f(s.reverbDuck,p.reverbDuck);
        f(s.width,p.width); f(s.masterMix,p.masterMix); f(s.outputDb,p.outputDb);
        dEnable = approach(dEnable, p.delayEnabled ? 1.0f : 0.0f, switchA);
        rEnable = approach(rEnable, p.reverbEnabled ? 1.0f : 0.0f, switchA);
        dWet = approach(dWet, (p.delayEnabled || p.spillover) ? 1.0f : 0.0f, switchA);
        rWet = approach(rWet, (p.reverbEnabled || p.spillover) ? 1.0f : 0.0f, switchA);
        f(freezeAmount, p.freeze ? 1.0f : 0.0f); f(holdAmount, p.hold ? 1.0f : 0.0f);
        auto change = [this](float& gain, int& mode, int requested)
        {
            gain = approach(gain, mode == requested ? 1.0f : 0.0f, switchA);
            if (mode != requested && gain < 0.001f) mode = requested;
        };
        change(dModeGain,delayMode,p.delayMode); change(rModeGain,reverbMode,p.reverbMode); change(routeGain,route,p.routing);
        if (!p.delayEnabled && !p.spillover && dWet < 0.001f && !delayCleared) { clearDelay(); delayCleared = true; }
        if (!p.reverbEnabled && !p.spillover && rWet < 0.001f && !reverbCleared) { clearReverb(); reverbCleared = true; }
        if (p.delayEnabled) delayCleared = false;
        if (p.reverbEnabled) reverbCleared = false;
    }
    void updateCoefficients(bool immediate = false)
    {
        delayHP = filterCoefficient(s.delayLowCut, sr);
        float delayCut = s.delayHighCut;
        if (delayMode == 1) delayCut *= 0.82f;
        if (delayMode == 2) delayCut *= 0.52f;
        delayLP = filterCoefficient(delayCut, sr);
        reverbHP = filterCoefficient(s.reverbLowCut, sr);
        reverbLP = filterCoefficient(s.reverbHighCut, sr);
        const auto profile = profiles[static_cast<std::size_t>(reverbMode)];
        // Three-band decay shaping: frequency-dependent RT60 gains rather
        // than a raw low-pass whose loss compounds uncontrollably every lap.
        dampLP = filterCoefficient(s.damping * 0.50f, sr);
        bassLP = filterCoefficient(280.0f, sr);
        const float density = clamp(std::pow(s.diffusion,0.70f)*profile.diffusion/0.85f,0.0f,1.0f);
        const float angle = static_cast<float>(pi*0.25)*(0.04f+0.96f*density);
        scatterCos = std::cos(angle); scatterSin = std::sin(angle);
        driveGain = std::pow(10.0f, s.driveDb / 20.0f);
        outputGain = std::pow(10.0f, s.outputDb / 20.0f);
        constexpr double seconds[reverbOrder] = {0.0211,0.0253,0.0301,0.0347,0.0397,0.0451,0.0509,0.0563,
                                                0.0623,0.0689,0.0757,0.0833,0.0919,0.1013,0.1129,0.1249};
        const float dimension = (0.55f + 1.85f * s.size) * profile.scale;
        const float decay = reverbMode == 7 ? std::min(s.decay, 1.6f) : s.decay;
        const float brightness = clamp(std::log(s.damping/500.0f)/std::log(44.0f),0.0f,1.0f);
        const float trebleDecay = clamp((0.18f+0.72f*std::sqrt(brightness))*profile.damping,0.12f,0.98f);
        for (std::size_t i = 0; i < reverbOrder; ++i)
        {
            const float target = static_cast<float>(seconds[i] * sr) * dimension;
            targetLengths[i] = target;
            if(immediate) lengths[i] = target;
            const double loopSeconds = lengths[i]/sr;
            lowGains[i] = static_cast<float>(std::pow(10.0,-3.0*loopSeconds/(decay*profile.bassDecay)));
            midGains[i] = static_cast<float>(std::pow(10.0,-3.0*loopSeconds/decay));
            highGains[i] = static_cast<float>(std::pow(10.0,-3.0*loopSeconds/(decay*trebleDecay)));
        }
    }
    Stereo processDelay(Stereo input)
    {
        if (delayCleared && !p.delayEnabled)
        {
            times[0].advance(); times[1].advance();
            return {};
        }
        const double depth = sr * s.modDepth * (delayMode == 2 ? 0.0015 : 0.0006);
        double modL = std::sin(lfo) * depth, modR = std::sin(lfo + 1.173) * depth;
        if (delayMode == 1)
        {
            modL += sr * (0.0005 * std::sin(wow) + 0.00008 * std::sin(flutter)) * s.modDepth;
            modR += sr * (0.0005 * std::sin(wow + 0.31) + 0.00008 * std::sin(flutter + 0.7)) * s.modDepth;
        }
        Stereo wet {times[0].read(delays[0],modL), times[1].read(delays[1],modR)};
        if (delayMode == 4)
        {
            wet.l = 0.50f * wet.l + 0.25f * times[1].read(delays[1],modR,0.5)
                  + 0.15f * times[0].read(delays[0],modL,0.75) + 0.10f * times[1].read(delays[1],modR,0.875);
            wet.r = 0.50f * wet.r + 0.25f * times[0].read(delays[0],modL,0.5)
                  + 0.15f * times[1].read(delays[1],modR,0.75) + 0.10f * times[0].read(delays[0],modL,0.875);
        }
        if (delayMode == 5)
        {
            float* outputs[2] = {&wet.l,&wet.r};
            for (std::size_t c = 0; c < 2; ++c)
            {
                const double length = std::max(32.0, times[c].nominal() * 0.5);
                const double q = reversePhase[c];
                const double q2 = q < 0.5 ? q + 0.5 : q - 0.5;
                const float w = static_cast<float>(0.5 - 0.5 * std::cos(2 * pi * q));
                *outputs[c] = w * delays[c].read(2.0 + 2.0 * q * length)
                            + (1.0f-w) * delays[c].read(2.0 + 2.0 * q2 * length);
                reversePhase[c] += 1.0 / length;
                if (reversePhase[c] >= 1.0) reversePhase[c] -= 1.0;
            }
        }
        wet.l = delayTone[0].process(wet.l,delayHP,delayLP,delayMode==2);
        wet.r = delayTone[1].process(wet.r,delayHP,delayLP,delayMode==2);
        const float colourDrive = driveGain * (delayMode == 1 ? 1.8f : (delayMode == 2 ? 1.35f : 1.0f));
        if (s.driveDb > 0.001f || delayMode == 1 || delayMode == 2)
        {
            const float amount = (delayMode == 1 || delayMode == 2) ? 1.0f : clamp(s.driveDb,0.0f,1.0f);
            wet.l = lerp(wet.l,drive[0].process(wet.l * colourDrive) / colourDrive,amount);
            wet.r = lerp(wet.r,drive[1].process(wet.r * colourDrive) / colourDrive,amount);
        }
        else { drive[0].reset(); drive[1].reset(); }
        const float fb = lerp(s.feedback,0.9995f,holdAmount) * (delayCleared ? 0.0f : 1.0f);
        const float inject = (dEnable > 1.0e-6f ? dEnable : 0.0f) * (1.0f-holdAmount);
        if (delayMode == 3)
        {
            delays[0].push(0.5f * (input.l+input.r) * inject + wet.r * fb);
            delays[1].push(wet.l * fb);
        }
        else
        {
            delays[0].push(input.l * inject + wet.l * fb);
            delays[1].push(input.r * inject + wet.r * fb);
        }
        times[0].advance(); times[1].advance();
        lfo += 2*pi*s.modRate/sr; if (lfo>=2*pi) lfo-=2*pi;
        wow += 2*pi*0.173/sr; if (wow>=2*pi) wow-=2*pi;
        flutter += 2*pi*5.91/sr; if (flutter>=2*pi) flutter-=2*pi;
        const float duck = 1.0f / (1.0f + 12.0f*s.delayDuck*detector);
        const float gain = s.delayMix*dWet*dModeGain*duck;
        return {wet.l*gain,wet.r*gain};
    }
    Stereo processReverb(Stereo input)
    {
        if (reverbCleared && !p.reverbEnabled) return {};
        const auto profile = profiles[static_cast<std::size_t>(reverbMode)];
        const float injection = (rEnable > 1.0e-6f ? rEnable : 0.0f) * (1.0f-freezeAmount);
        pre[0].push(input.l*injection); pre[1].push(input.r*injection);
        const double predelay = s.preDelay*sr*0.001;
        const Stereo predelayed {pre[0].read(predelay+1),pre[1].read(predelay+1)};
        Stereo feed=predelayed;
        Stereo early;
        constexpr double earlyTimes[12] = {0.0031,0.0079,0.0137,0.0191,0.0253,0.0329,
                                           0.0413,0.0499,0.0593,0.0689,0.0787,0.0899};
        constexpr float earlyGain[12] = {0.28f,0.24f,-0.21f,0.18f,0.15f,-0.13f,
                                         0.11f,0.09f,-0.08f,0.065f,0.055f,-0.045f};
        const double dimension = (0.55+1.85*s.size)*profile.scale;
        for (std::size_t i=0;i<12;++i)
        {
            // Reflection positions stretch with Size, independently of the
            // Decay control. Opposite-channel arrivals differ in path length.
            early.l += earlyGain[i]*(0.82f*pre[i%2].read(predelay+1+earlyTimes[i]*dimension*sr)
                                     +0.18f*pre[1-i%2].read(predelay+1+earlyTimes[i]*dimension*sr*1.073));
            early.r += earlyGain[i]*(0.82f*pre[1-i%2].read(predelay+1+earlyTimes[i]*dimension*sr*1.113)
                                     +0.18f*pre[i%2].read(predelay+1+earlyTimes[i]*dimension*sr*0.947));
        }
        const float diffusionGain = clamp(0.25f+0.56f*s.diffusion*profile.diffusion,0.1f,0.76f);
        for (std::size_t i=0;i<6;++i)
        {
            feed.l=diffuser[0][i].process(feed.l,diffusionGain);
            feed.r=diffuser[1][i].process(feed.r,diffusionGain);
        }
        // This controls actual temporal spreading, as well as the orthogonal
        // feedback scattering. At zero, distinct echoes are intentionally heard.
        const float diffusionBlend=std::sqrt(s.diffusion);
        feed.l=lerp(predelayed.l,feed.l,diffusionBlend);
        feed.r=lerp(predelayed.r,feed.r,diffusionBlend);
        if (reverbMode==5)
            for (std::size_t i=0;i<4;++i)
            {
                feed.l=spring[0][i].process(feed.l,0.72f);
                feed.r=spring[1][i].process(feed.r,-0.68f);
            }
        std::array<float,reverbOrder> values;
        constexpr float signsL[reverbOrder]={1,1,1,1,-1,-1,-1,-1,1,1,1,1,-1,-1,-1,-1};
        constexpr float signsR[reverbOrder]={1,1,-1,-1,1,1,-1,-1,1,1,-1,-1,1,1,-1,-1};
        constexpr float outputL[reverbOrder]={1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1};
        constexpr float outputR[reverbOrder]={1,-1,-1,1,1,-1,-1,1,-1,1,1,-1,-1,1,1,-1};
        constexpr double rates[reverbOrder]={0.071,0.093,0.117,0.139,0.163,0.191,0.223,0.257,
                                             0.079,0.103,0.127,0.151,0.179,0.211,0.241,0.269};
        Stereo late, shimmerSend;
        for (std::size_t i=0;i<reverbOrder;++i)
        {
            lengths[i]=approach(lengths[i],targetLengths[i],lengthSmoothA);
            const double modulation=(std::sin(phases[i])+0.23*std::sin(secondaryPhases[i]))
                                   *sr*0.00075*s.reverbMod*profile.modulation*(1.0-freezeAmount);
            float x=lines[i].read(lengths[i]+modulation);
            // The pitch-shift return uses only normalized end-of-line
            // projections. Multi-tap output density must not raise loop gain.
            shimmerSend.l+=projectionGain*x*outputL[i];
            shimmerSend.r+=projectionGain*x*outputR[i];
            // Three independent readout positions per path, with squared tap
            // weights summing to one. More arrivals, not an arbitrary gain lift.
            const float nearTap=lines[i].read(lengths[i]*0.373+modulation*0.43);
            const float farTap=lines[i].read(lengths[i]*0.719-modulation*0.31);
            late.l+=projectionGain*(0.70710678f*x*outputL[i]+0.5f*nearTap*outputR[(i+3)%reverbOrder]
                                  +0.5f*farTap*outputL[(i+7)%reverbOrder]);
            late.r+=projectionGain*(0.70710678f*x*outputR[i]+0.5f*nearTap*outputL[(i+5)%reverbOrder]
                                  -0.5f*farTap*outputR[(i+11)%reverbOrder]);
            dc[i]=clean(approach(dc[i],x,dcCoefficient));
            x-=dc[i]*(1.0f-freezeAmount);
            lowBand[i]=clean(approach(lowBand[i],x,bassLP));
            highBand[i]=clean(approach(highBand[i],x,dampLP));
            // Positive shelf weights sum to lowGains<=1. Together with the
            // orthogonal matrix this keeps each static feedback loop passive.
            const float shaped=highGains[i]*x+(midGains[i]-highGains[i])*highBand[i]
                              +(lowGains[i]-midGains[i])*lowBand[i];
            values[i]=lerp(shaped,0.99998f*x,freezeAmount);
            phases[i]+=2*pi*rates[i]/sr;
            if(phases[i]>=2*pi)phases[i]-=2*pi;
            secondaryPhases[i]+=2*pi*rates[i]*1.731/sr;
            if(secondaryPhases[i]>=2*pi)secondaryPhases[i]-=2*pi;
        }
        Stereo shifted;
        if(reverbMode==6) shifted=octave.process(shimmerSend);
        scatter(values,scatterCos,scatterSin);
        for(std::size_t i=0;i<reverbOrder;++i)
        {
            float fb=values[i];
            if(reverbMode==6)
            {
                const float shiftedMix=0.10f*(1.0f-freezeAmount);
                fb=(1.0f-shiftedMix)*fb+shiftedMix*0.5f*projectionGain*midGains[i]*(shifted.l*signsL[i]+shifted.r*signsR[i]);
            }
            // Above normal levels this soft bound prevents runaway energy,
            // including automation, freeze and malformed host input.
            const float value=projectionGain*(feed.l*signsL[i]+feed.r*signsR[i])+fb;
            const float magnitude=std::abs(value);
            const float bounded=magnitude>2.0f ? std::copysign(2.0f+std::tanh(magnitude-2.0f),value) : value;
            lines[i].push(bounded);
        }
        const float lateDiffusion=0.15f+0.49f*s.diffusion;
        Stereo spread=late;
        for(std::size_t i=0;i<2;++i)
        {
            spread.l=lateDiffuser[0][i].process(spread.l,lateDiffusion);
            spread.r=lateDiffuser[1][i].process(spread.r,-lateDiffusion);
        }
        late.l=lerp(late.l,spread.l,diffusionBlend);
        late.r=lerp(late.r,spread.r,diffusionBlend);
        Stereo wet {profile.early*early.l+(1.0f-profile.early)*late.l,
                    profile.early*early.r+(1.0f-profile.early)*late.r};
        if(reverbMode==7)
        {
            if(std::max(std::abs(predelayed.l),std::abs(predelayed.r))>0.0015f)
                gateRemaining=static_cast<int>(sr*clamp(s.decay*0.10f,0.08f,0.90f));
            if(gateRemaining>0)--gateRemaining;
            const float target=(gateRemaining>0||p.freeze)?1.0f:0.0f;
            gate=approach(gate,target,target>gate?switchA:gateRelease);
            wet.l*=gate;wet.r*=gate;
        }
        wet.l=reverbTone[0].process(wet.l,reverbHP,reverbLP);
        wet.r=reverbTone[1].process(wet.r,reverbHP,reverbLP);
        const float duck=1.0f/(1.0f+12.0f*s.reverbDuck*detector);
        const float gain=s.reverbMix*rWet*rModeGain*duck;
        return {wet.l*gain,wet.r*gain};
    }
    void process(float* left,float* right,int count)
    {
        if(!prepared||!left||count<=0)return;
        if(!primed)initialise();
        times[0].request(desiredTime(0)); times[1].request(desiredTime(1));
        const float attack=static_cast<float>(1-std::exp(-1/(sr*0.003)));
        const float release=static_cast<float>(1-std::exp(-1/(sr*0.220)));
        for(int n=0;n<count;++n)
        {
            smooth();
            if((tick++&31)==0)updateCoefficients();
            const Stereo dry {clean(left[n]),clean(right?right[n]:left[n])};
            const float level=std::max(std::abs(dry.l),std::abs(dry.r));
            detector=clean(approach(detector,level,level>detector?attack:release));
            const float dBlend=s.delayMix*dEnable*dModeGain;
            const float rBlend=s.reverbMix*rEnable*rModeGain;
            Stereo wet;
            float dryGain;
            if(route==0)
            {
                const auto d=processDelay(dry),r=processReverb(dry);
                wet={d.l+r.l,d.r+r.r};
                dryGain=1.0f-std::max(dBlend,rBlend);
            }
            else if(route==1)
            {
                const auto d=processDelay(dry);
                const Stereo intoReverb {dry.l*(1-dBlend)+d.l,dry.r*(1-dBlend)+d.r};
                const auto r=processReverb(intoReverb);
                wet={d.l*(1-rBlend)+r.l,d.r*(1-rBlend)+r.r};
                dryGain=(1-dBlend)*(1-rBlend);
            }
            else
            {
                const auto r=processReverb(dry);
                const Stereo intoDelay {dry.l*(1-rBlend)+r.l,dry.r*(1-rBlend)+r.r};
                const auto d=processDelay(intoDelay);
                wet={r.l*(1-dBlend)+d.l,r.r*(1-dBlend)+d.r};
                dryGain=(1-dBlend)*(1-rBlend);
            }
            const float mid=0.5f*(wet.l+wet.r),side=0.5f*(wet.l-wet.r)*s.width;
            const Stereo processed {dry.l*dryGain+mid+side,dry.r*dryGain+mid-side};
            const float blend=s.masterMix*routeGain;
            left[n]=clean(lerp(dry.l,processed.l,blend)*outputGain);
            if(right)right[n]=clean(lerp(dry.r,processed.r,blend)*outputGain);
        }
    }
};

Engine::Engine():impl(new Impl) {}
Engine::~Engine()=default;
Engine::Engine(Engine&&) noexcept=default;
Engine& Engine::operator=(Engine&&) noexcept=default;
void Engine::prepare(double sr) { impl->prepare(sr); }
void Engine::reset() { impl->reset(); }
void Engine::setParameters(const Parameters& p) { impl->p=sanitise(p); }
void Engine::process(float* l,float* r,int count) { impl->process(l,r,count); }
double Engine::noteMilliseconds(int note,int rhythm,double bpm)
{
    constexpr double beats[8]={0.0625,0.125,0.25,0.5,1.0,2.0,4.0,8.0};
    const double tempo=std::isfinite(bpm)?clamp(bpm,20.0,400.0):120.0;
    const double multiplier=rhythm==1?1.5:(rhythm==2?2.0/3.0:1.0);
    return 60000.0/tempo*beats[static_cast<std::size_t>(clamp(note,0,7))]*multiplier;
}
} // namespace tideglass
